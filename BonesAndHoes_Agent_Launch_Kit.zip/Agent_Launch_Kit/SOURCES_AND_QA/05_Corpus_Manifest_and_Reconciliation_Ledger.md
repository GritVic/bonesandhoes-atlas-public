# BonesAndHoes Clean Corpus Manifest and Reconciliation Ledger

## Corpus identity

Purpose: text-only evidence audit and strategy synthesis for Anna and Haley.

Status: clean source package assembled and locally verified before NotebookLM import.

Exclusion: all earlier NotebookLM-generated Studio assets and all duplicated older NotebookLM source copies.

## Controlling source files

| Order | File | Role | Treatment |
|---:|---|---|---|
| 1 | 00_Master_Atlas_Blueprint.md | Approved reader, thesis, chapters, page budget, companion boundaries, later visual needs | Controlling structure |
| 2 | 01_Strategy_and_Operating_Roadmap.md | Definitive business model, offer ladder, 90-day plan, one-year path, decision gates, metrics | Controlling strategy |
| 3 | 02_Commerce_Product_and_Merchandising_Playbook.md | Channel roles, setup logic, product system, merchandising, economics, owned-product gates | Controlling commerce interpretation |
| 4 | 03_Content_Networking_and_Expo_Playbook.md | Content formats, permission, networking chains, Expo system, regional sourcing | Controlling audience and network interpretation |
| 5 | 04_Evidence_Method_QA_and_Corpus_Control.md | Weighting, evidence labels, inclusion/exclusion rules, NotebookLM instructions | Controlling QA |
| 6 | 05_Corpus_Manifest_and_Reconciliation_Ledger.md | File roles and audit decisions | Controlling manifest |
| 7 | 06_Legal_Navigation_Master.md | Federal/state/land decision routing and state-package index | Controlling legal summary |

## Supporting research reports

| File | Evidence contribution | Use in synthesis |
|---|---|---|
| BonesAndHoes_Commerce_Channel_Economics_Research_2026-08-18.md | Current first-party platform rules, fees, channel matrix, economics, launch gates | Cite specific channel and economics claims |
| bonesandhoes_products_suppliers_merchandising_research_2026-08-18.md | Product observations, supplier paths, pricing, project taxonomy, market gaps | Cite product and merchandising examples |
| BonesAndHoes_Audience_Content_Legal_Research_2026-08-18.md | Audience questions, project taxonomy, permissions, content flywheel, initial legal framework | Use audience/content sections; supersede its preliminary state matrix with final state files |
| BonesAndHoes_Expo_Vendor_Census_and_Monetization_Report_2026-08-18.md | Verified vendor census, business patterns, ranked interviews, field plan | Cite Expo examples and known limitations |
| BonesAndHoes_Networking_Atlas_Report_2026-08-18.md | Network clusters, connector nodes, relationship chains, ranked outreach, CRM | Cite network recommendations and targets |
| bonesandhoes_content_opportunity_library.md | Detailed repeatable content formats, sourcing resources, permissions, QA, metrics | Use as companion content library |
| BonesAndHoes_Legal_Navigation_Federal_DC_Tribal_2026-08-18.md | Federal protections, land rules, DC, tribal routing, provenance record | Cite legal navigation only |
| State legal tranche reports | Primary-source state findings and unresolved questions | Use only in legal companion; do not dominate main synthesis |

## Structured operational files

| File | Records | Purpose |
|---|---:|---|
| BonesAndHoes_Expo_Vendor_Intelligence_Directory_2026-08-18.csv | 58 total directory records | Vendor research and interview planning |
| BonesAndHoes_Networking_Atlas_2026-08-18.csv | 61 curated entities | Outreach CRM seed and relationship map |
| bonesandhoes_content_opportunity_resources.csv | 26 resource rows plus 18 content-series rows | Local sourcing and content production |
| BonesAndHoes_Legal_Navigation_Federal_DC_Tribal_2026-08-18.csv | 12 structured rows | Federal, DC, tribal, and land routing |
| State legal tranche CSVs | 50 unique state rows across three non-overlapping files: 17 + 17 + 16 | State navigation and verification actions |

Structural QA confirmed that the three state files contain exactly 50 unique states with no duplicate state names. The Expo CSV contains 58 consistent 25-field records; the Networking CSV contains 61 consistent 20-field records; and the content-resource CSV contains 44 consistent 17-field records.

## Reconciliation ledger

### Original compiled Master Plan

Decision: archive from the clean corpus.

Reason: it duplicates approximately 95–99% of the specialist documents and would cause repetition and old weighting in NotebookLM.

Replacement: the clean blueprint, strategy, playbooks, and current research reports.

### Original Executive Strategy

Decision: replace its central narrative; preserve only still-supported principles.

Preserved:

- authentic identity;
- owned audience;
- recommendations tied to actual use;
- phased validation;
- measurable decision gates.

Replaced:

- narrow checklist-centered business framing;
- a cautious outsider explanation of the niche;
- premature emphasis on low-value offers;
- any position inconsistent with authentic project work and the supporting-product ecosystem.

### Original Research Methodology

Decision: compress and retain internally.

Preserved: source hierarchy, verification dates, distinction between observations and conclusions.

Replaced: overly coarse evidence classification and any source-register practice that labels nearly everything identically.

### Original Expo Intelligence

Decision: combine selected material with the new verified census.

Preserved: useful public price observations, field protocol, event and class context.

Replaced: incomplete vendor list and any unverified tour-total headline.

### Original Social Ecosystem

Decision: rebuild.

Preserved: useful topology, audience questions, and Pacific Northwest nodes.

Replacement: 61-entity networking directory, relationship chains, first-25 queue, and permission workflow.

### Original Products and Affiliate document

Decision: major rebuild.

Preserved: valid product families and program leads that remain current.

Replacement: authentic project-support taxonomy, current pricing, supplier pathways, product-card requirements, economics, and later display-infrastructure hypotheses.

### Original Audience document

Decision: combine and compress.

Preserved: identification, legality, preparation, odor, display, presentation, and gift-intent questions.

Replacement: confidence ladder, content-to-commerce system, and priority audience offers.

### Original Monetization document

Decision: replace with current channel architecture.

Replacement: current TikTok, Etsy, Payhip, Square, Shopify, affiliate, discovery, and later marketplace playbooks with explicit gates and economics.

### Original Compliance document

Decision: move out of the main narrative and expand as a standalone companion.

Replacement: federal/DC/tribal package plus three non-overlapping state tranches and a concise master navigator.

### Original workbook and source register

Decision: preserve only as historical/internal evidence and rebuild operational ledgers from the current CSVs.

Reason: the original evidence labels and scoring are too coarse for publication-grade decisions.

### Earlier NotebookLM outputs

Decision: exclude completely from the clean corpus.

Includes: prior slides, infographics, reports, mind map, audio, and video.

Reason: they inherit the superseded corpus weighting and must not influence the first text-only audit.

## Known evidence gaps retained as explicit questions

- Current account-level audience and commerce analytics.
- Live platform eligibility and rates at the moment of enrollment.
- Private supplier wholesale prices and written fulfillment terms.
- Actual conversion, returns, and contribution by product.
- Complete official city-specific Expo rosters.
- Private vendor profitability and sales figures.
- State questions explicitly marked unresolved in the legal files.
- Product and customer compatibility questions that require interviews and tests.

NotebookLM must not fill these gaps with generic advice or unstated assumptions.

## Final import rule

Import the controlling documents first, then supporting reports, then structured CSVs. Confirm every source is readable. If a file duplicates a cleaner controlling document or contains a superseded preliminary state matrix, the controlling document governs interpretation.
