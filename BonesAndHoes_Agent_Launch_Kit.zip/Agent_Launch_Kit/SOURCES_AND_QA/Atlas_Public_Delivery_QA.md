# BonesAndHoes Atlas - Public Delivery QA

Verified: 2026-08-24

## Public endpoints

- Share/view link: https://gritvic.github.io/bonesandhoes-atlas-public/atlas/
- Direct PDF download: https://gritvic.github.io/bonesandhoes-atlas-public/BonesAndHoes_Monetization_Atlas.pdf
- Approved explainer video: https://gritvic.github.io/bonesandhoes-atlas-public/The_Evidence_Led_Blueprint_Approved.mp4

## Verification results

- Anonymous access: PASS. All three endpoints return HTTP 200 without credentials or cookies.
- Correct delivery types: PASS. PDF returns `application/pdf`; video returns `video/mp4`; both support byte ranges.
- File integrity: PASS. Anonymous downloads match the local final PDF and approved video byte-for-byte by SHA-256.
- PDF structure: PASS. 34 pages; 42 internal navigation links; 3 public video links; no remaining Google Drive links.
- Table of contents: PASS. Chapters 1-5 resolve to pages 7, 10, 13, 16, and 19. Chapters 6-10 resolve to pages 22, 24, 27, 30, and 33.
- Interactive viewer: PASS. Loaded all 34 pages at a 390 x 844 phone viewport with the sidebar closed and page-width scaling.
- Live link test: PASS. A chapter-1 contents link opened page 7; the chapter-10 contents link opened page 33.
- Video playback: PASS. The public video loaded at the phone viewport, reported H.264/AAC at 1280 x 720, duration 452.533696 seconds, ready state 4, and was actively playing.
- Visual preservation: PASS. All 34 pages rendered pixel-identically before and after the hyperlink replacement.

## Local final output

`04_OUTPUT/BonesAndHoes_Monetization_Atlas_Public_Interactive.pdf`
