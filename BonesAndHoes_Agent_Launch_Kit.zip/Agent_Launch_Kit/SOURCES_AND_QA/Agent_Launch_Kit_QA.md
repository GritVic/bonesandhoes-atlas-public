# BonesAndHoes Agent Launch Kit — Release QA

**Release date:** 2026-08-24  
**Package:** `BonesAndHoes_Agent_Launch_Kit.zip`  
**Public endpoint:** https://gritvic.github.io/bonesandhoes-atlas-public/BonesAndHoes_Agent_Launch_Kit.zip

## Corpus and structure

- Curated output uses the reconciled clean corpus, final reader manuscript, final public Atlas, Further Resources companion, and final public-delivery QA.
- Superseded manuscripts, failed generations, scratch assets, duplicate reports, editable production binaries, temporary renders, and the stale prepublication checklist were deliberately excluded.
- The controlling README, launch prompt, master context, working-state template, manifest, and Atlas are at the package root.
- Detailed evidence is routed into `RESEARCH/`, `DIRECTORIES/`, `RESOURCES/`, and `SOURCES_AND_QA/`.

## Structured-data validation

- All seven CSV files parse with a consistent column count within each file.
- State records reconcile to 50 unique states across 17 + 17 + 16 non-overlapping rows.
- The federal/DC/tribal/land directory contains 12 rows.
- The Expo directory contains 58 rows.
- The networking directory contains 61 rows.
- The content and sourcing directory contains 44 rows.

## Atlas validation

- PDF pages: 34.
- Internal navigation annotations: 42.
- External video links: 3, all targeting the public approved video.
- Private Google Drive video links remaining in the PDF: 0.
- Existing publication QA verifies mobile page-width rendering, chapter destinations, public video playback, correct media types, byte-range support, and pixel identity with the approved source.
- A release contact-sheet review showed no missing pages or obvious page-level rendering failure.

## Package integrity and portability

- Standard ZIP with one obvious top-level `Agent_Launch_Kit/` folder.
- ASCII-only filenames, no unsafe traversal paths, and maximum archived path length under 110 characters.
- ZIP integrity passes both `unzip` and Python standard-library validation.
- macOS Archive Utility-compatible extraction passes.
- The human quick-start provides a fallback for agents that cannot inspect ZIP attachments.
- Anonymous requests using iPhone, Android, and macOS browser identifiers return HTTP 200 and a ZIP media type.
- A downloaded anonymous copy extracts successfully and matches the locally published ZIP hash.

## Content-safety validation

- No absolute local home-directory paths or local-file URI dependencies occur in the portable text corpus.
- No credentials or authentication material are included.
- No prohibited literal niche wording occurs in the package.
- Private project-document URLs retained in provenance records are historical evidence only and are not required to operate the package.
- Current facts, dated snapshots, hypotheses, and unresolved questions are explicitly distinguished.

## Fresh-agent behavior validation

Three independent clean-room agents were given only the package and launch prompt.

All tests confirmed that the receiving agent can:

- find and follow `AGENT_README.md`;
- understand the authentic project-to-commerce model;
- avoid a generic archive dump;
- welcome Anna and Haley energetically;
- offer the required concise starting menu;
- ask exactly one onboarding question;
- treat the community hub as strategic;
- preserve the bootstrap and no-inventory launch sequence;
- distinguish dated research from current operational facts;
- maintain progress through the working-state file;
- require approval before external actions.

The adversarial review identified and the final directory resolves:

1. precise prohibited-language control without printing the literal term;
2. explicit first-launch working-state creation;
3. authority for the newest owner-maintained working state;
4. a copyable-Markdown fallback when an agent cannot create files;
5. explicit checksum-file coverage in the manifest;
6. clearer verification labels for volatile synthesized claims.

## Genuine limitations

- Some AI products cannot inspect a ZIP directly. Anna and Haley must extract it and attach the four controlling files first, as explained in the human guide.
- No prompt can guarantee permanent behavior after a model loses context. The controlling README and portable working-state file are the recovery mechanism.
- Platform requirements, supplier terms, prices, events, and legal information remain time-sensitive and require current verification.
- Historical private project links in provenance files may require owner access, but no such link is required for the operating workflow, Atlas, video, or package download.

## Release gate

Release is approved only after the final rebuilt ZIP replaces the public copy, the anonymous downloaded hash matches the local final file, and Google Messages shows the delivery state for the direct package link.
