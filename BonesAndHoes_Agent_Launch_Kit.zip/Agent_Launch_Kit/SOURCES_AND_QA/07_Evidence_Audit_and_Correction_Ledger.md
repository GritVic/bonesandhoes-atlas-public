# BonesAndHoes Evidence Audit and Correction Ledger

**Audit date:** August 18, 2026  
**Audience:** Anna and Haley  
**Scope:** The seven controlling documents and sixteen supporting research/data files in the clean NotebookLM package  
**Purpose:** Confirm whether the corpus is ready to support a private, opportunity-led market Atlas and operating roadmap.

## Verdict

The corpus is ready for final strategy synthesis with the corrections and precedence rules in this ledger. It contains enough evidence to explain the business model, content engine, commerce sequence, product universe, networking system, Expo plan, unit-economics gates, 90-day roadmap, and legal-navigation companion.

The remaining unknowns do not prevent publication of the strategy. They are operating inputs that Anna and Haley must verify in live accounts, supplier conversations, customer interviews, and jurisdiction-specific situations. They must be shown as decision gates, not silently converted into facts.

## Source-ingestion and structural check

- All 23 clean-package sources were visibly imported into the separate NotebookLM notebook.
- The source list contains seven controlling Markdown documents, eight research reports, and eight structured CSV resources.
- The three state tranches cover exactly 50 unique states: 17 Alabama–Kentucky, 17 Louisiana–North Dakota, and 16 Ohio–Wyoming.
- CSV structure was validated: the Expo directory has 58 records and 25 fields; the networking directory has 61 records and 20 fields; the content-resource file has 44 records and 17 fields; every state tranche has the expected state count and a consistent row width within its own file.
- Direct sources and access dates are present throughout the research package. Unresolved legal questions are labeled rather than inferred.
- No older NotebookLM-created asset is included in the clean package.

## Material contradictions and their resolution

| Priority | Issue | Resolution for the Atlas |
|---|---|---|
| High | Square public pages show two different online-processing rates: an earlier 2.9% + $0.30 and a newer 3.3% + $0.30 for the Free tier. | Do not print one as permanent. State that Square Free has no monthly platform fee, model with the conservative current figure, and verify the live account rate before launch. |
| High | TikTok's own pilot guidance contains inconsistent posting descriptions for smaller eligible affiliate creators. | Treat the in-app quota as controlling. Do not build a publishing calendar around a quoted limit until the account shows the current rule. |
| Medium | The Expo's live schedule language describes 40 cities across the United States, Canada, and Australia, while an earlier project source separated North American cities and Australian dates. | Use the live organizer schedule for planning and avoid a headline tour count until the organizer confirms it. The verified vendor census remains useful regardless. |
| Medium | Platform fees, eligibility, affiliate rates, and seller rules can change after the research date. | Put a verification date beside operational platform facts and require an account-level check before launch. |
| Medium | Legal state files use 18 fields in one tranche and 19 in the other two. | This is a schema-normalization issue, not a coverage failure. Use the Legal Navigation Master as the reader-facing index and preserve the source files as evidence. Normalize fields when building the later public guide. |

## Weak, directional, or unsupported claims

The following evidence may guide testing but must not be presented as proven demand or a forecast:

- marketplace result counts, review counts, listing prices, and visible assortment;
- the current price ladder for finished work and display products;
- the hypothesis that modular display infrastructure is the strongest later owned-product opportunity;
- affiliate, digital-product, and supplier-direct revenue scenarios;
- supplier willingness to authorize direct fulfillment, provide wholesale pricing, or meet service levels;
- the likely conversion value of any creator, platform, content series, product collection, or event;
- audience size and demand intensity without first-party account analytics;
- any state legal path explicitly marked unresolved;
- product safety, compatibility, and shipping performance before practical testing.

These claims are already labeled as observations, planning cases, hypotheses, or unresolved questions in the controlling documents. The final Atlas must preserve those labels.

## Duplication and overweighting

### Intentional duplication

The same strategic decisions recur in the blueprint, roadmap, commerce playbook, content playbook, and QA file. This repetition establishes precedence for synthesis; it should not be reproduced verbatim in the designed Atlas.

The final Atlas should state each core decision once, then use later chapters for examples, numbers, and actions.

### Legal overweighting risk

Eight of the 23 imported sources are detailed legal reports or CSVs. They are necessary evidence for the separate legal navigator but have more text volume than their role in the market strategy warrants.

For final strategy synthesis:

- use `06_Legal_Navigation_Master.md` as the only active legal source;
- keep the detailed state, federal, District of Columbia, and tribal files in the notebook for legal-companion queries;
- limit the main Atlas to a short enabling decision sequence, provenance habits, and a link to the separate guide.

### Directory overweighting risk

The Expo and networking directories are operational artifacts, not narrative chapters. The main Atlas should show the patterns, first outreach queue, interview priorities, and relationship chains. Full records belong in linked companion resources.

## Blueprint coverage

| Blueprint chapter | Evidence status | Controlling source |
|---|---|---|
| Opening advantage | Supported | `00`, `01`, `03` |
| Opportunity map | Supported | `00`, `01`, products research |
| Business model | Supported | `01`, `02`, commerce research |
| Product universe | Supported | `02`, products research |
| Content engine | Supported | `03`, content library |
| Creator and relationship network | Supported | `03`, networking report and directory |
| Expo intelligence | Supported | `03`, Expo report and directory |
| Where and how to sell | Supported | `02`, commerce research |
| Economics of starting small | Supported with planning labels | `02`, commerce research |
| 90-day roadmap | Supported | `01`, `02`, `03` |
| One-year expansion map | Supported | `00`, `01` |
| Legal-navigation companion | Supported with explicit unresolved fields | `06`, four legal research packages |

## Strategic-alignment check

The clean controlling corpus is aligned with the owner's direction:

- Anna and Haley are the controlling audience.
- The emotional center is opportunity, confidence, and ordered action.
- The company starts as project media, trusted curation, creator network, and no-inventory commerce.
- Products appear naturally inside authentic projects and are offered as compatible choices, not a forced uniform package.
- Broad inventory is delayed until demand and fulfillment are proven.
- Creator features use permission, credit, correction, and value-first outreach.
- Expo work is treated as market intelligence, content acquisition, and relationship building.
- Legal material protects the opportunity without consuming the main narrative.

## Missing evidence versus owner decisions

### Research and operating evidence still to gather

- live TikTok, Etsy, Payhip, Square, Shopify, affiliate-program, and marketplace eligibility and fee screens;
- current account analytics and audience geography;
- approved affiliate and supplier terms;
- supplier quotes, service levels, return allocation, and written authorization;
- observed clicks, conversions, returns, and contribution after launch;
- customer interviews on display problems, acceptable prices, and missing sizes;
- prototype testing for any later owned product;
- written agency answers for legal fields that remain unresolved.

### Decisions only Anna and Haley can make

- which public account and identity lead the launch;
- role ownership between the two founders;
- the first five project types;
- the first free guide and paid digital tool;
- willingness to appear on camera and conduct interviews;
- weekly production capacity;
- the acceptable boundaries for subject matter, imagery, sponsorships, and commercial relationships;
- the amount of money, if any, available after evidence justifies spending;
- timing of Etsy, owned checkout, events, and later product development.

## Correction ledger

| Severity | Correction | Action | Status |
|---|---|---|---|
| Critical | Prevent legal volume from becoming the Atlas narrative. | Use the Legal Navigation Master for strategy synthesis; reserve detailed files for the companion. | Applied as corpus-control rule |
| High | Resolve variable platform facts. | Date and re-verify fees, eligibility, limits, and policies in live accounts before execution. | Applied as operational gate |
| High | Prevent planning economics from appearing as forecasts. | Keep every scenario labeled and replace assumptions with observed results after launch. | Applied |
| High | Prevent marketplace observations from appearing as demand proof. | Use them for vocabulary, taxonomy, price ladders, and test design only. | Applied |
| Medium | Resolve Expo tour-count inconsistency. | Use the live schedule operationally; confirm any headline count with the organizer. | Applied |
| Medium | Normalize legal fields for public release. | Map all state records to the reader-facing master schema before publishing the separate legal guide. | Deferred to legal-guide production |
| Medium | Prevent directories from bloating the book. | Publish patterns and priority queues in the Atlas; link the full CSV companions. | Applied |
| Medium | Keep owner choices visible. | Present unresolved owner decisions as decision boxes in the roadmap. | Applied |
| Low | Refresh volatile local-resource and product details. | Verify hours, inventory, price, availability, and filming permission before each production day. | Applied as recurring workflow |

## NotebookLM service verification

The clean notebook accepted and displayed all 23 sources and generated an aligned notebook-level summary. Multiple text-audit attempts, including a final one-source two-sentence test, stalled or returned a service error on August 18, 2026. No Studio feature was used.

Because ingestion was verified but generation was not dependable, the final audit and synthesis were completed against the same local/Drive source files. This ledger is the controlling correction source for future NotebookLM runs. When text generation is available again, the next run should use the seven controlling documents, the principal commerce/product/content/network/Expo reports, and this ledger; detailed legal files should remain deselected unless the query is specifically about the legal companion.

## Freeze decision

The strategy corpus may be frozen when the final synthesis:

1. names Anna and Haley as its readers;
2. leads with the project-to-supply opportunity;
3. keeps products choice-rich and tied to real project jobs;
4. sequences channels and inventory by evidence;
5. includes the content, network, Expo, economics, and roadmap systems;
6. labels volatile facts, scenarios, and unresolved questions;
7. keeps legal detail in the companion layer;
8. contains no new Studio-generated asset.

