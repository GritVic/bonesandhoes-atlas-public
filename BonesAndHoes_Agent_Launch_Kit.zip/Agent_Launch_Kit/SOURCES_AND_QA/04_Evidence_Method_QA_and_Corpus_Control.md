# BonesAndHoes Evidence Method, QA, and Corpus Control

## Purpose

This document controls how NotebookLM and the Atlas production process should interpret the source package. It prevents older framing, duplicated text, weak evidence, and supporting legal detail from overpowering the actual business strategy.

## Intended audience and decision

The reader is Anna and Haley. The decision is how they should launch, monetize, measure, and expand BonesAndHoes.

The main narrative priority is:

1. market opportunity;
2. authentic content and audience demand;
3. project-supporting product ecosystem;
4. commerce-channel sequence;
5. creator relationships and events;
6. operating roadmap and economics;
7. legal and safety guardrails.

Legal and safety material must remain accurate and visible, but it must not become the emotional or structural center of the Atlas.

## Corpus inclusion rules

Use:

- the approved Master Atlas Blueprint;
- the clean Strategy and Operating Roadmap;
- the clean Commerce, Product, and Merchandising Playbook;
- the clean Content, Networking, and Expo Playbook;
- the completed current research reports and structured directories;
- the completed federal and 50-state legal navigation package;
- this control document.

Do not use:

- earlier NotebookLM slide decks, infographics, reports, mind maps, audio, or video as evidence;
- the old compiled Master Plan;
- duplicated older NotebookLM source copies;
- older narrative conclusions where the clean documents explicitly replace them;
- presentation wording generated for outsiders.

The old material may be preserved in Drive as historical work, but it is not part of the clean synthesis corpus.

## Source authority order

When sources conflict, use this order:

1. Current controlling government or platform source for law, policy, eligibility, fees, and procedure.
2. Current manufacturer, retailer, event, creator, or organization first-party source for its own products, programs, dates, and public claims.
3. Direct public observation such as current product price or marketplace listing.
4. Credible secondary reporting.
5. Community discussion as a demand signal only.
6. Planning assumption or strategic interpretation, clearly labeled.

No lower class may overrule a higher controlling source.

## Required evidence labels

- **Verified primary:** directly supported by a controlling government or platform source.
- **Observed first party:** the relevant organization or creator states it publicly.
- **Current market observation:** a dated product, price, listing, or public offer observation.
- **Demand signal:** repeated questions, search vocabulary, comments, or public community behavior; not population-representative.
- **Planning assumption:** a transparent input used for a scenario or gate.
- **Strategic recommendation:** an interpretation based on the assembled evidence.
- **Unresolved:** the controlling answer was not located or remains ambiguous.

## Claim rules

- Do not equate a marketplace result count, review count, or visible popularity signal with sales.
- Do not treat an affiliate maximum rate as the expected rate for every product.
- Do not use a platform fee or eligibility rule without its verification date.
- Do not imply supplier-direct fulfillment until written terms exist.
- Do not use a creator’s sourcing statement as independently verified legal provenance.
- Do not infer permission from regulatory silence.
- Do not turn planning scenarios into revenue forecasts.
- Do not imply institutional endorsement of a commercial product.
- Distinguish acquisition, possession, personal use, transfer, commerce, land access, and interstate movement.
- Preserve uncertainty where the evidence does not resolve a claim.

## Current evidence inventory

### Commerce channels and economics

Evidence package includes 39 direct primary-source URLs, a ranked channel matrix, detailed TikTok and Etsy setup paths, other-channel playbooks, three unit-economics models, launch gates, measurement, and caveats.

Important current conclusion: use affiliate and digital channels first; add supplier-direct and owned checkout after evidence; delay marketplace seller obligations until fulfillment is proven.

### Products, suppliers, and merchandising

Evidence package includes more than 50 price and product observations, more than 25 project or format observations, 25 supplier or partner records, product taxonomy, affiliate and wholesale paths, provisional economics, market gaps, and a 90-day research plan.

Material limitation: the initial directive’s larger product and creator record targets were not fully reached. The strategy is supported, but the live product database should continue expanding before external publication.

### Audience, creators, and content

Evidence package includes audience segments, recurring questions, project taxonomy, permission workflow, one-project content flywheel, creator examples, partnership tiers, content series, and a 90-day sequence.

Material limitation: community questions are demand signals, not market sizing or audience-representative survey evidence.

### Expo vendor intelligence

The working directory contains 58 records with 25 fields: 48 directly verified current vendors plus instructors, partner, organizer, and clearly labeled discovery or historical records. Every row contains a source and access date.

Material limitation: no stable complete official city roster was located. The directory is substantial but not exhaustive, and private vendor economics are unknown.

### Networking

The working directory contains 61 curated entities with 20 fields and 25 ranked priorities. The report identifies seven clusters, connector nodes, relationship chains, interview targets, permissions, CRM, and a 30-day activation plan.

Material limitation: public contact routes and publicly evidenced connections do not imply consent or an existing relationship.

### Content and regional sourcing

The package includes 26 verified resource records and 18 complete content-series records, including Expo capture, permission, regional sourcing, search vocabulary, safety screen, and measurement.

Material limitation: inventories, store hours, sale locations, platform feeds, and filming permissions change and require live confirmation.

### Legal navigation

The legal package separates federal, District of Columbia, tribal, land, and 50-state routing. Each state record identifies the topics researched, primary URLs, confidence, unresolved ambiguity, and next verification action.

Material limitation: a state section with unresolved topics is a navigation record, not a statement of permission. Every public version needs a current date, correction route, and non-legal-advice statement.

## Reconciled strategic decisions

### Decision 1: what BonesAndHoes sells first

Digital organization, trusted recommendations, and complete project supply paths—not inventory breadth.

### Decision 2: what creates attention

Authentic discovery, process, artistic transformation, distinctive sourcing, creator stories, and finished results.

### Decision 3: what creates scalable commerce

The supporting project ecosystem and later difficult-to-find display infrastructure.

### Decision 4: how the catalog is organized

By project outcome and workflow stage, with multiple compatible choices.

### Decision 5: how channels are sequenced

Affiliate and digital first; narrow marketplace tests; owned checkout and authorized suppliers after demand; seller marketplaces and inventory later.

### Decision 6: how networking works

Permission-cleared value creation, five-at-a-time outreach waves, completed proof, warm introductions, and disciplined follow-up.

### Decision 7: how legal material is positioned

As a separate free decision navigator and a supporting trust layer, not the Atlas’s dominant narrative.

## Pre-NotebookLM QA gate

The corpus passes only when:

- all intended files are final and uniquely named;
- no old generated Studio asset is included;
- no old compiled plan or duplicated specialist copy is included;
- all major strategy sections speak directly to Anna and Haley;
- monetization and execution dominate the main narrative;
- specific claims preserve their source or source-report path;
- observations, assumptions, and recommendations are distinct;
- legal detail is separated into the companion guide;
- the source manifest identifies every file and its role;
- terminology and positioning follow the owner’s explicit direction;
- all local files pass a prohibited-term scan;
- all CSV files have a consistent header and row count appropriate to their scope.

## NotebookLM text-only instructions

NotebookLM must not generate Studio assets during this phase.

First audit the complete clean corpus for:

- contradictions;
- unsupported or weak claims;
- duplicated recommendations;
- obsolete platform information;
- inconsistent numbers;
- unanswered owner decisions;
- sections that speak to outsiders instead of Anna and Haley;
- excessive legal emphasis;
- missing links between content, product, channel, network, and roadmap.

Then produce a text-only strategy synthesis organized around:

1. the opportunity;
2. the operating thesis;
3. priority audience needs;
4. product and merchandising system;
5. commerce-channel sequence;
6. content engine;
7. creator, supplier, and event network;
8. economics and decision gates;
9. 90-day and one-year roadmap;
10. unresolved owner decisions and evidence gaps.

Every finding must cite the imported sources. When the clean strategy documents and a raw research report appear to conflict, identify the conflict and prefer the more current, better-supported conclusion rather than blending both.

## Corpus-freeze criteria

The content corpus is frozen only after:

- the NotebookLM audit is reviewed;
- material contradictions are corrected in the source documents;
- the corrected sources are reimported or refreshed;
- the final synthesis matches the approved blueprint;
- no major chapter is missing;
- legal material remains proportionate;
- open questions are visible rather than silently guessed;
- all source counts and file identities are verified;
- the final corpus manifest is dated and saved.

Only after this freeze may visual, audio, video, slide, mind-map, report, infographic, or data-table generation begin.
