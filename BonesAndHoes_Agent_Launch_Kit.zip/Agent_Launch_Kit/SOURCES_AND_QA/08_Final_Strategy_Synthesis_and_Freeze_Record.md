# BonesAndHoes Final Strategy Synthesis and Freeze Record

**Version:** Text Corpus 1.0  
**Frozen:** August 18, 2026  
**Readers:** Anna and Haley  
**Next phase after owner review:** editorial design and visual-production planning

## The business to build

BonesAndHoes should become the most useful bridge between an authentic project and everything required to complete it well.

The scarce asset is not a large catalog. It is Anna and Haley's real access to discovery, preparation, artistic judgment, problem-solving, distinctive materials, finished work, and a visually compelling creative world. That creates trust and attention. Commerce belongs around the project: the supports, substrates, stands, enclosures, tools, consumables, finishes, lighting, documentation, photography, storage, and packing that viewers need after inspiration becomes intent.

The launch model is therefore:

1. document authentic work;
2. teach the decisions that make the work possible;
3. credit and connect the people who expand the field;
4. organize complete, choice-rich supply paths;
5. earn through digital tools and approved recommendations;
6. add authorized supplier-direct retail after demand and fulfillment are proven;
7. develop difficult-to-find owned products only after repeated measured need.

This is a bootstrapped media-and-commerce system. Broad inventory is the last move, not the first.

## The opportunity map

Five audiences create the initial opportunity:

- curious beginners need confidence, sequence, and a safe starting point;
- new processors need troubleshooting, discipline, and clear stopping points;
- display-focused collectors need stability, protection, proportion, lighting, and care;
- artists and makers need aesthetic freedom plus reliable construction options;
- working creators and vendors need discovery, peer relationships, supply intelligence, and operational learning.

The shared market problem is fragmentation. Inspiration, legal routing, preparation knowledge, project design, display engineering, and product sourcing live in different places. BonesAndHoes creates value by connecting them without dictating one aesthetic or one package.

## What to sell, and in what order

### First: free trust tools

- dated legal-navigation guide linked to official sources;
- project documentation record;
- secondhand and salvage-search vocabulary;
- display measurement sheet;
- selected supplier, creator, and event directories.

These tools answer real questions, capture email interest, and reveal what the audience wants next.

### Second: low-cost digital tools

- project journal and progress record;
- display-design planner;
- pricing and packing worksheet;
- sourcing and vendor comparison workbook;
- creator interview and capture system.

These are high-margin tests of whether people will pay for organization, saved time, and confidence.

### Third: approved recommendations

Every recommendation must belong to a demonstrated job inside a real project. Collections should be organized both by outcome and by workflow stage, with economical, refined, and premium choices where useful.

### Fourth: authorized supplier-direct commerce

Add physical products only under written commercial terms covering price, inventory accuracy, handling time, packaging, returns, damage, warranties, product information, customer service, and termination. A supplier-direct model is not permission to buy from a public retailer after receiving the customer's order.

### Fifth: later owned products

The strongest current hypothesis is refined modular display infrastructure: discreet stands, rods, adapters, bases, enclosure systems, removable mounting inserts, provenance systems, and fragile-art packing systems. Advance no concept without 90 days of behavior, at least 20 relevant interviews, three supplier quotes, margin modeling, compatibility review, and practical testing.

## The product universe

Organize the future shop two ways.

### By project outcome

- dome and cloche displays;
- shadow boxes and framed work;
- tabletop and wall displays;
- jewelry and wearable work;
- botanical, mineral, and mixed-media compositions;
- carved, painted, and finished art;
- photography and listing setup;
- studio storage, labeling, packing, and shipping.

### By workflow stage

- document and handle;
- prepare safely;
- drill, shape, and finish;
- build and attach;
- display and protect;
- photograph and publish;
- store and ship.

Every product card should explain the exact job, compatibility, measurements, selection reason, price and verification date, merchant and fulfillment source, shipping and return notes, commercial relationship, safety or policy flags, alternatives, and testing status.

## The content engine

One project should create a full narrative and commerce cycle:

1. lawful discovery or sourcing context;
2. initial documentation and decisions;
3. preparation progress and setbacks;
4. competing artistic directions;
5. the search for a distinctive support or substrate;
6. construction and display engineering;
7. the finished reveal;
8. the complete supply path;
9. care, maintenance, storage, or packing follow-up.

That single record can become short video, long-form video, email, Pinterest material, a project page, a supply collection, an Atlas example, and a creator spotlight.

Priority series are:

- **Found, Chosen, Made:** the complete discovery-to-finished-work story;
- **Treasure Routes:** sourcing supports through thrift stores, reuse centers, estate sales, yard sales, auctions, local marketplaces, and free listings;
- **Search Like a Set Designer:** exact vocabulary for finding unusual supports;
- **One Find, Three Directions:** multiple creative paths from one object;
- **Display Engineering:** stability, proportion, enclosures, lighting, and care;
- **The Tool Earned Its Place:** a product introduced through genuine use;
- **Booth Anatomy:** how Expo vendors present, price, bundle, and sell;
- **What the Vendor Learned:** concise operator interviews;
- **Make It, Price It, Pack It:** the economics and logistics behind finished work;
- **Maker-to-Maker Chain:** one creator introduces the next.

Products should appear nonchalantly when they have earned a role: viewers who want the same tools or materials can find the complete list below the content.

## The relationship engine

Networking is an operating system, not a contact list. Work across seven clusters: creators and educators; Expo and event operators; suppliers and brands; retailers and marketplaces; reuse and regional-resource nodes; legal and subject-matter authorities; and media or community connectors.

Use five-at-a-time outreach waves. Offer something useful before asking for reach, products, or introductions. Every feature requires permission, accurate credit, a correction route, and a defined follow-up. A completed relationship should produce a useful audience story, visible value for the participant, a project/material record, one next introduction, and performance feedback where appropriate.

The verified networking directory contains 61 curated entities and a ranked first-25 queue. The full directory remains a companion artifact; the Atlas should show the clusters, connector nodes, first outreach sequence, and practical relationship chains.

## The Expo intelligence system

The Expo is a compressed market laboratory. The verified directory contains 58 records, including 48 directly verified 2026 vendors plus instructors, partners, the organizer, and clearly labeled discovery leads.

Attend as an editorial and market-intelligence team. Before the event, secure permissions, rank interview candidates, prepare questions, define the observation grid, and schedule follow-up. During the event, capture product families, price bands, display systems, packaging, workshops, wholesale signals, repeat-tour patterns, customer questions, and introductions. Afterward, publish the strongest stories, return useful clips or links to participants, record follow-ups, and connect each observation to a content, product, supplier, or relationship hypothesis.

Public vendor behavior already reveals useful models: partner-booth distribution, wholesale and stockists, workshop bundling, timed drops, service revenue, and collective-store touring. Treat these as examples to investigate, not formulas to copy.

## Where to sell

The channels have different jobs and should open in sequence.

1. **Payhip:** free guide, email capture, and paid digital tools immediately.
2. **Approved affiliate programs:** broad recommendations used inside projects.
3. **TikTok Shop Creator Affiliate:** native product testing when the account qualifies.
4. **Etsy:** a narrow set of qualifying original digital, artistic, and supply offers after the first content proof.
5. **Square Free:** a low-cost owned checkout bridge when buyers show intent outside marketplaces.
6. **Shopify:** only when authorized supplier-direct synchronization or multichannel operations justify its recurring cost.
7. **Pinterest, Google, Meta, and YouTube Shopping:** discovery layers after the owned catalog and policies are stable.
8. **TikTok Shop Seller:** only after inventory ownership and fulfillment compliance are proven.
9. **eBay, Amazon Handmade, and Faire:** later, for narrow use cases that fit their economics and rules.

All live fees, eligibility, posting limits, category rules, and account requirements must be rechecked at execution.

## Economics and spending gates

Affiliate scenarios are demand-sensing models, not forecasts. Digital products are attractive early because their direct costs are low, but they still require accuracy, design, maintenance, and customer support. A supplier-direct physical order should clear at least 15% modeled contribution before owner labor, with 20% as the normal target. Later owned difficult-to-find products should target 30% or more.

Do not pay for a platform to look established. Add it when attributable monthly gross profit exceeds roughly three times the recurring platform cost or when its operating value clearly saves more than it costs.

Optimize:

- contribution per qualified view;
- contribution per order;
- qualified clicks and saves;
- email opt-ins;
- attributed transactions;
- repeat questions;
- product-family conversion;
- supplier response quality;
- creator relationships and warm introductions;
- returns, damage, and fulfillment failures.

## The first 90 days

### Days 1–7: establish the operating foundation

- choose the primary public account and record baseline analytics;
- choose five initial project types;
- choose one free guide and one paid digital tool;
- assign responsibility for content, research, outreach, and source review;
- create the product ledger, relationship CRM, content record, tagged links, permission templates, and correction workflow.

**Gate:** all systems exist and one complete project is selected.

### Days 8–30: publish proof

- publish the free guide and paid digital tool;
- apply to suitable affiliate programs;
- build a 50-product recommendation library tied to real jobs;
- publish 12 content units across one project cycle;
- begin five creator or regional-resource conversations;
- log questions from comments, messages, and searches.

**Gate:** 100 qualified outbound product clicks, reliable attribution, one complete project-to-supply page, and one permission-cleared feature. If traffic is weak, improve content and distribution before adding a store platform.

### Days 31–60: test demand and relationships

- publish a second project cycle;
- launch 6–12 qualifying Etsy listings;
- contact 25 manufacturers or brands for affiliate, wholesale, or authorized supplier-direct terms;
- complete two outreach waves;
- publish a Treasure Routes episode;
- compare economical and premium display paths;
- prepare Expo permissions and interviews when timing applies.

**Gate:** 10 attributed transactions, three product families showing independent interest, recorded supplier responses, two creator features, and two warm introductions.

### Days 61–90: choose the scalable path

- enter TikTok creator affiliate commerce if eligible;
- decide whether Payhip remains sufficient or owned checkout is justified;
- choose Square unless Shopify's supplier-direct or synchronization value clearly wins;
- score at least 50 potential supplier-direct products without publishing any that fail fulfillment or margin gates;
- rank the top 25 products by behavior and operating risk;
- complete 20 interviews about missing sizes, display problems, enclosures, materials, and acceptable price;
- choose no more than two later product concepts for deeper validation.

**Gate:** three independently converting product families, no unresolved fulfillment issue for direct sales, a documented store-timing decision, and a ranked quarterly backlog.

## Months 4–12

Months 4–6: add an owned checkout only when triggered; test a small authorized supplier set; add discovery feeds after catalog quality is stable; complete the first Expo or regional-market intelligence cycle; prototype one display component only if every gate is met.

Months 7–12: expand proven project collections; deepen creator chains; repeat the strongest content formats; build supplier redundancy; consider wholesale or event participation only after contribution and production capacity are visible; prepare a tested owned product for a narrow launch if demand, economics, and operations support it.

## Legal and safety boundary

The main Atlas uses one short decision route: identify the material, determine origin and land authority, check federal and state rules, separate possession from transfer or commerce, preserve provenance, and verify again before movement or publication.

The separate legal package covers all 50 states plus federal, District of Columbia, tribal, land, disease-movement, import, and international overlays. An unresolved field is a direction to contact the authority, never permission. The legal section should enable lawful making and then return the reader to the opportunity.

## Decisions for Anna and Haley

Before production, decide:

1. which public identity and account lead;
2. who owns content, product research, outreach, and verification;
3. the first five project types;
4. the first free and paid digital tools;
5. camera and interview boundaries;
6. weekly production capacity;
7. sponsorship and commercial-relationship boundaries;
8. the maximum evidence-backed spend after the first cycle;
9. the timing of Etsy, owned checkout, events, and later product development.

## The next three moves

1. Select the first complete project and record every decision, product, problem, and visual moment.
2. Build the free guide, paid tool, product ledger, tagged links, and first five outreach messages around that project.
3. Publish the first content cycle, measure qualified behavior, and let the evidence decide which channel and product family earns the next 60 days.

## Freeze record

This synthesis is the controlling text for the next editorial phase. The blueprint, roadmap, commerce playbook, content/network/Expo playbook, evidence method, reconciliation ledger, legal master, and audit ledger remain the supporting control set. Detailed reports and CSV directories remain linked evidence and companion resources.

The corpus is frozen at text-only strategy stage. No infographic, chart, mind map, slide deck, report template, audio, or video was generated in the new NotebookLM. Later visual production must begin only after Anna and Haley review this synthesis and approve the emphasis, chapter order, and owner decisions.

