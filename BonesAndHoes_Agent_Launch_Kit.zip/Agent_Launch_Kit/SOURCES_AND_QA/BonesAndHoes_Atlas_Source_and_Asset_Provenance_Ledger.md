# BonesAndHoes Monetization Atlas — Source and Asset Provenance Ledger

## Publication identity

- Project: **The BonesAndHoes Monetization Atlas**
- Intended readers: Anna and Haley
- Publication format: portrait digital field guide with interactive navigation
- Final publication folder: https://drive.google.com/drive/folders/1rEb0C6Gq2pMwHQj2y2yBmZD8AlOpMJHH
- Controlling specification: https://docs.google.com/document/d/10M4iYFku7OUT-KoStT0t-ulVq4DvNli2nAMKgCtOtKw/edit

## Controlling narrative source

- Locked manuscript: `BonesAndHoes_Monetization_Atlas_Manuscript_v3.md`
- Google Doc: https://docs.google.com/document/d/1_KV2KKBMRdYGpq4SAV8aZvNN7O9i1sYgZ3EgnjPwea0/edit
- Manuscript length at lock: 4,203 words
- Editorial mapping: 20 controlled body pages, with chapter headings and part headings represented by ten chapter opener pages
- Copy rule: every mapped manuscript passage remains represented once in the final body; dense evidence and operational records are routed to Further Resources

## Approved primary media

| Asset | Role | Provenance |
|---|---|---|
| `BonesAndHoes_Monetization_Strategy_Cover_Art_v2_FinalText.png` | Final cover | Owner-approved generated cover art |
| `The_Evidence_Led_Blueprint_Approved.mp4` | Approved explainer video | Owner-selected earlier NotebookLM video |
| `The_Evidence_Led_Blueprint_Poster.png` | Video gateway poster | Extracted from the approved video |
| `01_Opportunity_Ecosystem.png` through `10_One_Year_Expansion_Path.png` | Ten chapter opener infographics | Owner-approved NotebookLM clay infographics |
| `P001_Approved_Opening.*` | Approved opening-page visual reference | Owner-approved NotebookLM slide-deck page |
| `P001_characters.png` and `P001_vignette.png` | Opening-page decorative artwork | Cropped from the approved opening page so the final edition can use exact native copy |
| `P002` through `P020` production pages | Editorial body-page visual system | Controlled one-page NotebookLM generations using only the locked manuscript and page-specific layout direction |

## Research corpus roles

| Research package | Publication role |
|---|---|
| Commerce Channel and Economics Research | Channel order, launch gates, platform roles, contribution logic, and measurement |
| Product, Supplier, and Merchandising Research | Product universe, pricing observations, compatibility, supplier paths, and later product hypotheses |
| Audience, Content, and Legal Research | Audience needs, creator flywheel, partnership routes, and legal-navigation framework |
| Expo Vendor Census and Directory | Verified vendors, monetization patterns, interview targets, and Expo field plan |
| Networking Atlas | Curated relationship map, ranked outreach queue, collaboration paths, permission controls, and CRM workflow |
| Content Opportunity Library | Repeatable series, sourcing routes, interview formats, capture plan, safety screen, and metrics |
| 50-State plus Federal/DC/Tribal Legal Navigation | Primary-source routing, confidence, ambiguity, and next-authority verification actions |
| Clean Corpus Manifest, Evidence Audit, Correction Ledger, and Freeze Record | Claim-level traceability, corrections, source roles, and publication controls |

## Important evidence boundary

The Atlas is a commercialization roadmap, not a legal opinion. Legal records are intentionally routed through a six-question verification process because species, place, acquisition method, intended action, records, and destination can all change the answer. Silence is never treated as permission. Marketplace observations are treated as observations, not proof of demand or sell-through.

## Generated-media quality boundary

NotebookLM editorial pages are flattened visual compositions. Their body copy is compared against the locked manuscript using OCR and human visual review. The final editable master preserves exact manuscript copy in native or controlled text wherever the flattened rendering introduces a material omission, duplication, or error. Minor decorative labels are allowed only when they do not create a new factual claim.

## Final verification record

The companion file `BonesAndHoes_Atlas_Final_QA_and_Completion_Record.md` records final page count, text coverage, link checks, rendering inspection, mobile legibility, artifact hashes, publication links, and any candidly unresolved limitations.
