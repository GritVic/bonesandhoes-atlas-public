# BonesAndHoes Agent Launch Kit Manifest

**Release:** 2026-08-24  
**Research snapshot:** 2026-08-18  
**Package:** `BonesAndHoes_Agent_Launch_Kit.zip`

## Authority levels

- **Controlling:** governs agent behavior.
- **Authoritative synthesis:** reconciled strategic direction for the project.
- **Approved publication:** owner-approved reader-facing artifact.
- **Supporting research:** detailed evidence and operating information.
- **Structured reference:** searchable rows for execution.
- **Provenance/QA:** explains evidence handling, corrections, sources, and verification.

## Root files

| File | Subject | Authority | Intended use | Current verification? |
|---|---|---|---|---|
| `00_READ_THIS_FIRST_ANNA_AND_HALEY.md` | Human quick start | Controlling for setup | Download once and delegate all package handling to ChatGPT | No |
| `01_COPY_AND_PASTE_THIS_PROMPT.txt` | One-sentence activation command | Controlling for activation | Tells ChatGPT to locate, extract, read, and follow the package | No |
| `AGENT_README.md` | Agent operating rules | Controlling | Behavior, onboarding, services, evidence, continuity | No |
| `BONESANDHOES_MASTER_CONTEXT.md` | Consolidated strategic context | Authoritative synthesis | Fast orientation and planning | Verify volatile facts |
| `BONESANDHOES_WORKING_STATE_TEMPLATE.md` | Continuity record | Controlling template | Decisions, accounts, projects, calendar, outreach, commerce, evidence | Continuously update |
| `BonesAndHoes_Monetization_Atlas.pdf` | Mobile-first interactive Atlas | Approved publication | Reader-facing strategy and navigation | Links verified at release |
| `MANIFEST.md` | Package inventory and routing | Controlling index | Find the correct source without reading everything | No |
| `CHECKSUMS_SHA256.txt` | File-integrity hashes | Provenance/QA | Verify every other packaged file after transfer | Regenerate when package contents change |

## RESEARCH/00_Core_Strategy

| File | Subject | Authority | Intended use | Current verification? |
|---|---|---|---|---|
| `00_Master_Atlas_Blueprint.md` | Unified Atlas architecture | Authoritative synthesis | Strategic orientation and module relationships | Verify volatile facts |
| `01_Strategy_and_Operating_Roadmap.md` | Phased business roadmap | Authoritative synthesis | Sequencing, gates, measurement, and operations | Verify platforms and costs |
| `02_Commerce_Product_and_Merchandising_Playbook.md` | Product and channel system | Authoritative synthesis | Curation, product records, channels, and economics | Verified at the 2026-08-18 snapshot; reverify volatile operational claims |
| `03_Content_Networking_and_Expo_Playbook.md` | Content, relationships, and Expo | Authoritative synthesis | Content engine, outreach, interviews, and events | Verify event details |
| `04_Invisible_Lines_and_Growth_Intelligence.md` | Cross-source strategic connections | Authoritative synthesis | Project-intelligence model and ranked experiments | Verified at the 2026-08-18 snapshot; reverify volatile operational claims |
| `05_Final_Reader_Manuscript.md` | Final narrative manuscript | Approved editorial source | Tone, explanations, and reader-facing strategy | Verify volatile facts |

## Detailed research

| Path | Subject | Authority | Intended use | Current verification? |
|---|---|---|---|---|
| `RESEARCH/01_Products_and_Suppliers/Products_Suppliers_Merchandising_Research.md` | Products, prices, suppliers, formats, and later product hypotheses | Supporting research | Product discovery and supplier work | Always verify prices, availability, and terms |
| `RESEARCH/02_Commerce_and_Economics/Commerce_Channel_Economics_Research.md` | Channel requirements, economics, and launch gates | Supporting research | Current channel decisions and models | Always verify platform rules and fees |
| `RESEARCH/03_Content_and_Sourcing/Content_Opportunity_Library.md` | Content series, interviews, local sourcing, rights, and safety | Supporting research | Editorial planning and sourcing work | Verify locations and current details |
| `RESEARCH/04_Expo/Expo_Vendor_Census_and_Monetization_Report.md` | Expo vendors, patterns, interviews, and field plan | Supporting research | Event preparation and market intelligence | Verify roster and dates |
| `RESEARCH/05_Networking/Networking_Atlas_Report.md` | Relationship clusters, sequences, and CRM method | Supporting research | Permission-first outreach and collaboration | Verify current contacts |
| `RESEARCH/06_Legal_Navigation/` | Federal, DC, tribal, land, and all 50 states | Supporting legal-navigation research | Locate current governing authority and unresolved questions | Always verify before acting |

## DIRECTORIES

| File/group | Subject | Authority | Intended use | Current verification? |
|---|---|---|---|---|
| `Expo_Vendor_Intelligence_Directory.csv` | 58 Expo-related records | Structured reference | Rank interviews, vendor research, and follow-up | Verify current participation/contact |
| `Networking_Atlas_Directory.csv` | 61 relationship entities | Structured reference | Build a permission-first relationship queue | Verify current contact/status |
| `Content_Opportunity_Resources.csv` | 26 resources and 18 content-series records | Structured reference | Plan content and regional sourcing | Verify current details |
| `BonesAndHoes_Legal_Navigation_*.csv` | 50 states plus federal/DC/tribal routing | Structured reference | Locate authority, confidence, and next verification action | Always verify before acting |

## RESOURCES

| File | Subject | Authority | Intended use | Current verification? |
|---|---|---|---|---|
| `Digital_Product_and_Lead_Magnet_Library.md` | 18 free and paid resource concepts | Authoritative idea library | Select and test digital offers | Validate demand |
| `PUBLIC_MEDIA_LINKS.md` | Public Atlas and video URLs | Release reference | Viewing and sharing | Verify before public use |

## SOURCES_AND_QA

| File | Subject | Authority | Intended use |
|---|---|---|---|
| `04_Evidence_Method_QA_and_Corpus_Control.md` | Evidence rules and corpus control | Provenance/QA | Evaluate confidence and source quality |
| `05_Corpus_Manifest_and_Reconciliation_Ledger.md` | Corpus inclusion and reconciliation | Provenance/QA | Understand what was preserved, superseded, or corrected |
| `07_Evidence_Audit_and_Correction_Ledger.md` | Claim corrections and caveats | Provenance/QA | Prevent reuse of weak or superseded claims |
| `08_Final_Strategy_Synthesis_and_Freeze_Record.md` | Frozen strategy decision record | Authoritative synthesis | Resolve strategic ambiguity |
| `BonesAndHoes_Atlas_Source_and_Asset_Provenance_Ledger.md` | Publication sources and assets | Provenance/QA | Trace Atlas support and asset origin |
| `Atlas_Public_Delivery_QA.md` | Public PDF/video delivery verification | Provenance/QA | Confirm links, PDF navigation, mobile rendering, and media behavior |
| `Agent_Launch_Kit_QA.md` | Portable-package and fresh-agent release verification | Provenance/QA | Confirm corpus, integrity, portability, behavior, and release gates |

## Deliberately excluded

- Superseded manuscript versions and early strategy drafts.
- NotebookLM experiments, failed generations, abandoned slide decks, and scratch assets.
- Duplicate copies of reports already represented by the curated files.
- Editable production files too large or unnecessary for an advisory agent.
- Raw page renders, contact sheets, extraction remnants, scripts, and temporary QA artifacts.
- The video binary; the verified public stream is linked instead to keep the package compact.
- The stale prepublication completion checklist; the later public-delivery QA is authoritative for the released Atlas.

These exclusions preserve substantive evidence while preventing an unfamiliar agent from confusing working artifacts with approved strategy.
