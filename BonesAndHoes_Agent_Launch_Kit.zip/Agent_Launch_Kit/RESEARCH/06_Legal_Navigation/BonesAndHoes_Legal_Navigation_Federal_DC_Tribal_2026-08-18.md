# BonesAndHoes Legal Acquisition and Personal-Use Navigation Guide

## Federal overlays, District of Columbia, and tribal-jurisdiction routing

**Verification date:** August 18, 2026  
**Scope of this tranche:** Federal protections and movement rules; federal land; District of Columbia; tribal-jurisdiction routing.  
**Status:** Source-grounded publication input. State-by-state entries are separate research work.  
**Important:** Educational navigation only, not legal advice. Rules depend on species, origin, cause of death, exact land jurisdiction, documentation, intended use, recipient, destination, and current agency interpretation.

## The controlling sequence

Never begin with “May I keep this?” Begin with:

1. **What is it?** Confirm species or at least rule out protected categories.
2. **Where exactly is it?** Private property, state land, tribal land, National Park Service unit, national wildlife refuge, National Forest System land, BLM land, or another jurisdiction?
3. **How did it enter the situation?** Lawful harvest, vehicle collision, naturally found remains, shed antler, permitted transfer, purchase, import, or unknown?
4. **What action is proposed?** Photograph, touch, move for safety, acquire, possess, prepare, display, gift, sell, ship interstate, import, or export?
5. **Which overlays apply?** Federal species protection, state law, tribal law, land-manager rules, public-health rules, disease movement restrictions, and property-owner permission can coexist.
6. **What documentation is required?** Permit, salvage authorization, tag, registration, receipt, statement of origin, transfer record, agency confirmation, or no authorization available?

Silence is not permission. If the controlling source does not answer the exact action, leave the item in place and contact the responsible agency.

## Federal rule map

### 1. Migratory birds

The U.S. Fish and Wildlife Service Feather Atlas states that possession of feathers and other parts of native North American birds protected by the Migratory Bird Treaty Act is prohibited without authorization. Species must be checked against the current protected list rather than identified by an informal “songbird” or “raptor” category.

Beginning December 31, 2024, 50 CFR 21.16 allows opportunistic pickup of a migratory bird found dead—including parts, feathers, nonviable eggs, and inactive nests—but only for donation or destruction under stated conditions. The general-public authorization does **not** allow personal retention. Salvaged material must be donated to an authorized recipient or destroyed within seven calendar days; eagle material has additional requirements. Research and permanent collection remain permit-based.

**Navigation result**

- **Found feather or bird part:** Do not treat it as a personal keepsake merely because it was found.
- **Temporary pickup:** Consult the current regulatory authorization and state/local rules; donation or disposal conditions apply.
- **Personal display or art use:** Not authorized by the general salvage provision.
- **Educational/scientific collection:** Route to the appropriate federal permit and qualified institution.
- **Sale, barter, gifting, or transfer:** Do not proceed without explicit authorization governing the species, holder, and recipient.

Primary sources:

- [FWS Feather Atlas: Feathers and the Law](https://www.fws.gov/lab/featheratlas/feathers-law.html)
- [FWS authorized activities without an individual permit](https://www.fws.gov/program/migratory-bird-permits/authorized-activities-no-permit-required)
- [FWS regulatory authorization for salvage](https://www.fws.gov/media/regulatory-authorization-salvage-migratory-birds)
- [FWS permit types and forms](https://www.fws.gov/program/migratory-bird-permits/permit-types-and-forms)

**Confidence:** High.  
**Next check before publication:** Confirm 50 CFR 10.13 species status and the current text of 50 CFR 21.16.

### 2. Bald and golden eagles

Eagles, their feathers, and their parts receive additional protection under the Bald and Golden Eagle Protection Act as well as the Migratory Bird Treaty Act. The National Eagle Repository states that personal possession is generally unlawful. A member of the public who encounters a dead eagle or part should not salvage it and should report it to the state wildlife agency or FWS.

The National Eagle Repository provides a distinct religious-use route for eligible enrolled members of federally recognized Tribes. Repository permits and materials have their own eligibility, possession, transfer, and noncommercial limits. A federal Tribal Eagle Remains Permit is a separate mechanism for qualifying eagle remains found within a Tribe's Indian Country; it does not authorize take or activity outside the permit's scope.

**Navigation result**

- **General public:** Do not pick up, keep, transform, gift, buy, sell, barter, import, or export eagle remains or feathers.
- **Report:** Contact the state wildlife agency or FWS rather than moving the material.
- **Eligible tribal religious or cultural use:** Use the Repository or applicable tribal permit route and follow the issued authorization exactly.
- **Commerce:** Eagle remains and feathers may not be bought, sold, traded, or bartered under the cited tribal pathways.

Primary sources:

- [National Eagle Repository](https://www.fws.gov/program/national-eagle-repository/about-us)
- [FWS Eagle Repository policy](https://www.fws.gov/policy-library/724fw4)
- [Federal Native American Tribal Eagle Remains Permit FAQ](https://www.fws.gov/sites/default/files/documents/2025-01/3-1552-frequently-asked-questions-about-native-american-tribal-eagle-retention.pdf)
- [FWS general FAQ for deceased eagles](https://www.fws.gov/frequently-asked-questions)

**Confidence:** High.  
**Next check:** Confirm the correct regional contact and current form before giving process instructions.

### 3. Endangered and threatened species

Section 9 of the Endangered Species Act prohibits specified take, possession of unlawfully taken material, commercial interstate movement, and interstate or foreign sale of listed wildlife. Regulations and species-specific rules can extend or modify treatment of threatened species. A state salvage authorization does not by itself remove a federal species restriction.

**Navigation result**

- Confirm species status in the current FWS or NOAA listing system before acquisition.
- Do not acquire material of uncertain identity if a protected species is plausible.
- Do not infer that old, inherited, captive-origin, found, or purchased material is unrestricted; documentation and separate exemptions or permits may be decisive.
- Interstate commerce, import, and export require a separate federal analysis even if in-state possession is lawful.

Primary source: [ESA Section 9 prohibited acts](https://www.fws.gov/laws/endangered-species-act/section-9).

**Confidence:** High for the general prohibition; species/activity-specific outcome requires individual review.  
**Next check:** Search the exact scientific name, listing status, applicable 4(d) rule if threatened, origin date, and permit history.

### 4. Marine mammals and NOAA-protected species

NOAA Fisheries states that a person may collect bones, teeth, or ivory of a **non-ESA-listed** marine mammal found on a beach or land within one-quarter mile of an ocean, bay, or estuary, provided the item is not collected from a carcass and has no soft tissue attached. The collected material must be identified and registered with the nearest NOAA Fisheries Regional Office. Material collected through this beach-found route may not be bought or sold. Parts of ESA-listed species may not be collected without authorization.

**Navigation result**

- Do not remove material from a carcass or from remains with soft tissue.
- Contact NOAA for identification and registration; do not rely on personal identification.
- Confirm whether the population/species is ESA-listed.
- Do not buy or sell material retained through the beach-found route.
- State law, tribal law, protected-land rules, and property access still apply.

Primary sources:

- [NOAA Protected Species Parts](https://www.fisheries.noaa.gov/national/permits/protected-species-parts)
- [NOAA Alaska Marine Mammal Parts and Products](https://www.fisheries.noaa.gov/alaska/outreach-and-education/marine-mammal-parts-and-products-alaska)

**Confidence:** High for the federal route stated by NOAA.  
**Next check:** Contact the correct NOAA regional law-enforcement or stranding office before removal because listing status and location matter.

### 5. The Lacey Act

The Lacey Act can turn an underlying federal, state, foreign, or tribal wildlife-law violation into an additional federal offense involving import, export, transport, sale, receipt, acquisition, or purchase. It applies to wildlife parts and products, not only live animals. It also separately regulates injurious wildlife import and specified movements.

**Navigation result**

- A destination-state rule does not cure unlawful acquisition in the source jurisdiction.
- Keep source, permit, tag, receipt, transfer, and destination records together.
- Check source state, destination state, each land jurisdiction, tribal law where relevant, and federal species law before shipping or traveling.
- Imported material needs a distinct import/export, CITES, declaration, port, and documentation analysis.

Primary sources:

- [FWS Lacey Act overview](https://www.fws.gov/law/lacey-act)
- [FWS 2023 explanation of wildlife parts and Lacey Act coverage](https://www.fws.gov/policy/library/2023/2023-12636.pdf)
- [FWS testimony on predicate violations](https://www.fws.gov/testimony/hr-3210-and-hr-4171-related-lacey-act)

**Confidence:** High for the routing principle; application is fact-specific.  
**Next check:** Have counsel or the relevant enforcement office assess any transaction with uncertain origin or cross-jurisdiction movement.

### 6. International movement, CITES, and wildlife declarations

FWS defines regulated wildlife broadly to include dead wild animals and their parts, products, eggs, and offspring. Import and export can require wildlife declarations, designated ports, inspections, CITES documents, protected-species permits, and—when commercial—an import/export license. Personal-baggage exceptions are limited and do not displace species-specific restrictions.

**Navigation result**

- Do not order or ship wildlife material across an international border based solely on a marketplace seller's assurance.
- Identify the species scientifically, source country, wild/captive origin, acquisition date, purpose, port, and all permits before shipment.
- Commercial import/export licensing is separate from CITES or ESA permission.
- Keep foreign and U.S. authorization together permanently.

Primary sources:

- [FWS information for importers and exporters](https://www.fws.gov/program/office-of-law-enforcement/information-importers-exporters)
- [FWS importing and exporting permit index](https://www.fws.gov/service/importing-and-exporting)
- [CITES export form for wild-sourced parts and products](https://www.fws.gov/service/3-200-27-export-wildlife-removed-wild-livesamples-partsproducts-under-cites)
- [Commercial import/export license](https://www.fws.gov/service/3-200-3a-import-export-license-us-entities)

**Confidence:** High for process routing.  
**Next check:** Obtain a transaction-specific determination from FWS Office of Law Enforcement and International Affairs before shipment.

### 7. Chronic Wasting Disease and interstate cervid movement

CWD rules are not one national consumer rule. USDA APHIS regulates farmed/captive cervid herd certification and interstate movement, while states frequently impose additional or stricter restrictions on wild cervid carcasses and parts entering or leaving their jurisdictions. APHIS also notes that carcass and tissue disposal can be regulated by federal, state, or local authorities.

**Navigation result**

- Check both origin and destination state rules immediately before moving deer, elk, moose, or other covered cervid material.
- Distinguish cleaned antlers, skull plates, finished mounts, taxidermy, meat, hide, whole skulls, spinal tissue, and other high-risk parts; states often define them differently.
- Do not treat “fully cleaned” as self-proving; comply with the destination state's stated standard and documentation.
- If disease is suspected or confirmed, follow agency direction for transport, testing, cleaning, and disposal.

Primary sources:

- [APHIS CWD control and eradication guide](https://www.aphis.usda.gov/nvap/reference-guide/control-eradication/cwd)
- [APHIS CWD Herd Certification Program](https://www.aphis.usda.gov/livestock-poultry-disease/cervid/chronic-wasting/herd-certification)
- [APHIS interstate regulation routing](https://www.aphis.usda.gov/nvap/reference-guide/animal-movement/interstate-regulations)

**Confidence:** High for the division of responsibility; state-specific outcomes remain unresolved until each origin/destination pair is checked.  
**Next check:** Use current state wildlife and animal-health pages for every shipment.

## Federal land and property jurisdiction

### National Park Service

NPS regulations generally prohibit possessing, removing, injuring, destroying, or disturbing wildlife and other natural resources in park units. Scientific collection requires a permit and qualifying purpose. Unit-specific compendia can add transport and wildlife restrictions.

**Public rule:** Leave wildlife remains, sheds, feathers, nests, and other natural objects in place unless a current unit-specific rule and ranger confirmation expressly authorizes the exact activity.

Sources:

- [NPS collecting-permit overview](https://www.nps.gov/subjects/geology/permits.htm)
- [NPS fossil and collection regulations](https://www.nps.gov/subjects/fossils/fossil-protection.htm)
- [Example of unit-specific rules: Acadia](https://www.nps.gov/acad/planyourvisit/park-rules-and-regulations.htm)

**Confidence:** High for the general prohibition.  
**Next check:** Contact the specific unit and read its current superintendent's compendium.

### National wildlife refuges

Refuge-specific regulations, compatibility determinations, permits, and state law can govern collection. No general permission to remove wildlife remains should be inferred from public access.

**Public rule:** Leave it and contact that refuge's manager before any collection or removal.

**Confidence:** Conservative routing; site-specific verification required.  
**Next check:** Obtain the refuge's current regulations and written staff direction.

### Bureau of Land Management

BLM's public collection guidance principally addresses rocks, minerals, plants, petrified wood, and fossils—not a nationwide right to collect modern wildlife remains. Local closures, special designations, resource-management plans, state wildlife law, and species law can control. Some BLM materials recognize shed-antler collection consistent with state law in a particular area, while special units may prohibit broader collections.

**Public rule:** Do not infer a nationwide BLM authorization for bones, carcass parts, or sheds. Contact the field office for the exact parcel, identify special designation, and check state seasons/closures and species restrictions.

Sources:

- [BLM “Can I Keep This?”](https://www.blm.gov/Learn/Can-I-Keep-This)
- [BLM rockhounding and field-office routing](https://www.blm.gov/programs/recreation/rockhounding)

**Confidence:** High that local verification is required; no universal yes/no result.  
**Next check:** Written field-office confirmation for exact land and object.

### National Forest System

Forest orders, wilderness rules, state wildlife law, closures, and unit practice can vary. Search did not locate a current Forest Service page creating a universal personal-collection right for modern wildlife remains. Some unit documents state that shed gathering is not treated as a forest-product program, but that does not resolve state law, seasonal wildlife closures, wilderness restrictions, protected species, or a specific forest order.

**Public rule:** Check state law and contact the specific ranger district before collecting any modern wildlife part or shed. Do not rely on a rule from another forest.

**Confidence:** Medium; current national guidance is not sufficiently explicit for publication as a permission rule.  
**Next check:** Obtain the unit's written response, current orders, and applicable state regulation.

### Private property, roads, rail corridors, utilities, and municipal land

Property-owner permission does not replace wildlife law, and wildlife authorization does not replace property access. A public-facing roadside may be private property or controlled right-of-way. Removing an object from a road can create traffic and safety risks.

**Public rule:** Do not enter, stop, park, film, or remove material without lawful access and the required wildlife authorization. Report road hazards to the responsible authority.

## District of Columbia

### Verified conclusions

1. DOEE's Fisheries and Wildlife Division is the controlling public contact for District wildlife questions. DOEE asks the public to report dead wildlife to that division rather than presenting a public salvage route.
2. The Wildlife Protection Act's restriction on retaining or transferring wildlife or parts at D.C. Code § 8-2205(d) specifically governs licensed wildlife control operators; it is strong evidence that material handled through wildlife-control work cannot be retained, sold, bartered, traded, or gifted, but it should not be stretched into a universal rule for every resident circumstance.
3. D.C. Code § 8-2221.28 recognizes District regulatory authority while preserving federal migratory-bird permitting and limits local restriction of wildlife legally taken elsewhere, subject to public health and safety. It does not establish a public local pickup authorization.
4. D.C. has a distinct prohibition on distribution of specified animal products at § 22-1862, with defined exceptions. Any product involving covered species requires a separate review.
5. Federal migratory-bird, eagle, endangered-species, marine-mammal, import/export, and Lacey Act rules continue to apply.

### Decision table

| Topic | Current verified status | Public action |
|---|---|---|
| Road-killed wildlife acquisition | No primary public authorization located | Do not collect; report and ask DOEE Fisheries and Wildlife Division |
| Naturally found terrestrial remains | No general public-retention rule located | Leave in place; obtain species and land-jurisdiction guidance from DOEE |
| Shed antlers | No District-specific public collection authorization located | Ask DOEE and the exact land manager; do not infer permission |
| Migratory bird feathers/parts | Federal restrictions and seven-day donation/destruction salvage route apply | Do not retain for personal use |
| Eagles | Federal additional prohibition applies | Do not salvage; report |
| Protected species | Federal and District protections may overlap | Stop and obtain agency identification/direction |
| Private property | Owner permission is necessary but not sufficient | Obtain owner permission and wildlife authorization |
| National Park Service land in D.C. | NPS resource-removal prohibition applies | Leave in place and contact the park unit |
| Personal art/display use | No general acquisition authorization found | Personal use does not cure unlawful acquisition; get written agency direction |
| Gift/transfer | Species, source, and acquisition determine outcome; wildlife-control material cannot be retained or given | Do not transfer without explicit authority and documentation |
| Commerce | Federal rules plus D.C. prohibited-animal-product law and any species rule apply | Treat as high-risk; obtain transaction-specific review |
| Resident/nonresident status | No general public salvage route found for either | Ask DOEE; do not assume residency creates authority |
| CWD/import | Destination and origin rules plus federal captive-cervid rules may apply | Check DOEE and source-state rules before entry |
| Interstate transport | Lacey Act and source/destination laws apply | Preserve records and verify both jurisdictions |

Primary sources and contact path:

- [DOEE Fisheries and Wildlife](https://doee.dc.gov/service/fisheries-and-wildlife)
- [DOEE Natural Resources Administration](https://doee.dc.gov/page/natural-resources-administration)
- [DOEE dead-wildlife reporting example](https://doee.dc.gov/release/potomac-interceptor-update-and-faqs)
- [D.C. Code § 8-2205](https://code.dccouncil.gov/us/dc/council/code/sections/8-2205)
- [D.C. Code § 8-2221.28](https://code.dccouncil.gov/us/dc/council/code/sections/8-2221.28)
- [D.C. Code § 22-1862](https://code.dccouncil.gov/us/dc/council/code/sections/22-1862)

**Agency contact:** DOEE Fisheries and Wildlife Division, 1200 First Street NE, Washington, DC 20002; main phone (202) 535-2600. DOEE's current administration page lists the Fisheries and Wildlife Division's associate director and direct contact.

**Overall confidence:** Medium-high for “no public authorization located; ask before collecting”; high for cited federal and operator-specific restrictions.  
**Required next verification:** Ask DOEE in writing for a matrix covering resident and nonresident acquisition of roadkill, naturally found terrestrial remains, clean bones, skulls, shed antlers, gifting, personal display, import from a state, CWD-sensitive cervid parts, and commerce.

## Tribal-jurisdiction routing

There is no single “tribal land” rule. BIA states that tribal fish-and-wildlife authority and responsibility vary by land status and by treaty, executive order, court decision, resource-specific statute, and other legal instruments. Tribes determine the scope of their fish-and-wildlife programs for their reservations. Tribal law can also be a predicate law under the Lacey Act.

### Required workflow

1. Identify the exact parcel and whether it is Indian Country, trust land, restricted land, allotted land, tribally owned fee land, or another land status.
2. Identify the governing Tribe or Tribes; do not assume the nearest Tribe controls the parcel.
3. Use the BIA Tribal Leaders Directory to find the Tribe's official public contact and website.
4. Contact the Tribe's wildlife, natural-resources, fish-and-game, conservation-enforcement, cultural-resources, or legal office as directed by the Tribe.
5. Ask about species, cause of death, collection, possession, member/nonmember status, intended personal use, gifting, commerce, transport off land, season/closure, permit/reporting, and cultural restrictions.
6. Separately check federal protected-species law and the destination jurisdiction.
7. Retain written permission, permit, receipt, tag, and transfer record with the object.

### Cultural and religious pathways

Do not generalize tribal religious-use rules into public permissions. FWS provides specific federal pathways for eligible enrolled members of federally recognized Tribes to obtain eagle and non-eagle migratory-bird material for religious or cultural use. Eligibility, source, possession document, transfer, and commerce restrictions are specific to those pathways.

Primary sources:

- [BIA Tribal Leaders Directory](https://www.bia.gov/service/tribal-leaders-directory)
- [BIA fish, wildlife, and recreation authority manual](https://www.bia.gov/sites/default/files/dup/assets/raca/manual/pdf/idc2-060922.pdf)
- [BIA explanation of tribal self-government](https://www.bia.gov/frequently-asked-questions)
- [FWS non-eagle feather repositories](https://www.fws.gov/service/non-eagle-feather-repositories)
- [National Eagle Repository](https://www.fws.gov/program/national-eagle-repository/about-us)

**Confidence:** High for the routing rule; no parcel-specific outcome can be supplied without the Tribe's current law and facts.  
**Next check:** For each project, obtain the current tribal code or written wildlife-office response rather than relying on a state page.

## Required provenance record

For any item lawfully acquired or transferred, preserve:

- Species and how identification was confirmed.
- Date and exact source jurisdiction; keep sensitive coordinates private where appropriate.
- Landowner/land-manager authorization.
- Cause/source category: lawful harvest, permitted salvage, naturally found, shed, purchase, gift, inheritance, import, or other.
- Permit, tag, salvage number, registration, agency correspondence, and expiration/conditions.
- Transferor and recipient, with their authority to transfer/receive.
- Cleaning status and any CWD/import-relevant treatment.
- Origin state/country and every destination.
- Receipt and item photographs at acquisition.
- Restrictions on use, gifting, sale, interstate movement, export, and disposal.
- Date the rule and links were last rechecked.

## Publication language rules

- Say **“agency confirmation required”** when the primary source does not resolve the exact facts.
- Separate acquisition, possession, preparation, personal display, gifting, sale, and transport.
- State “no public authorization located” instead of converting silence into a prohibition or permission.
- Treat state salvage programs as species- and action-specific, not blanket ownership.
- Treat protected land and tribal jurisdiction as separate gates.
- Treat commerce, interstate movement, and international movement as new legal events.
- Preserve direct primary links and an access date for every conclusion.

