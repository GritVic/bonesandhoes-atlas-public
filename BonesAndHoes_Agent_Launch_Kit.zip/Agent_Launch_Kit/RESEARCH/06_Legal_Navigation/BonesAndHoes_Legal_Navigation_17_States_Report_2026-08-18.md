# BonesAndHoes Legal Acquisition and Personal-Use Navigation Guide

## Louisiana through North Dakota — 17-state verification segment

**Access date:** August 18, 2026  
**Structured companion:** `BonesAndHoes_Legal_Navigation_17_States_2026-08-18.csv`  
**Scope:** Louisiana, Maine, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana, Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina, and North Dakota.

## How to use this guide

This is a navigation resource, not legal advice and not a simple legal/illegal scorecard. Wildlife rules turn on multiple independent facts:

- species and whether it is protected federally or by the state;
- how the animal or part was acquired;
- whether it came from hunting, a vehicle collision, natural death, or a natural shed;
- whether the person has an officer authorization, confirmation number, tag, permit, receipt, or donation certificate;
- private-property permission and the land manager’s separate rules;
- resident status;
- whether the material will remain in personal possession, be gifted, cross a state line, or enter commerce;
- CWD zone, origin, tissue condition, and disposal requirements.

An empty or silent agency webpage does not grant permission. Where current primary sources did not answer a question, this guide marks the point unresolved and provides a verification action.

## Fast comparison

| State | Roadkill position | Naturally shed antlers | Found skulls/bones | Commerce signal | Confidence |
|---|---|---|---|---|---|
| Louisiana | No public general authorization found; contact LDWF | Unresolved | Unresolved | Unresolved | Low |
| Maine | Reported collision-carcass process; entire deer/moose/bear carcass must be removed | Needs clarification | General possession prohibition unless exception | Limited lawful-product and hide-dealer paths | Medium |
| Maryland | Deer/turkey confirmation; bear possession tag; special furbearer limits | Expressly lawful with property permission | Antlered skull needs confirmation | No broad found-material right | High |
| Massachusetts | 321 CMR 2.04 governs non-hunting deer salvage | Expressly exempt if naturally shed | Unresolved | Unresolved | Medium |
| Michigan | Free deer salvage application; movement limits | Unresolved | Institutional scientific salvage is not private ownership | WCO species/source rules apply | High |
| Minnesota | Possession permit required; driver has priority for public-road deer | Expressly lawful without license | Game skull needs lawful take or permit | Lawfully taken inedible parts generally transferable | High |
| Mississippi | No public general authorization found; contact MDWFP | Unresolved | Unresolved | Unresolved | Low |
| Missouri | Attached antlers on found dead deer/elk require 24-hour report and authorization | Expressly lawful and transferable | Species-specific; attached antlers controlled | Deer/elk parts have bill-of-sale pathway | High |
| Montana | Free permit for vehicle-killed deer/elk/moose/antelope within 24 hours | Expressly lawful | Certain naturally dead cervid parts allowed; other salvage controlled | Salvaged meat cannot be sold | High |
| Nebraska | Resident-only roadkill deer/elk/antelope process with notification/tagging | Expressly lawful and saleable | Defined found-dead parts may be possessed but not sold | Roadkill non-meat parts may be sold | High |
| Nevada | NDOW agent certificate for pick-up heads; whole carcass unresolved | Unresolved | Agent certificate needed for found heads | Unresolved | Low |
| New Hampshire | No current public procedure found; possession prohibited unless authorized | Unresolved | Unresolved | Unresolved | Low |
| New Jersey | Roadkill/naturally dead deer antlers prohibited | Naturally shed antlers lawful | Native found wildlife may require salvage permit | General game-part sale prohibition with narrow exceptions | High |
| New Mexico | No general roadkill program found; protected skulls left and reported | Expressly lawful | Protected heads/horns/antlers require Department receipt | No general field-found sale right | High |
| New York | Road-killed furbearers only under season/license/sealing rules; deer unresolved | Unresolved | Unresolved | Species/license/seal specific | Medium |
| North Carolina | Most dead wildlife permit-free, but deer/turkey/bear/elk and listed species require permission | Unresolved | Most species allowed; big-game/listed/birds excepted | Found-dead wildlife sales generally prohibited | High |
| North Dakota | Permit required for roadkill deer; current process not located | Unresolved | State control; no broad exception found | Unresolved | Low |

## State findings

### Louisiana

**What is verified**

- LDWF’s current cervid carcass-import regulation limits imported or transported cervid material to specified lower-risk forms, including antlers, clean skull plates, cleaned skulls without tissue, capes, tanned hides, finished mounts, cleaned teeth, and qualifying meat.
- Approved outside-origin parts need possession information identifying the hunter and harvest.
- CWD-related restrictions can also limit movement of material originating within named Louisiana parishes.

**What is not verified**

- A general public roadkill-salvage process.
- Personal collection of naturally dead bones or skulls.
- Naturally shed antlers.
- Gifting or selling salvaged/found material.

**Safe navigation:** Do not remove the material. Record location and species from a safe place and contact LDWF Enforcement. Ask for written authorization and a record that travels with the item.

**Primary sources:** [LDWF regulations](https://www.wlf.louisiana.gov/page/seasons-and-regulations); [cervid import regulation](https://www.wlf.louisiana.gov/assets/Hunting/Deer/Files/Cervid-Carcass-Importation-Regulations.pdf); [LDWF import advisory](https://www.wlf.louisiana.gov/news/ldwf-reminds-hunters-returning-from-outofstate-hunts-about-louisianas-cervid-carcass-importation-ban).

### Maine

**What is verified**

- Maine defines wildlife to include dead bodies and parts and broadly prohibits possession when no season or exception authorizes it.
- A person entitled to a collision-killed deer, moose, or bear must follow the reporting process and remove the entire carcass; taking only a portion is prohibited.
- Harvested deer, moose, bear, and turkey have tagging, registration, transport, and gift-document requirements.
- Legally obtained finished wildlife products have a defined commercial pathway, while raw antlers from registered deer or moose are restricted to licensed hide-dealer transactions.
- Cervid imports are restricted to specified lower-risk parts.

**What is not fully verified**

- General naturally shed-antler collection on each land class.
- Ordinary naturally found bones outside the collision rule.
- Transfer and commerce for material whose source is not a registered harvest.

**Safe navigation:** Treat the general prohibition as controlling until MDIFW identifies the exact exception. Never remove only the head or antlers from a collision carcass.

**Primary sources:** [Maine wildlife-law overview](https://www1.maine.gov/ifw/fish-wildlife/wildlife/living-with-wildlife/avoid-resolve-conflict/laws.html); [general hunting laws](https://www.maine.gov/ifw/hunting-trapping/hunting/laws-rules/general-laws.html); [tagging, transport, and registration](https://www.maine.gov/ifw/hunting-trapping/hunting/laws-rules/tagging-transportation-registration.html); [CWD rules](https://www.maine.gov/ifw/hunting-trapping/hunting/laws-rules/chronic-wasting-disease.html).

### Maryland

**What is verified**

- Deer and turkey roadkills may be salvaged by a person with a DNRid and non-harvest confirmation number.
- Black bear roadkills or found carcasses require a possession tag from a wildlife service field office.
- Furbearer salvage is limited to licensed trappers or permitted wildlife-damage operators.
- Naturally shed antlers may be possessed without a permit and collected with property-owner permission.
- An antlered skull found outside hunter harvest must be checked in through MD Outdoors for a confirmation number.

**What is not fully verified**

- Unantlered bones and remains by species.
- Gifting and commercial use of salvaged material.
- Current cervid import restrictions.

**Safe navigation:** Obtain the confirmation number or tag before possession and retain it permanently with the item’s provenance file.

**Primary sources:** [Maryland shed-antler policy](https://dnr.maryland.gov/wildlife/Pages/hunt_trap/Shed-Antler-Policies.aspx); [Maryland Taxidermy Guide](https://dnr.maryland.gov/wildlife/Documents/Maryland-Taxidermy-Guide.pdf).

### Massachusetts

**What is verified**

- 321 CMR 2.04 governs salvage, disposition, and possession of deer killed outside sport hunting.
- Naturally shed deer and moose antlers are exempt from possession-permit requirements if found naturally and not removed through a device designed to induce shedding.

**What is not fully verified**

- The current applicant priority and documentation sequence under 2.04.
- Naturally found remains other than shed antlers.
- Gifting, commerce, and current CWD import limits.

**Safe navigation:** Contact Massachusetts Environmental Police or MassWildlife before removing a collision deer. Keep the shed-antler exception narrow; it does not authorize a skull with antlers attached.

**Primary source:** [321 CMR 2.00](https://www.mass.gov/regulations/321-CMR-200-miscellaneous-regulations).

### Michigan

**What is verified**

- A free salvage application is required to keep a roadkill deer.
- Roadkill deer movement outside the pickup county is restricted, except for specified lower-risk parts.
- Current import rules restrict outside-origin cervids to hides, qualifying meat, finished products, cleaned teeth, and cleaned antlers/skull caps.
- Scientific salvage is an institutional research/education pathway; it does not authorize private maintenance or sale.
- Threatened/endangered species and numerous specially controlled species cannot be treated as ordinary roadkill.

**What is not fully verified**

- Naturally shed antlers.
- Every non-deer roadkill species.
- Gifts and commerce under the current Wildlife Conservation Order.

**Safe navigation:** Use the online deer application. For any other species, call DNR Wildlife or Law Enforcement before touching or transporting it.

**Primary sources:** [Michigan deer nuisance/roadkill page](https://www.michigan.gov/dnr/managing-resources/wildlife/nuisance-wildlife/deer); [2026 deer regulations](https://www.michigan.gov/dnr/managing-resources/laws/regulations/deer); [Wildlife Conservation Order](https://www.michigan.gov/dnr/managing-resources/laws/orders/wildlife-conservation-order); [scientific collector permit](https://www.michigan.gov/dnr/-/media/Project/Websites/dnr/Documents/WLD/permits/24.pdf).

### Minnesota

**What is verified**

- Protected wildlife killed by a vehicle requires a possession permit.
- The driver who collided with a deer on a public road has priority for a permit covering the entire deer.
- Conservation officers and many local law-enforcement agencies issue possession permits.
- Naturally shed antlers may be collected and possessed without a license; devices that pull or sever antlers from live cervids are prohibited.
- Game-animal skulls need a lawful-harvest or permit basis.
- Lawfully taken bones, skulls, hooves, antlers, sinews, teeth, hides, and claws have a general purchase/sale pathway subject to species exceptions.
- Game gifts require a receipt identifying donor, recipient, date, description, and license number.
- Whole outside-origin cervid carcasses are prohibited; specified lower-risk parts are allowed, and certain heads may go directly to a licensed taxidermist within 48 hours.

**Safe navigation:** Get the possession permit before keeping vehicle-killed protected wildlife and preserve every permit/gift record.

**Primary sources:** [vehicle-killed wildlife](https://www.dnr.state.mn.us/enforcement/motorkill.html); [Minn. Stat. 97A.502](https://www.revisor.mn.gov/statutes/cite/97A.502); [shed-antler statute](https://www.revisor.mn.gov/statutes/cite/97B/pdf); [hunting regulations](https://files.dnr.state.mn.us/rlp/regulations/hunting/full_regs.pdf); [cervid imports](https://www.dnr.state.mn.us/deerimports/index.html).

### Mississippi

**What is verified**

- Mississippi’s CWD rule permits only specified lower-risk cervid material to enter the state or leave a CWD zone: completely deboned meat, qualifying quarters, headless hides, finished products, tissue-free antlers, and cleaned skulls or skull plates.
- Public-land regulations can be stricter than statewide hunting rules.

**What is not verified**

- A current public roadkill-salvage process.
- Naturally found bones/skulls.
- Naturally shed antlers.
- Gifting and commerce.

**Safe navigation:** Do not remove a collision carcass or found protected wildlife without MDWFP Law Enforcement authorization.

**Primary sources:** [white-tailed deer regulations](https://www.mdwfp.com/enforcement-education/white-tailed-deer-regulations); [hunting seasons and limits](https://www.mdwfp.com/wildlife-hunting/hunting-seasons-and-bag-limits); [nuisance-species regulations](https://www.mdwfp.com/wildlife-hunting/general-hunting-rules-regulations/nuisance-species-regulations).

### Missouri

**What is verified**

- A person taking antlers still attached to the skull plate of a found-dead deer or elk must report the find to a conservation agent within 24 hours and obtain authorization to possess it.
- Naturally shed antlers not attached to a skull plate may be possessed, bought, and sold without authorization.
- Lawfully obtained deer and elk heads, antlers, hides, and feet may be sold with a bill of sale carrying required seller, buyer, species, and quantity information.
- The recipient/purchaser of attached skull-plate antlers must retain a dated bill of sale.

**What remains case-specific**

- Whole roadkill carcasses.
- Non-cervid found remains.
- Current CWD-zone and import controls.

**Safe navigation:** Report a deadhead within 24 hours and obtain the agent’s possession authorization before transport.

**Primary sources:** [Missouri deer regulations](https://mdc.mo.gov/hunting-trapping/species/deer/deer-regulations); [3 CSR 10-10.768](https://mdc.mo.gov/about-us/about-regulations/wildlife-code-missouri/3-csr-10-10768-sales-possession-wildlife-parts).

### Montana

**What is verified**

- A free vehicle-killed wildlife permit covers deer, elk, moose, and antelope only.
- The permit must be obtained within 24 hours, printed, signed, and retained.
- The entire animal must be removed; the permittee may not leave parts at the site.
- A permit holder may possess meat, hide, hooves, horns, and antlers.
- Salvaged meat must be used for human consumption and cannot be sold.
- Montana law recognizes naturally shed antlers and certain naturally dead cervid antlers/skulls/bones when the animal was not unlawfully or accidentally killed.
- Mountain-sheep natural-death horns/skulls have special reporting, inspection, and pinning requirements.
- CWD disposal and outside-origin import limits apply to cervids.

**What is not fully verified**

- Gifting or selling non-meat parts from a vehicle salvage.
- All other species and land-manager restrictions.

**Safe navigation:** Use the official online permit and retain the paper copy. For natural-death material, be prepared to establish that the death was not an accident or unlawful take.

**Primary sources:** [vehicle-killed salvage permit](https://fwp.mt.gov/buyandapply/vehiclekilledsalvagepermit); [CWD management](https://fwp.mt.gov/conservation/chronic-wasting-disease/management); [scientific permits](https://fwp.mt.gov/buyandapply/commercialwildlifeandscientificpermits/scientific); [WMA public-use rules](https://fwp.mt.gov/conservation/wildlife-management-areas/public-use-rules).

### Nebraska

**What is verified**

- The roadkill deer/elk/antelope process is expressly framed for Nebraska residents.
- Priority goes to the person in the collision, then public institutions, nonprofits, and other individuals.
- Game and Parks must be notified within 24 hours, with officer/designee tagging within 48 hours.
- Processing before a special salvage permit is prohibited.
- An individual may not possess more than one roadkill carcass at once.
- Roadkill meat cannot be sold or traded; processed meat may be gifted with a prescribed receipt.
- Hide, hair, hooves, bones, horns, and antlers from permitted roadkill may be sold.
- Shed antlers/horns may be possessed and sold at any time.
- Certain parts of deer, elk, and antelope found dead may be possessed but not sold, provided specified conditions are met.

**Safe navigation:** Use the full permit and tagging process. Do not cut up the carcass first. Keep the tag and any gift receipt.

**Primary sources:** [Neb. Rev. Stat. 37-560](https://nebraskalegislature.gov/laws/statutes.php?statute=37-560); [Title 163 Chapter 4](https://govdocs.nebraska.gov/epubs/G1000/R163.0004-2015.pdf); [Nebraska Game Law](https://nebraskalegislature.gov/laws/laws-index/chap37-full.html).

### Nevada

**What is verified**

- NDOW uses an agent-signed “Pick-Up Head Salvage Certificate” under NAC 503.093 to authorize possession of a found head.
- Nevada’s CWD rules prohibit knowing possession/import of most outside-origin cervid carcass material while allowing listed lower-risk parts such as antlers without tissue.

**What is not verified**

- A statewide whole-roadkill carcass procedure.
- The current statewide shed-antler rule and any seasonal closures.
- Ordinary found bones.
- Gifts and commerce.

**Safe navigation:** Leave a found head in place and contact an NDOW game warden. Obtain the completed certificate before possession.

**Primary sources:** [NDOW salvage certificate material](https://www.ndow.org/wp-content/uploads/2025/07/6-Shed-Antler-Regulations.pdf); [Nevada CWD guidance](https://www.ndow.org/blog/chronic-wasting-disease/).

### New Hampshire

**What is verified**

- RSA 207:2 broadly prohibits taking, buying, selling, transporting, or possessing wildlife or parts except where Title XVIII authorizes it.
- Deer transport outside ordinary harvest provisions requires a special permit.

**What is not verified**

- A current public roadkill-deer process.
- Naturally found bones/skulls or shed antlers.
- Gifting, commerce, and cervid import rules.

**Safe navigation:** Because the baseline statute is prohibitory, do not remove material without Fish and Game or law-enforcement authorization.

**Primary sources:** [RSA Chapter 207](https://www.gc.nh.gov/rsa/html/xviii/207/207-mrg.htm); [RSA Chapter 208](https://www.gc.nh.gov/rsa/html/XVIII/208/208-mrg.htm); [Fis 300](https://gc.nh.gov/rules/state_agencies/fis300.html).

### New Jersey

**What is verified**

- Current NJ Fish & Wildlife guidance says antlers from roadkill or naturally deceased deer may not be possessed.
- Deer antlers must instead trace to a lawful harvest with confirmation/possession documentation.
- Naturally shed deer antlers are lawful under official guidance.
- A salvage permit is required to possess native wild animals found dead under the exotic/nongame permit program, subject to the deer-specific rule above.
- Whole outside-origin deer carcasses and intact heads are prohibited; specified lower-risk parts may enter.
- General sale of wild birds/game or their parts is prohibited except defined exceptions.

**Safe navigation:** A shed is not the same as an antler attached to a naturally dead or road-killed deer. Do not remove the latter.

**Primary sources:** [New Jersey Deer FAQs](https://dep.nj.gov/njfw/hunting/deer-faqs/); [exotic/nongame wildlife permit applications](https://dep.nj.gov/njfw/wildlife/exotic-and-nongame-wildlife-permit-applications/).

### New Mexico

**What is verified**

- Naturally shed antlers may be possessed.
- A person may not drive off an established road or on a closed road while gathering/searching for sheds on public land.
- Antlers attached to a skull found in the field may not be possessed.
- A protected-animal skull should be left where found and reported to an NMDGF conservation officer.
- NMDGF may sell antlered skulls; the purchaser must retain the Department receipt.
- State and federal threatened/endangered wildlife have strict take, possession, transport, and sale controls.

**What is not fully verified**

- Vehicle-killed carcass salvage.
- Gift and commerce pathways beyond Department receipts and current possession certificates.
- Cervid import rules.

**Safe navigation:** Collect only a true natural shed where access is lawful. Leave protected skulls in place and contact NMDGF.

**Primary sources:** [New Mexico general rules](https://wildlife.dgf.nm.gov/download/13-general-rules/); [19.31.10 NMAC](https://www.srca.nm.gov/parts/title19/19.031.0010.html); [current publications](https://wildlife.dgf.nm.gov/home/publications/).

### New York

**What is verified**

- A road-killed furbearer may be possessed only if the season is open in that WMU and the person complies with ordinary license and sealing requirements.
- Current deer/bear rules limit outside-origin CWD-susceptible cervids to listed lower-risk parts, require origin/harvester labels, and require DEC notification within 24 hours of a positive outside CWD result.
- Direct transport through New York is allowed if no material remains or is disposed of in the state.
- Active CWD containment areas can impose stricter controls, including prohibitions on road-killed deer possession.

**What is not verified**

- A general roadkill-deer salvage path outside an active containment area.
- Shed antlers and ordinary found bones.
- Gifts and sale beyond regulated furbearer pathways.

**Safe navigation:** Contact the DEC regional office. Do not generalize the road-killed furbearer rule to deer or other game.

**Primary sources:** [New York trapping regulations](https://dec.ny.gov/things-to-do/trapping/regulations); [deer and bear regulations](https://dec.ny.gov/things-to-do/hunting/deer-bear/regulations); [2026 CWD response plan](https://dec.ny.gov/sites/default/files/2026-05/cwdinteragencyresponse.pdf).

### North Carolina

**What is verified**

- Most dead wildlife killed accidentally or found dead may now be possessed without a salvage permit.
- Deer, turkey, bear, and elk still require permission.
- An officer investigating a collision may authorize road-killed deer or turkey possession and transport for the person’s private lawful use, for a second person’s private use, or for a charity.
- Endangered, threatened, and special-concern species require written permission.
- Raptors and nongame migratory birds require federal permits.
- Sale of wildlife or parts found dead is prohibited except narrow licensed hunter/trapper furbearer exceptions.
- Lawfully taken wildlife gifts require a donor/source record.

**What is not fully verified**

- Whether naturally shed deer antlers are outside the big-game permission requirement.
- Current cervid-import restrictions.

**Safe navigation:** Request officer authorization for deer/turkey and preserve it in writing. Contact the Commission for bear, elk, or any listed species.

**Primary sources:** [Wildlife Possession and Salvage Permit](https://www.ncwildlife.gov/hunting/hunting-trapping-licenses/other-licenses-permits/wildlife-possession-and-salvage-permit); [Possession and Collection](https://www.ncwildlife.gov/hunting/regulations/nongame-and-other-regulations/possession-and-collection).

### North Dakota

**What is verified**

- Game and Fish materials state that a permit is required before possession of a roadkill deer.
- State law treats wildlife as including dead bodies and parts and places ownership/control with the state.
- Big-game possession and transport ordinarily require the proper tag or a Department permit.
- A resident needs Department permission to ship big game or parts other than hides out of North Dakota.
- Processed lawfully harvested meat may be gifted, but not sold, traded, or bartered.

**What is not verified**

- The current roadkill permit application process.
- Naturally shed antlers and naturally found bones/skulls.
- Roadkill gifts, non-meat commerce, and current CWD import rules.

**Safe navigation:** Contact a game warden before possession or transport and request a written permit/record.

**Primary sources:** [2026 deer proclamation](https://gf.nd.gov/regulations/deer); [research and scientific permits](https://gf.nd.gov/ecology/research-permits); [Century Code Title 20.1](https://ndlegis.gov/cencode/T20-1.html); [Game and Fish help/contact](https://gf.nd.gov/help).

## Federal and land-jurisdiction overlay

Every state entry remains subject to federal restrictions. In particular:

- Native migratory birds, feathers, nests, eggs, and parts are generally federally protected; a state salvage rule does not override federal law.
- ESA-listed species require federal authority and may also be protected by stricter state law.
- National parks generally prohibit removing natural objects.
- National wildlife refuges, national forests, BLM land, state parks, state wildlife areas, tribal lands, municipal land, and private land each have their own access and removal rules.
- Permission to enter land is not automatically permission to remove wildlife material.
- A state possession permit does not automatically authorize interstate transport or possession in the destination state.

## Minimum provenance record

For any lawfully acquired material, retain:

1. Date, precise location, state, county/parish, and land manager.
2. Species identification and who made it.
3. Acquisition category: lawful harvest, officer-authorized collision salvage, natural shed, Department sale, gift, or other permit.
4. Permit, tag, confirmation number, receipt, possession certificate, or gift record.
5. Name and public office of authorizing official when applicable.
6. Photographs before movement where safe and lawful.
7. CWD origin, tissue-cleaning, testing, disposal, and transport records for cervids.
8. Any transfer, buyer/seller, or destination records required by law.
9. The exact source pages and access date used for the decision.

## Publication gate

Before publishing any state as a definitive public guide:

- Recheck all source pages immediately before publication.
- Send unresolved questions to the state agency in writing.
- Preserve the reply in the source register.
- Publish “unresolved—contact agency” rather than guessing.
- Add a visible revision date and correction route.
- Recheck CWD emergency orders and geographic containment areas, which can change faster than ordinary regulations.

## Confidence and remaining work

- **High confidence:** Maryland, Michigan, Minnesota, Missouri, Montana, Nebraska, New Jersey, New Mexico, North Carolina.
- **Medium confidence:** Maine, Massachusetts, New York.
- **Low confidence pending direct agency verification:** Louisiana, Mississippi, Nevada, New Hampshire, North Dakota.

The low-confidence states are not evidence that collection is prohibited or allowed. They are evidence that the reviewed public primary sources did not resolve the full decision. Those states require a written agency response before the Atlas offers specific acquisition guidance.
