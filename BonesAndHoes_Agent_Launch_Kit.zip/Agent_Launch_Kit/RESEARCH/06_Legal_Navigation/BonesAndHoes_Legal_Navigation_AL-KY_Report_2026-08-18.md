# BonesAndHoes Legal Acquisition & Personal-Use Navigation Guide

## Verified tranche: Alabama through Kentucky

**Coverage:** 17 states  
**Verification date:** 2026-08-18  
**Use:** editorial research and pre-action navigation; not legal advice

## Executive finding

The legally safe workflow is not “find it, then determine what to do with it.” It is **identify the species, identify who controls the place, identify the lawful acquisition pathway, obtain the required authorization, and only then move the animal or part**. Across these states, a roadkill report, a CWD transport allowance, or the fact that an antler is clean does not by itself establish lawful acquisition.

The clearest public-facing systems in this tranche are Arizona, Connecticut, Delaware, Idaho, Illinois, Iowa and Kansas. Colorado also has a documented system, but the exact current chapter and species/part disposition must be checked. Alabama, Alaska, Arkansas, California, Florida, Georgia, Hawaii and Kentucky retain material public-facing ambiguity for at least one core scenario. Indiana requires DNR authorization, but its consumer-facing process is fragmented.

## How to read the companion CSV

Every state is separated across: roadkill; naturally found remains; sheds/antlers; protected species; land jurisdiction; acquisition; possession/personal use; gifting/transfer; commerce; resident status; permits/reporting; CWD/import/interstate transport; confidence; unresolved flags; and next action. “Unresolved” means no current primary source reviewed here affirmatively answered the question. It is not permission.

## Universal six-gate check

1. **Species:** positively identify it. Unknown remains stop the process.
2. **Federal overlay:** migratory birds, eagles, marine mammals, endangered species, CITES and the Lacey Act can control even where state law appears permissive.
3. **Place:** identify the landowner or manager. State salvage permission does not authorize trespass or removal from a park, refuge, tribal land, federal unit, sanctuary, right-of-way, or private parcel.
4. **Cause and pathway:** collision, lawful harvest, natural death, agency disposal and a naturally shed antler are distinct legal categories.
5. **Documentation:** obtain the permit, incident report, salvage tag, check number, transfer record or written agency direction before movement when required.
6. **Next use and route:** possession, personal use, gifting, sale, taxidermy, import and interstate transit are separate questions. Verify every state crossed, not only the destination.

## State findings

### Alabama

ADCNR provides current transfer documentation for hunter-harvested deer/turkey and detailed CWD movement controls, but the reviewed official sources do not establish a general public roadkill-claim procedure. Do not use the hunter transfer page as a substitute for initial lawful acquisition. Whole or high-risk cervid material entering Alabama is restricted; deboned meat and thoroughly cleaned specified parts are the principal allowed categories. CWD management-zone movement restrictions can be tighter.

**Action:** ask ADCNR Wildlife & Freshwater Fisheries in writing for the exact roadkill, found-remains, shed, gift and sale rules before pickup.  
**Primary sources:** [transfer of possession](https://www.outdooralabama.com/transfer-possession); [CWD movement and transport](https://www.outdooralabama.com/cwd/cwd-harvest-movement-and-transport); [processor/taxidermist controls](https://www.outdooralabama.com/cwd/processors-and-taxidermists).

### Alaska

Alaska is unusually species- and status-sensitive. ADF&G identifies permits for collection, possession and transport, sealing for specified trophies, a transfer-of-possession form for unprocessed game, and a taxidermy license for paid trophy preparation. Its guidance says game meat cannot be bought, sold or bartered and identifies additional bans involving big-game trophies and bear parts. Found marine-mammal parts have a separate federal/Alaska Native framework. No current official page reviewed here grants an ordinary individual a general roadkill pickup right.

**Action:** send ADF&G Wildlife Permits Section the species, location, cause of death, part, use and route: dfg.dwc.permits@alaska.gov, 907-465-4148.  
**Primary sources:** [permit overview](https://www.adfg.alaska.gov/index.cfm?adfg=otherlicense.wildlife_overview); [permits](https://www.adfg.alaska.gov/index.cfm?adfg=otherlicense.main); [transfer](https://www.adfg.alaska.gov/index.cfm?adfg=hunting.meatcare); [taxidermy](https://www.adfg.alaska.gov/index.cfm?adfg=prolicenses.Taxidermy); [shipping](https://www.adfg.alaska.gov/index.cfm?adfg=hunting..shipping); [found skull guidance](https://www.adfg.alaska.gov/index.cfm?adfg=wildlifenews.view_article&articles_id=837).

### Arizona

A.R.S. 17-319 supplies a strong, specific pathway for qualifying big game. An officer or authorized department employee issues a nontransferable permit for qualifying collision deaths, post-collision euthanasia, reported natural deaths and certain natural injuries. The department receives a copy within 48 hours; destination is recorded; inspection may occur. The permit holder may gift the carcass or parts to another individual. Suspected diseased or spoiled animals are excluded. Sale is not affirmatively authorized. A separate out-of-state big-game transport statute may matter, and its application to salvage should be confirmed.

**Action:** ask AZGFD for written treatment of sheds, gifted-part paperwork, sale and A.R.S. 17-371 export.  
**Primary sources:** [A.R.S. 17-319](https://www.azleg.gov/ars/17/00319.htm); [A.R.S. 17-371](https://www.azleg.gov/ars/17/00371.htm); [A.R.S. 17-309](https://www.azleg.gov/ars/17/00309.htm).

### Arkansas

AGFC’s roadkill sources support reporting and disease surveillance, not public acquisition. The current CWD page prohibits import/possession of most out-of-state cervid material and identifies cleaned skulls/skull plates, tissue-free antlers, deboned meat, cleaned teeth, hides/tanned material and finished taxidermy as lower-risk exceptions. Internal movement between CWD tiers and out of the management zone is also restricted. These movement exceptions do not authorize someone to collect a carcass or antler in the first place.

**Action:** call AGFC Enforcement Radio Room at 800-482-9262 and request written rules for roadkill, naturally found remains, sheds, transfer and sale.  
**Primary sources:** [roadkill reporting](https://www.agfc.com/news/report-road-killed-deer-to-help-agfc-monitor-disease/); [roadkill index](https://www.agfc.com/category/roadkill/); [CWD regulations](https://www.agfc.com/hunting/deer/chronic-wasting-disease/cwd-related-wildlife-hunting-regulations/).

### California

Fish & Game Code 2000.5 is decisive: an accidental vehicle collision is not itself unlawful take, but that section does **not** authorize possession. Section 2000.6 allows a commission pilot for certain big game, but its operative subdivisions depend on department implementation. No current CDFW permit portal or implementation notice was located in this review. The book should therefore not present California public salvage as available unless CDFW confirms the program is operating. California also restricts imported cervid high-risk parts and requires an entry declaration.

**Action:** obtain written CDFW confirmation of 2000.6 implementation and the live permit process, if any.  
**Primary sources:** [Fish & Game Code chapter](https://leginfo.legislature.ca.gov/faces/codes_displayText.xhtml?article=&chapter=1.&division=3.&lawCode=FGC&part=&title=); [CWD/import guidance](https://wildlife.ca.gov/Conservation/Laboratories/Wildlife-Health/Monitoring/CWD); [scientific collecting](https://wildlife.ca.gov/Licensing/Scientific-Collecting).

### Colorado

Colorado’s framework requires agency authorization and timely notice for covered roadkill; federally protected and threatened/endangered wildlife is outside the ordinary pathway. CPW’s current shed page is unusually clear: public lands west of I-25 are closed January 1 through April 30, specified western units add May 1–15 time limits, and lawful access plus any stricter land-manager rule always controls. Some lawfully acquired nonedible parts can enter commerce, but major exceptions exist, so the exact current Chapter W-0 subsection and species/part must be checked before a transaction.

**Action:** have CPW identify the current W-0 sections governing the intended roadkill part, any transfer, and any sale.  
**Primary sources:** [current Chapter W-0](https://cpw.state.co.us/sites/default/files/dam/x4ttwki7gk/chw-0-as-approved-nov-2025.pdf); [shed collection](https://cpw.state.co.us/shed-antler-and-horn-collection); [CWD](https://cpw.state.co.us/activities/hunting/big-game/chronic-wasting-disease); [special licenses](https://cpw.state.co.us/special-wildlife-licenses).

### Connecticut

CGS 26-86 allows a deer, moose or black bear killed or seriously wounded by a vehicle to become the driver’s property—or another person’s if the driver declines—only after inspection and a wildlife-kill incident report from police or a conservation officer. This is a narrow, documented acquisition route. CGS 26-82 restricts deer-flesh sale and possession. The reviewed law does not clearly authorize later gifts or sale of salvaged nonedible parts. CWD-source carcasses are restricted and official guidance emphasizes deboned/cleaned lower-risk material.

**Action:** ask DEEP for written answers on post-report gifts, nonedible-part sale, sheds and other found remains.  
**Primary sources:** [Chapter 490](https://www.cga.ct.gov/2023/pub/chap_490.htm); [2026 deer/CWD rules](https://portal.ct.gov/deep/hunting/2026-connecticut-hunting-and-trapping-guide/deer-hunting); [wildlife disease guidance](https://portal.ct.gov/DEEP/Wildlife/Wildlife-Diseases).

### Delaware

Under 7 Del. C. 794, the driver who kills a deer on a public highway and produces visible collision evidence to State Police or a Fish & Wildlife agent is entitled to possession. No bystander priority is stated. Section 787 restricts possession and broadly restricts sale or intent to sell deer and parts, with a hide exception whose application to salvaged deer should be confirmed. Delaware’s 2026 CWD page adds current import and management-area movement rules.

**Action:** ask DNREC whether a bystander can ever receive the deer, whether later gifting is lawful, how sheds are treated, and whether a roadkill hide fits the statutory exception.  
**Primary sources:** [Title 7 deer statutes](https://delcode.delaware.gov/title7/c007/sc06/); [CWD](https://dnrec.delaware.gov/fish-wildlife/hunting/cwd/).

### Florida

FWC’s deer FAQ says road-killed deer are excluded from annual and daily deer bag limits, but that is not a complete acquisition procedure. The taxidermy page describes roadkill handling and recordkeeping for licensed taxidermists and special closed-season permits for certain game, not a blanket ordinary-public right. Florida prohibits import or possession of out-of-state whole/high-risk cervid material, with enumerated low-risk exceptions. Bear-part sale is specifically constrained.

**Action:** obtain FWC Law Enforcement’s written ordinary-public roadkill procedure and separate answers for sheds, gifts and commerce.  
**Primary sources:** [deer FAQ](https://myfwc.com/hunting/deer/faqs/); [taxidermy](https://myfwc.com/license/captive-wildlife/taxidermy/); [CWD rules](https://myfwc.com/hunting/deer/cwd/).

### Georgia

Georgia DNR’s current public guidance says Georgia law prohibits possession of most wildlife without a permit and advises leaving wildlife where found. No general public roadkill pathway was located. This is a high-value editorial correction: a roadkill reporting or CWD surveillance reference cannot be presented as a collection authorization. Georgia’s current CWD rules limit out-of-state parts and impose statewide deer-carcass disposal duties on anyone transporting or disposing of carcasses or parts.

**Action:** send WRD the exact species/place/use scenario before collection; use 1-800-366-2661 for customer help and 1-800-241-4113 for the ranger hotline.  
**Primary sources:** [leave wildlife where found](https://georgiawildlife.com/wildlife-belongs-wild-leave-wildlife-where-found); [CWD/import](https://georgiawildlife.com/cwd/know-georgia); [hunter transport/disposal](https://georgiawildlife.com/cwd/hunter-info).

### Hawaii

Hawaii requires species-, island-, place- and purpose-specific analysis. DOFAW warns that multiple permits can be required. Native, listed, migratory and injurious wildlife have distinct controls; federal permission may be additional. One-time injurious-wildlife export permissions described by DOFAW are narrow, status-specific and noncommercial. Managed animal-removal events are special programs, not a statewide roadkill rule.

**Action:** provide DOFAW with species, island, land unit, cause of death, intended use and destination before possession or movement.  
**Primary sources:** [permit guidance](https://dlnr.hawaii.gov/dofaw/permits/); [special-use portal](https://dlnr.hawaii.gov/dofaw/sap_landing_page/); [rules](https://dlnr.hawaii.gov/dofaw/rules/); [contacts](https://dlnr.hawaii.gov/dofaw/contact/).

### Idaho

Idaho has the most usable digital system in this tranche. Eligible accidental-collision wildlife may be picked up, reported within 24 hours and documented by a CE-51 permit within 72 hours. The official list controls species eligibility. For natural deaths, IDFG must be contacted before salvaging meat, while antlers from naturally dead big game may be recovered without a permit if the animal was not illegally taken or a suspected wounding loss. Mandatory checks apply to specified species. Idaho expressly permits sale of nonedible parts from covered vehicle-killed huntable/trappable wildlife, except bighorn sheep, while edible flesh may not be sold.

**Action:** use the online report and confirm land access, mandatory check, CWD-zone notice and gift documentation.  
**Primary sources:** [roadkill system](https://idfg.idaho.gov/species/roadkill); [eligible species](https://idfg.idaho.gov/species/roadkill/salvage/list); [report/permit form](https://idfg.idaho.gov/species/roadkill/add); [natural-death guidance](https://idfg.idaho.gov/press/idahos-wildlife-collision-salvage-rule-what-can-you-salvage); [CWD import](https://idfg.idaho.gov/cwd/import-ban).

### Illinois

Part 750 separates vehicle-killed deer from other found-dead deer. A claimant reports vehicle-killed deer possession to DNR within 24 hours. Other found-dead deer cannot be moved or possessed until DNR law enforcement grants permission and issues a tag. The tag remains with the deer until parts are consumed or no longer possessed. Parts of either vehicle-killed or other salvaged deer may not be bartered or sold. Only authorized personnel may dispatch an injured deer.

**Action:** ask DNR whether documented gifting is allowed, how loose sheds are treated and which current CWD import rules apply.  
**Primary source:** [17 Ill. Admin. Code Part 750](https://www.ilga.gov/agencies/JCAR/EntirePart?titlepart=01700750).

### Indiana

Indiana’s official materials indicate that a DNR permit is necessary to retain a deer found dead or struck by a vehicle; DNR Central Dispatch is the pre-movement contact. The permit inventory includes a Special Purpose Salvage Permit, but that document should not be assumed to be the ordinary roadkill instrument. Indiana’s current carcass-transport page clearly lists allowed imported parts and the 72-hour registered-processor/licensed-taxidermist route for high-risk material.

**Action:** call Central Dispatch at 812-837-9536 before moving a deer, then ask the permit coordinator at 317-232-4102 for written rules on retained parts, gifting and sale.  
**Primary sources:** [permit inventory](https://www.in.gov/dnr/fish-and-wildlife/licenses-and-permits/permits-commercial-licenses/); [BOAH operational guidance](https://www.in.gov/boah/files/AnimalFoodPrdtDispsitnSOG6-12-17Final.pdf); [carcass transportation](https://www.in.gov/dnr/fish-and-wildlife/wildlife-resources/animals/white-tailed-deer/deer-carcass-transportation); [CWD](https://www.in.gov/dnr/fish-and-wildlife/wildlife-resources/wildlife-diseases-in-indiana/chronic-wasting-disease-cwd/).

### Iowa

Iowa’s new Chapter 80 became effective June 17, 2026. A person seeking game accidentally killed by a motor vehicle on a highway must immediately contact an officer, receive a signed salvage tag before possession and remove the whole carcass. The tag is nontransferable and stays until consumption. Spotted fawn deer and hen pheasants are excluded. Naturally shed deer antlers may be collected year-round. A found-dead antlered deer head requires a hunting license/habitat fee unless exempt and either advance electronic authorization (February 1–July 31) or an officer’s physical tag (August 1–January 31). The authorization stays affixed. The rule permits legal sale of hides, plumage or antlers only as a secondary benefit, not the primary purpose of officer salvage.

**Action:** ask DNR Law Enforcement to confirm gift treatment, sale categories and current cervid import rules.  
**Primary source:** [2026 adopted Chapter 80, pp. 72–75](https://www.iowadnr.gov/media/9533/download).

### Kansas

Kansas requires a salvage tag before removing a deer carcass or any part from a crash site; KHP troopers, sheriff’s deputies and KDWP game wardens may issue it. Dead big game and turkey outside season require KDWP salvage tags, and antlers may not be cut from roadkills or found skulls without the tag. A tag does not itself authorize commerce. Kansas currently says it has no general CWD carcass transportation ban, but origin, transit and destination states may be stricter.

**Action:** ask the local game warden about loose sheds, gift documentation, export and commerce for the precise species/part.  
**Primary sources:** [salvage tags](https://ksoutdoors.com/Hunting/Hunting-Regulations/General-Information/Salvage-Tag); [vehicle crashes](https://ksoutdoors.com/Wildlife-Habitats/Wildlife-Vehicle-Crashes); [possession statute](https://kslegislature.gov/b2025_26/laws/032_000_0000_chapter/032_010_0000_article/032_010_0004_section/032_010_0004_k/); [commercialization statute](https://kslegislature.gov/b2023_24/laws/032_000_0000_chapter/032_010_0000_article/032_010_0005_section/032_010_0005_k/); [CWD transport](https://ksoutdoors.com/Hunting/Big-Game-Information/CWD/CWD-Regulations-for-Kansas-and-Other-States).

### Kentucky

No current official page reviewed here grants an ordinary member of the public a right to claim roadkill or found remains. Kentucky provides a reporting route for sick/dead deer and detailed documentation for hunter-harvested animals, but harvest transfer rules cannot be substituted for salvage authority. Official guidance also restricts buying, selling, trading or bartering native wildlife or parts obtained from the wild without the specified permit framework. CWD surveillance zones and the statewide import ban restrict whole/high-risk cervid material entering, leaving or passing through relevant areas.

**Action:** ask KDFWR Law Enforcement in writing for roadkill, deadhead, shed, gift and wild-origin commerce rules. Report sick/dead deer at 1-800-858-1549.  
**Primary sources:** [CWD FAQ](https://fw.ky.gov/Wildlife/Pages/CWD-FAQ.aspx); [tagging/transfer/transport](https://fw.ky.gov/Hunt/Pages/Recording%2C-Checking%2C-Tagging-and-Transporting.aspx); [general wildlife commerce](https://fw.ky.gov/Hunt/Pages/General-Information.aspx); [CWD zone](https://fw.ky.gov/Wildlife/Pages/CWD-SurveillanceZone.aspx).

## Publication controls

- Label every state entry with “verified 2026-08-18” and a visible confidence field.
- Put an “agency confirmation required” badge beside every unresolved path.
- Never turn “may possess after permit” into “may collect.” Acquisition and possession are separate.
- Never turn a CWD low-risk transport exception into collection or sale authority.
- Never turn a harvest transfer rule into a salvage transfer rule.
- Place federal-protection and land-manager warnings before the state table, not in fine print.
- Require a fresh verification before publication and again before a reader acts; rules, CWD zones and emergency orders change.

## Highest-priority verification queue

1. California: operational status of Fish & Game Code 2000.6.
2. Alabama, Arkansas, Florida, Georgia, Hawaii and Kentucky: ordinary roadkill acquisition procedure.
3. Alaska: public roadkill program and land-unit shed rules.
4. Indiana: exact ordinary-public permit instrument and disposition terms.
5. All states: gifting documentation and commerce treatment for each species/part.
6. All states: the live CWD map, emergency orders and every transit-state restriction immediately before movement.

