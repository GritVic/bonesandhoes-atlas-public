# BonesAndHoes Legal Navigation Master

## Role in the Atlas

This is a supporting trust resource for Anna and Haley, not the main market story. It provides a safe decision route and an index to the detailed federal and 50-state research. It does not promise that a particular item or action is lawful, and it does not replace advice from the controlling authority or a qualified attorney.

The public-facing guide can be a valuable free digital asset because it solves a real entry problem and directs users to current official sources. It must remain dated, correctable, and clear about uncertainty.

## The decision sequence

Before touching, moving, keeping, preparing, gifting, transferring, transporting, or selling wildlife material, determine:

1. What species is it, and how certain is the identification?
2. Where exactly is it: state, county, landowner, road, park, refuge, forest, tribal land, or other managed property?
3. How did it die or become available: lawful harvest, vehicle collision, natural death, naturally detached shed, gift, purchase, inheritance, or import?
4. What action is proposed: observation, collection, possession, preparation, personal display, gift, transfer, sale, shipment, or interstate movement?
5. What authorization and records exist: permit, tag, incident report, landowner consent, receipt, transfer record, photographs, location, date, and agency response?
6. Where will it go next, and what destination rules apply?

A rule authorizing one step does not automatically authorize the others.

## Federal overlay

The detailed federal package covers:

- native migratory birds;
- bald and golden eagles;
- endangered and threatened species;
- marine mammals;
- the Lacey Act;
- CITES and international movement;
- Chronic Wasting Disease routing;
- National Park Service land;
- national wildlife refuges;
- Bureau of Land Management land;
- National Forest System land;
- District of Columbia;
- tribal-jurisdiction routing;
- minimum provenance records.

Federal rules can override or narrow a state pathway. Land rules remain separate from species and possession rules.

## Fifty-state package

The 50 states are divided into three non-overlapping primary-source tranches:

### Alabama through Kentucky — 17 states

Alabama, Alaska, Arizona, Arkansas, California, Colorado, Connecticut, Delaware, Florida, Georgia, Hawaii, Idaho, Illinois, Indiana, Iowa, Kansas, Kentucky.

File pair:

- BonesAndHoes_Legal_Navigation_AL-KY_Report_2026-08-18.md
- BonesAndHoes_Legal_Navigation_AL-KY_2026-08-18.csv

### Louisiana through North Dakota — 17 states

Louisiana, Maine, Maryland, Massachusetts, Michigan, Minnesota, Mississippi, Missouri, Montana, Nebraska, Nevada, New Hampshire, New Jersey, New Mexico, New York, North Carolina, North Dakota.

File pair:

- BonesAndHoes_Legal_Navigation_17_States_Report_2026-08-18.md
- BonesAndHoes_Legal_Navigation_17_States_2026-08-18.csv

### Ohio through Wyoming — 16 states

Ohio, Oklahoma, Oregon, Pennsylvania, Rhode Island, South Carolina, South Dakota, Tennessee, Texas, Utah, Vermont, Virginia, Washington, West Virginia, Wisconsin, Wyoming.

File pair:

- BonesAndHoes_Legal_Navigation_OH-WY_Report_2026-08-18.md
- BonesAndHoes_Legal_Navigation_OH-WY_2026-08-18.csv

Together these ranges contain exactly 50 unique states.

## Required state-record fields

Every structured state entry should identify:

- vehicle-killed wildlife pathway;
- naturally found remains;
- naturally shed antlers;
- protected species overlay;
- land jurisdiction;
- acquisition route;
- possession and personal use;
- gift or transfer;
- commerce;
- resident status where relevant;
- permit, reporting, or agency-contact path;
- CWD and cervid import restrictions;
- interstate transport;
- primary-source links;
- confidence;
- unresolved ambiguity;
- next verification action;
- access date.

## Publication rules

- Never infer permission because a public rule could not be located.
- Use official agency and statute links wherever available.
- Show the verification date.
- Separate high-confidence rules from unresolved questions.
- Tell the reader which agency or officer to contact next.
- Avoid universal statements about what may be sold, gifted, or moved.
- Keep federal, state, tribal, landowner, and destination rules visible as separate gates.
- Preserve provenance records with the item.
- Recheck rules before publication and at a defined maintenance interval.
- Provide a correction route.

## Minimum provenance record

- source date and location at an appropriate privacy level;
- species identification and confidence;
- acquisition method;
- landowner or land-manager permission;
- permit, tag, incident report, or agency contact;
- photographs before and after collection where appropriate;
- receipt or transfer record;
- preparation and treatment notes;
- intended use;
- every later transfer and destination;
- links and access dates for the rules relied upon.

## Main-Atlas treatment

The main Atlas should show only the six-question decision route, a short explanation of why rules differ, the provenance record, and a link to the full guide. State-by-state detail belongs in the companion resource.

The tone should be enabling: verify the route, document it, and then return to making. The legal section should protect the opportunity rather than consume the project.
