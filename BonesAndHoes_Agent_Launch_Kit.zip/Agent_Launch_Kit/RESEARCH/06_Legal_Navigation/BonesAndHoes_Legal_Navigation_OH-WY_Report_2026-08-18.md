# BonesAndHoes Legal Acquisition and Personal-Use Navigation Guide
## Ohio through Wyoming — primary-source verification tranche

**Verified:** 2026-08-18  
**Coverage:** Ohio, Oklahoma, Oregon, Pennsylvania, Rhode Island, South Carolina, South Dakota, Tennessee, Texas, Utah, Vermont, Virginia, Washington, West Virginia, Wisconsin, Wyoming (16 states)

## How to use this guide

This is a navigation guide, not legal advice. It separates distinct legal questions that are often mistakenly collapsed into one: acquiring vehicle-killed wildlife, finding remains away from a roadway, collecting naturally shed antlers, possessing and using parts, transferring or selling them, crossing land boundaries, and transporting cervid material. A rule that authorizes one activity does not authorize the others. Federal law, tribal law, protected-species law, land-manager rules, local road-safety rules, and property permission may independently control.

**Safe default:** do not touch or move wildlife or parts until the species, land jurisdiction, and required authorization are confirmed. Never infer permission from agency silence. Keep every permit, registration confirmation, receipt, transfer record, photograph, and source record with the material.

Confidence means confidence in the stated navigation rule, not a guarantee that every possible fact pattern is covered.

---

## Ohio

- **Vehicle-killed wildlife:** A driver who kills a deer on a highway may take possession but must report the collision within 24 hours. The investigating officer may issue a certificate. If the driver does not claim the deer, an officer may issue the certificate to an eligible institution, charity, or another person under ORC 1533.121.
- **Found remains and sheds:** No broad authorization for taking naturally found carcasses or parts was verified. Naturally shed antlers are not treated as automatically collectible on every land class; confirm land-manager and ODNR rules before removal.
- **Possession / personal use:** Deer and deer parts require the applicable tag, certificate, or receipt. Documentation must remain with or be available for the part as required by Ohio Administrative Code 1501:31-15-11.
- **Gift / transfer / commerce:** The roadkill certificate is proof of lawful origin, not a blanket commercial authorization. Confirm the exact item and contemplated transfer with ODNR; do not detach provenance.
- **Land / protected species:** Property consent and land-manager rules still apply. Migratory birds, eagles, threatened and endangered wildlife remain separately controlled.
- **CWD / interstate:** Ohio limits cervid material entering from outside Ohio or a designated disease-surveillance area to specified lower-risk forms, including deboned meat, certain wrapped cuts, cleaned antlers/skull cap, teeth, hides without head/lymph nodes, and finished taxidermy, subject to the exact rule and transit/processor exceptions.
- **Resident status:** The driver rule is not stated as resident-only in the cited statute; confirm ID/document procedures with the officer.
- **Confidence:** High for vehicle-killed deer and documentation; medium for other found remains and later transfer.
- **Next verification:** Ask ODNR Division of Wildlife Law Enforcement whether a non-driver may receive a certificate for a specific carcass/part and whether any authorization exists for non-road naturally found bones.
- **Primary sources:** [ORC 1533.121](https://codes.ohio.gov/ohio-revised-code/section-1533.121); [OAC 1501:31-15-11](https://codes.ohio.gov/ohio-administrative-code/rule-1501%3A31-15-11); [OAC Chapter 1501:31-19](https://codes.ohio.gov/ohio-administrative-code/chapter-1501%3A31-19)

## Oklahoma

- **Vehicle-killed wildlife:** No current, public, primary-source general-public salvage authorization was located in the Oklahoma statutes or ODWC regulations reviewed. Do not take possession on that basis; contact the county game warden before touching or moving it.
- **Found remains and sheds:** No blanket authorization was verified. A found carcass, attached head, claws, teeth, hide, antlers, or horns can implicate protected-wildlife possession and waste rules. Naturally detached sheds still require lawful land access and species verification.
- **Possession / personal use:** Possession must trace to a lawful method of acquisition under Title 29 and ODWC rules. Personal use does not cure unlawful acquisition.
- **Gift / transfer / commerce:** No general right was verified for found material. Obtain a warden determination and retain documentation before any transfer.
- **Land / protected species:** Private permission and the controlling public-land rules are required. Federal protections independently control birds and listed species.
- **CWD / interstate:** Oklahoma restricts import of cervid carcasses and parts; the current big-game regulation page lists permitted processed categories. Check the current CWD map and rule before every interstate movement.
- **Resident status:** Unresolved for any non-harvest authorization because no public salvage pathway was verified.
- **Confidence:** High that no permission should be inferred; low on whether a case-specific nonhunting tag may be issued.
- **Next verification:** Contact the ODWC game warden for the county and request a written answer for the species, location, intended retained parts, personal use, and any later transfer.
- **Primary sources:** [Oklahoma Wildlife Conservation Code, Title 29](https://www.oklegislature.gov/OK_Statutes/CompleteTitles/os29.pdf); [ODWC general hunting regulations](https://www.wildlifedepartment.com/hunting/regs/general-hunting-regulations); [ODWC big-game regulations](https://www.wildlifedepartment.com/hunting/regs/big-game-regulations)

## Oregon

- **Vehicle-killed wildlife:** A person may salvage deer or elk accidentally struck by a vehicle where the program applies. A free permit is required within 24 hours. The entire carcass and gut pile must be removed. The head and antlers must be surrendered to ODFW within five business days. Geographic limits apply to certain white-tailed deer; other big-game species listed by ODFW are not eligible.
- **Found remains and sheds:** The roadkill permit does not authorize naturally found carcasses or parts. Sheds and other finds depend on species, land ownership, seasonal closures, and land-manager rules.
- **Possession / personal use:** The permit establishes lawful roadkill possession subject to its conditions and CWD procedures.
- **Gift / transfer / commerce:** ODFW states salvaged wildlife may not be sold. Transfer is permitted only with the prescribed written Wildlife Transfer Record and within the rule’s limits.
- **Land / protected species:** Tribal, federal, state-park, wildlife-area, and private-property rules can be stricter. Federal bird and listed-species law remains controlling.
- **CWD / interstate:** Follow ODFW’s current testing and carcass-movement directions; permitted roadkill heads may be required for sampling/surrender.
- **Resident status:** The public permit page does not state a resident-only limit.
- **Confidence:** High for deer/elk roadkill; medium for sheds and non-road remains because land-specific rules vary.
- **Next verification:** Obtain written ODFW guidance before taking a non-road carcass, skull, or bone and verify the land manager separately.
- **Primary sources:** [ODFW roadkill salvage permits](https://myodfw.com/articles/roadkill-salvage-permits); [ODFW licenses, permits and forms](https://myodfw.com/licenses-permits-applications-and-forms)

## Pennsylvania

- **Vehicle-killed wildlife:** Current Game Commission guidance limits public salvage to Pennsylvania residents and vehicle-killed deer or turkey for consumption. The driver has priority; if the driver declines, another Pennsylvania resident may claim eligible wildlife. A free permit must be obtained within 24 hours.
- **Found remains and sheds:** No broad authorization for keeping naturally found carcasses or attached parts was verified. Shed collection requires lawful access and any land-specific seasonal restrictions.
- **Possession / personal use:** The roadkill pathway is framed as consumption, not a general parts-acquisition program. Older official digest language states antlers could not be retained under that permit; reconfirm against the current permit terms before relying on it.
- **Gift / transfer / commerce:** Do not assume a consumption permit authorizes gifting, sale, or retaining display parts. Obtain current written confirmation.
- **Land / protected species:** State game lands, parks, federal lands, and private property each have separate access rules. Protected birds and listed species remain off limits without appropriate authorization.
- **CWD / interstate:** High-risk parts may not leave a Disease Management Area or Established Area except as current rules allow; check the live map before transport.
- **Resident status:** Pennsylvania resident only under the cited current agency guidance.
- **Confidence:** High for resident/deer-turkey/24-hour pathway; medium for the precise current treatment of antlers and transfers.
- **Next verification:** Use the Game Commission regional office to confirm whether the current permit permits retention of hide, cleaned bone, or antlers and whether any part may be transferred.
- **Primary sources:** [Pennsylvania Game Commission contact and roadkill guidance](https://www.pa.gov/agencies/pgc/about-us/contact-information); [PGC deer-on-the-move guidance](https://www.pa.gov/agencies/pgc/newsroom/deer-on-the-move-crossing-roads-more); [2023–24 official digest, historical cross-check](https://www.pgc.pa.gov/HuntTrap/Law/Documents/2023-24%20Digest%20lowres.pdf)

## Rhode Island

- **Vehicle-killed wildlife:** Rhode Island’s Wildlife Salvage Permit program allows a person to claim eligible vehicle-killed wildlife by completing the permit within 24 hours. The listed species include white-tailed deer, wild turkey, beaver, coyote, fisher, red and gray fox, muskrat, pheasant, squirrel, rabbit, and raccoon. Fisher and fox require additional contact. The whole animal must be removed. The public may not kill an injured animal for salvage.
- **Found remains and sheds:** The vehicle-kill permit does not establish a general right to collect naturally found remains or attached parts. Confirm with DEM before removal.
- **Possession / personal use:** Permit compliance establishes possession of the eligible vehicle-killed animal; the permit is one per animal.
- **Gift / transfer / commerce:** The public page does not provide blanket transfer or commercial authority. Confirm under 250-RICR-60-00-14 before any transfer.
- **Land / protected species:** Road safety, property rights, land-manager rules, and federal species protections remain separate.
- **CWD / interstate:** No complete current cervid-import rule was verified in this pass; consult DEM before importing any cervid head, spine, skull plate, or unfinished part.
- **Resident status:** The public permit page does not state resident-only eligibility.
- **Confidence:** High for the permit’s species and procedure; medium-low for later transfer and interstate movement.
- **Next verification:** Ask DEM Division of Fish and Wildlife whether hides, cleaned bones, skulls, or antlers acquired under the permit may be retained or transferred, and request the current cervid-import rule.
- **Primary sources:** [Rhode Island Wildlife Salvage Permit](https://dem.ri.gov/wildlife-salvage-permit); [DEM program announcement](https://dem.ri.gov/press-releases/permit-allows-public-salvage-roadkill)

## South Carolina

- **Vehicle-killed wildlife:** SCDNR states a fresh road-killed deer may be kept by the finder or given to a charitable institution if an incident report is obtained from a law-enforcement officer. Report collisions; law enforcement handles euthanasia of injured deer.
- **Found remains and sheds:** No blanket authority was verified for naturally found carcasses, attached parts, or other species. Naturally shed antlers still require permission for the land and confirmation of any site rules.
- **Possession / personal use:** Keep the incident report as provenance. The deer FAQ does not itself authorize every use of every part.
- **Gift / transfer / commerce:** The express charitable transfer does not establish a general commercial right. Confirm any other transfer with SCDNR.
- **Land / protected species:** Property and public-land rules remain separate; federal birds and listed species are independently protected.
- **CWD / interstate:** South Carolina prohibits import or possession of whole cervid carcasses or high-risk parts from CWD-positive jurisdictions, allowing specified lower-risk forms such as boned meat, quarters without head/spine, hides without heads, cleaned skulls/skull plates, detached antlers, cleaned elk ivories, and finished taxidermy.
- **Resident status:** The FAQ does not state resident-only eligibility.
- **Confidence:** High for fresh road-killed deer and CWD import; low-medium for other species and later transfer.
- **Next verification:** Contact SCDNR Wildlife Section for a written determination on retaining cleaned bones/antlers and any acquisition pathway for non-road finds.
- **Primary sources:** [SCDNR deer FAQ](https://www.dnr.sc.gov/wildlife/deer/faqsdeer.html); [SCDNR CWD rules](https://www.dnr.sc.gov/cwd/index.html)

## South Dakota

- **Vehicle-killed wildlife:** For a deer or antelope killed by a motor vehicle on a public highway, notify a conservation officer before possession. The officer may give verbal immediate authorization followed by dated written authorization. The written authorization must stay with the carcass during processing or storage. There is no fee.
- **Found remains and sheds:** Taking any carcass or part of road-killed big game, including antlers, without authorization is illegal. A broad rule for non-road remains was not verified. Naturally detached sheds require lawful land access and any land-specific restrictions.
- **Possession / personal use:** The written authorization permits possession and disposal.
- **Gift / transfer / commerce:** No part obtained through this route may be sold, bartered, or traded.
- **Land / protected species:** Public-road authorization does not grant entry onto adjacent private land. Federal species protections remain separate.
- **CWD / interstate:** South Dakota imposes cervid carcass transportation and disposal requirements. Whole or partial cervid carcasses from another state must ultimately have remaining parts disposed through an accepting waste provider or permitted landfill unless delivered as the rule provides; through-transport is exempt. Moving a carcass outside its South Dakota county of harvest also triggers disposal rules.
- **Resident status:** No resident-only condition appears in the cited statute/FAQ.
- **Confidence:** High.
- **Next verification:** Contact the local conservation officer before collection and ask whether written authorization covers the intended retained parts and later gifting.
- **Primary sources:** [South Dakota GFP FAQ, including SDCL 41-1-5.7](https://gfp.sd.gov/faq/); [South Dakota CWD regulations](https://gfp.sd.gov/cwd-regulations/)

## Tennessee

- **Vehicle-killed wildlife:** A vehicle-killed deer may be possessed for personal use or consumption if TWRA or local law enforcement is notified within 48 hours. Current TWRA guidance says a person wishing to possess big game found dead should contact the regional office first for authorization; bear requires an enforcement possession tag.
- **Found remains and sheds:** Treat found big-game remains as authorization-first. No broad rule was verified for other remains. Sheds require lawful access and site rules.
- **Possession / personal use:** The pathway is personal use/consumption. Albino deer possession is prohibited under the current guide.
- **Gift / transfer / commerce:** No blanket gifting or commercial authority was verified for found or vehicle-killed big game.
- **Land / protected species:** Landowner/manager permission and federal species law remain separate.
- **CWD / interstate:** Imported deer, elk, and moose must be processed into allowed lower-risk forms under TWRA’s current carcass-transport rules; consult the current CWD page before movement.
- **Resident status:** No resident-only term was verified in the cited public guidance.
- **Confidence:** High for notification and personal use; medium for species-specific parts and transfer.
- **Next verification:** Contact the relevant TWRA regional office before collecting found big game, and request written confirmation for any intended art/display use or transfer.
- **Primary sources:** [TWRA FAQ](https://www.tn.gov/twra/frequently-asked-questions.html); [TWRA guides, rules and regulations](https://comptroller.aem.tn.extglb.tn.gov/twra/rules-and-regulations.html); [TWRA carcass transport and disposal](https://comptroller.aem.tn.extglb.tn.gov/content/tn/twra/hunting/cwd/deer-carcass-transport-disposal.html); [TWRA permits](https://www.tn.gov/twra/law-enforcement/permits.html)

## Texas

- **Vehicle-killed wildlife:** TPWD states a dead deer may be moved off the roadway for safety but may not be tagged or taken into possession; TxDOT or the responsible authority removes it. A vehicle collision does not create a lawful game-animal acquisition pathway.
- **Found remains and sheds:** No general right to take naturally found game-animal carcasses or attached parts was verified. Naturally shed antlers still require lawful access and a check of the controlling land rules.
- **Possession / personal use:** Wildlife possession must trace to lawful acquisition. A Wildlife Resource Document supports transfer of lawfully harvested wildlife; it does not legalize a found or road-killed animal.
- **Gift / transfer / commerce:** Texas allows sale of certain inedible parts of lawfully taken/possessed game animals, subject to species-specific and federal restrictions. Proof of lawful origin is essential. Do not apply this rule to roadkill.
- **Land / protected species:** Private permission is required. Nongame, threatened/endangered, migratory-bird, park, and federal-land rules may prohibit collection.
- **CWD / interstate:** Texas restricts carcasses and parts entering from CWD-positive jurisdictions and movement from Texas CWD zones; permitted lower-risk forms and documentation are specified by current TPWD rules. Statewide disposal rules apply to harvested deer.
- **Resident status:** Not relevant to the game-animal roadkill prohibition; separate licenses/documents govern lawful harvest and transfer.
- **Confidence:** High.
- **Next verification:** Ask the local TPWD game warden about any found non-game item before removal and obtain a written lawful-origin record for anything transferred or listed for sale.
- **Primary sources:** [TPWD general hunting FAQ](https://tpwd.texas.gov/faq/huntwild/general_questions.phtml); [TPWD laws, penalties and restitution](https://tpwd.texas.gov/regulations/outdoor-annual/hunting/general-regulations/laws-penalties-restitution/); [TPWD transfer and importation](https://tpwd.texas.gov/regulations/outdoor-annual/hunting/general-regulations/transfer-of-wildlife); [TPWD CWD rules](https://tpwd.texas.gov/regulations/outdoor-annual/hunting/cwd/)

## Utah

- **Vehicle-killed wildlife:** Utah’s public Roadkill Reporter records vehicle kills, but no general public carcass-salvage authorization was verified from that reporting tool. Report a neighborhood or park carcass for agency removal; do not assume reporting grants possession.
- **Found remains and sheds:** A skull of a big-game animal with antlers/horns attached must not be moved until submitted through the Utah Deadhead Reporter and an electronic approval license is received. Naturally detached sheds are a different category but still require lawful access, observance of seasonal shed-gathering rules, and land-manager permission.
- **Possession / personal use:** Utah Code 23A-20-3, as cited by DWR, requires the necessary license, permit, or tag before possession of an antler/horn still attached to a skull. Keep the electronic approval available in the field.
- **Gift / transfer / commerce:** Deadhead approval does not state broad commercial authority. Confirm any transfer or commerce with DWR and retain the approval/provenance.
- **Land / protected species:** Do not remove material from national parks or other prohibited lands; private permission and agency rules apply. Federal bird/listed-species rules remain separate.
- **CWD / interstate:** Utah maintains CWD testing and carcass-disposal guidance. Exact import/movement conditions should be checked for the current unit and destination before transport.
- **Resident status:** The Deadhead Reporter requires a DWR customer ID but does not state resident-only eligibility.
- **Confidence:** High for attached-antler skulls; medium-low for general roadkill carcass salvage.
- **Next verification:** Ask DWR Law Enforcement whether any public authorization permits retaining a vehicle-killed carcass or cleaned parts, and verify current shed-season and land-unit closures.
- **Primary sources:** [Utah Deadhead Reporter](https://wildlife.utah.gov/deadhead); [Utah Certificates of Registration](https://wildlife.utah.gov/cor); [Utah wildlife encounter guidance](https://wildlife.utah.gov/news/2021/12/01/when-you-should-report-a-wildlife-sighting-or-encounter); [Utah CWD guidance](https://wildlife.utah.gov/diseases/cwd)

## Vermont

- **Vehicle-killed wildlife:** Vermont law authorizes designated officials to euthanize severely injured deer and requires the official to report it; the animal is disposed of under state authority. No current primary-source general-public roadkill-retention program was verified. Contact a state game warden before possession.
- **Found remains and sheds:** Wildlife is held in trust by the state. No blanket public authorization for naturally found carcasses or attached parts was located. Scientific, educational, art, and photography collection can require a permit under 10 V.S.A. §4152. Sheds require lawful access and a land-rule check.
- **Possession / personal use:** Big game possessed must be lawfully taken/acquired. Personal use does not independently authorize acquisition.
- **Gift / transfer / commerce:** Purchase and sale of big game are separately controlled; no authority was found for commercial use of found material.
- **Land / protected species:** Department lands prohibit collecting plants and may separately regulate wildlife collection; federal protections remain controlling.
- **CWD / interstate:** Current Vermont guidance restricts higher-risk cervid material and requires checking import/possession rules; the exact current permitted-part list should be confirmed before movement.
- **Resident status:** Unresolved because no general public roadkill pathway was verified.
- **Confidence:** High that prior warden authorization is the safe route; low-medium on any case-specific disposition option.
- **Next verification:** Ask the district game warden for written authorization or denial for the exact species, part, location, personal use, and any contemplated transfer; ask whether §4152 art/photography permit applies.
- **Primary sources:** [10 V.S.A. Chapter 113](https://legislature.vermont.gov/statutes/fullchapter/10/113); [10 V.S.A. §4513](https://legislature.vermont.gov/statutes/section/10/109/04513); [10 V.S.A. §4152](https://legislature.vermont.gov/statutes/section/10/103/04152); [Vermont Fish and Wildlife Regulations](https://legislature.vermont.gov/statutes/fullchapter/10APPENDIX/001)

## Virginia

- **Vehicle-killed wildlife:** A person involved in a collision that kills a deer or bear must immediately report it to a conservation police officer or other law enforcement. The driver may keep it for personal use only after an officer views the animal and issues a possession certificate.
- **Found remains and sheds:** A public salvage permit exists for scientific/educational and other authorized collection, not as an automatic public right. No broad authorization was verified for naturally found game remains. Sheds require lawful access and land-specific confirmation.
- **Possession / personal use:** The officer-issued certificate is the lawful-origin document for the driver’s vehicle-killed deer/bear.
- **Gift / transfer / commerce:** The cited driver pathway is for the driver’s own use. No blanket right to gift or sell was verified.
- **Land / protected species:** Private permission and public-land rules apply. Federal protections independently control migratory birds, eagles, and listed species.
- **CWD / interstate:** Virginia has current CWD carcass-movement rules that vary by management area and origin. Confirm the live DWR map and allowed-part rules before moving cervid material.
- **Resident status:** The FAQ does not state resident-only eligibility, but the eligible claimant is the involved driver.
- **Confidence:** High for driver/report/certificate; medium-low for found remains and transfer.
- **Next verification:** Ask a DWR conservation police officer whether a certificate permits retaining particular cleaned parts and whether any transfer is allowed.
- **Primary sources:** [Virginia DWR deer FAQ](https://dwr.virginia.gov/wildlife/deer/faq/); [DWR permit contacts](https://dwr.virginia.gov/permits/contacts/); [DWR forms](https://dwr.virginia.gov/forms/)

## Washington

- **Vehicle-killed wildlife:** Deer or elk accidentally killed by a vehicle may be salvaged. A WDFW permit is required within 24 hours; the entire carcass, including entrails, must be removed. The public may not euthanize an injured animal for salvage. Current 2026 amendments require CWD sampling in a region where CWD has been detected.
- **Found remains and sheds:** Possession of wildlife found dead is unlawful unless permitted or expressly authorized. The rule expressly allows naturally shed deer, elk, or moose antlers. Wildlife removed from one’s property or adjoining roadway under the disposal provision may not be retained for use or consumption.
- **Possession / personal use:** Keep the salvage permit. WDFW does not guarantee fitness for consumption.
- **Gift / transfer / commerce:** The roadkill page/rule does not provide blanket commercial authority. Confirm transfer and sale separately.
- **Land / protected species:** The shed exception does not override trespass, closures, tribal jurisdiction, federal lands, or protected-species rules. Columbian white-tailed deer remain federally protected even though the geographic roadkill exclusion was removed.
- **CWD / interstate:** In a WDFW region with detected CWD, submit the whole head with at least three inches of neck or extracted lymph nodes within five days. Import/retention rules for nonresident wildlife also apply.
- **Resident status:** No resident-only limit appears in the salvage rule.
- **Confidence:** High.
- **Next verification:** Check the current WDFW CWD-region map and ask enforcement before retaining or transferring any non-deer/elk found part.
- **Primary sources:** [WDFW roadkill salvage](https://wdfw.wa.gov/licenses/roadkill-salvage); [current Chapter 220-400 WAC](https://lawfilesext.leg.wa.gov/Law/WAC/WAC%20220%20%20TITLE/WAC%20220%20-400%20%20CHAPTER/WAC%20220%20-400%20%20CHAPTER.htm); [2026 adopted amendment](https://lawfilesext.leg.wa.gov/law/wsrpdf/2026/04/26-04-120.pdf)

## West Virginia

- **Vehicle-killed wildlife:** Wildlife accidentally/inadvertently struck by a vehicle may be possessed except protected birds, elk, spotted fawns, and bear cubs. The possessor must notify a relevant law-enforcement agency within 12 hours and obtain a nonhunting game tag within 24 hours. Species including deer, bear, turkey, wild boar, bobcat, beaver, otter, and fisher also require electronic registration under the statute/rules.
- **Found remains and sheds:** Naturally shed deer antlers may be collected from one’s own land, public land unless prohibited, or private land with written landowner permission in hand. This shed exception does not authorize attached antlers, skulls, carcasses, or other remains.
- **Possession / personal use:** Keep the nonhunting tag and registration proof. Other wildlife or parts must be lawfully taken, killed, or obtained.
- **Gift / transfer / commerce:** No blanket authority was verified for sale or transfer of nonhunting-tag material; confirm species-specific law before doing so.
- **Land / protected species:** Public-land prohibitions and private written permission govern shed collection. Migratory birds remain subject to federal law.
- **CWD / interstate:** West Virginia maintains CWD-area carcass-movement rules. Confirm the current containment-area counties and allowed parts before transport.
- **Resident status:** The statute does not state resident-only eligibility.
- **Confidence:** High for vehicle-kill and sheds; medium for commerce/interstate specifics.
- **Next verification:** Obtain the nonhunting tag from the responding agency and ask WVDNR to document which parts may be retained/transferred and current CWD movement limits.
- **Primary sources:** [West Virginia Code §20-2-4](https://code.wvlegislature.gov/pdf/20-2-4/); [WVDNR scientific collecting permit](https://wvdnr.gov/plants-animals/scientific-collecting-permit/); [2026–27 WVDNR hunting and trapping guide](https://wvdnr.gov/wp-content/uploads/2026/07/Pub_Regs_HuntTrap_202627_DNR_WILD_20260724-1.pdf)

## Wisconsin

- **Vehicle-killed wildlife:** Any person may claim an accidentally vehicle-killed deer, bear, or turkey, with the driver having first priority. Deer and turkey must be registered before possession or removal; bear requires contacting DNR for a tag. A DNR customer ID is required. Other small-game roadkill is collectible only under the specific license, season, and species conditions stated by DNR.
- **Found remains and sheds:** The vehicle-kill process does not establish a general right to collect naturally found carcasses or attached parts. Sheds require lawful access and land-specific rules.
- **Possession / personal use:** After notification, a vehicle-killed deer or turkey may be possessed and transported without a harvest authorization/tag; keep the registration confirmation. Bear must carry the issued tag.
- **Gift / transfer / commerce:** No blanket transfer or commercial authority appears on the roadkill page. Confirm with DNR before transfer and preserve the registration/tag.
- **Land / protected species:** The small-game exception excludes fisher, otter, bobcat, wolf, migratory birds, and protected/endangered/threatened species. Property and land-manager permission remain necessary.
- **CWD / interstate:** Vehicle-killed deer must comply with Wisconsin’s CWD transportation rules. Check the current county and carcass-movement page before moving the animal or parts.
- **Resident status:** Any person may claim, but a DNR customer ID is required.
- **Confidence:** High.
- **Next verification:** Ask DNR whether a registered vehicle-killed animal’s cleaned bones, hide, or antlers may be transferred or sold and whether additional documentation is required.
- **Primary sources:** [Wisconsin DNR wildlife-vehicle collisions](https://dnr.wisconsin.gov/topic/WildlifeHabitat/cardeer.html); [Wisconsin DNR CWD](https://dnr.wisconsin.gov/topic/WildlifeHabitat/cwd.html)

## Wyoming

- **Vehicle-killed wildlife:** Prior authorization through the Wyoming 511 app/desktop process is required. Eligible species include deer, elk, antelope, moose, wild bison, and wild turkey. Collection is daylight-only, prohibited on I-25, I-80, I-90, active construction areas, and National Park Service road segments. The whole animal must be removed; parts alone cannot be collected; no field dressing in the right-of-way.
- **Found remains and sheds:** A big-game head/skull with attached antlers or horns found in the field requires prior approval from a game warden and may require an Interstate Game Tag. Naturally detached shed antlers are governed separately by lawful access and any seasonal shed-gathering restrictions.
- **Possession / personal use:** Keep the roadkill authorization. The whole-animal and disposal conditions continue after collection.
- **Gift / transfer / commerce:** Roadkill-collected meat may not be donated to a nonprofit. No blanket commercial authority was verified. Parts-only collection is prohibited under the roadkill rule.
- **Land / protected species:** National parks are excluded. Private access, public-land rules, federal species protections, and any shed-season closures remain separate.
- **CWD / interstate:** Deer, elk, and moose heads and spinal columns collected under roadkill authorization must be disposed of at an approved Wyoming landfill/incinerator under Chapter 70. Interstate movement and attached antlers can require an Interstate Game Tag.
- **Resident status:** No resident-only term appears on the public roadkill page; an account is required.
- **Confidence:** High.
- **Next verification:** Use the 511 authorization before collection, then ask the local warden about any intended retention of skull/antler/hide and crossing state lines.
- **Primary sources:** [WGFD roadkill collection](https://wgfd.wyo.gov/licenses-applications/permits/roadkill-collection); [WGFD Chapter 70 regulation](https://wgfd.wyo.gov/sites/default/files/content/PDF/Regulations/CH-70-FINAL.pdf); [WGFD attached-antler skull guidance](https://wgfd.wyo.gov/Ask-Game-and-Fish/Jim%2C-can-I-legally-remove-the-head-with-antlers-or)

---

## Cross-state publication rules

1. Present these entries as a **starting decision path**, not a permission slip.
2. Date-stamp every state card and link directly to the live agency/statute page.
3. Show separate icons or fields for roadkill, non-road remains, naturally detached sheds, land access, transfer, commerce, CWD/import, and federal overlay.
4. A blank or unresolved field must read **“Confirm with agency before possession”**, never “allowed.”
5. Any shop or affiliate workflow should cover tools, preparation supplies, display hardware, and lawful substrates—not wildlife whose lawful origin cannot be documented.
6. Re-verify all live rules immediately before publication and at least quarterly thereafter; update sooner when a disease-management area changes.

## Tranche QA

- 16 requested states present.
- Every state includes direct government/agency URLs and an access date through this report header.
- Roadkill, found remains, sheds, protected species/land, possession/personal use, gifting/transfer, commerce, resident status, permits/reporting, CWD/import, interstate considerations, confidence, ambiguity, and next action are separately addressed.
- Unresolved questions are labeled; no permission is inferred from silence.
- Federal and tribal overlays are intentionally delegated to the separate federal/DC/tribal package.
