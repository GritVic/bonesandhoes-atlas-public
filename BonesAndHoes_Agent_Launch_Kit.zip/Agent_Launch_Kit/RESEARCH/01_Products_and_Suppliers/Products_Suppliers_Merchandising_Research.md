# BonesAndHoes Product, Supplier, Project, and Merchandising Research

**Research date:** August 18, 2026  
**Decision supported:** Which product and merchandising opportunities should BonesAndHoes pursue first, with no initial inventory, and which products merit later development?  
**Audience:** Anna, Haley, and the Atlas production team  
**Scope:** Finished-project patterns; supporting products; suppliers; affiliate, reseller, and wholesale paths; adjacent shops; merchandising gaps; provisional economics. This is a commerce study, not legal advice or a biological-material sales plan.

## Executive Summary

- **The best bootstrapped position is “project-to-supply translator.”** Finished-work marketplaces show broad demand across framed assemblages, glass-dome displays, wall pieces, jewelry, carved and painted skull art, and museum-like tabletop presentations. Yet the surrounding supplies are fragmented across craft, hardware, display, photography, labeling, and packing vendors. BonesAndHoes can turn each creator feature or project video into a verified bill of materials and shopping path without holding inventory.
- **Start with affiliate commerce and demand measurement, not a broad reseller operation.** Lowe’s currently advertises creator commissions up to 20%; Michaels MakerPlace documents 10%–15% on linked Michaels supplies; Displays2Go has an affiliate program and an independently reported rate up to 8%; Avery advertises up to 10%; B&H starts at 2%; Amazon’s relevant categories are generally 3%. These paths externalize fulfillment and returns. By contrast, Displays2Go’s entry reseller discount is 10%, which would be consumed by ordinary marketplace/payment fees before shipping or customer support.
- **The clearest later owned-product gap is refined, modular display hardware for artists.** Existing stand choices divide between generic acrylic boxes and hunting-oriented wall hardware. Etsy shows hundreds of stand listings and prices commonly around $38–$99, while finished framed or domed work commonly spans roughly $40–$326 in sampled listings. A discreet, size-labeled, museum-like small-specimen stand, modular rod-and-clamp system, reversible base, or integrated enclosure-and-label system is a credible product-development lane after demand is measured.
- **Commerce must stay attached to authentic making.** Each video should show the real item being used, then link a complete supply list below. The shop should offer many compatible choices instead of forcing a single prescribed look. Creator spotlights should credit the artist, seek permission where needed, and link the artist before presenting adjacent supplies.

## What the Market Is Showing

### Finished-work formats with observable current listings

The examples below are market observations, not a claim that every listing has sold. Review counts shown by Etsy may belong to the listing or its shop and should be treated as directional demand evidence rather than unit sales.

| Project format | Current example and observed price | Supporting-product implications | Evidence |
|---|---:|---|---|
| Small skull in glass dome | Gecko skull dome, **$48.99** | Dome, wood base, slender rod, moss, adhesive, label | [Etsy skull-display market](https://www.etsy.com/market/skull_display_dome) |
| Snake skull/skeleton in glass dome | **$74.71–$117.67** sampled | Dome, rod, base, decorative insert, protective packing | [Etsy dome listing](https://www.etsy.com/listing/4480554113/gothic-skeleton-art-display-under-glass) |
| Squirrel skull cloche | **$87.50** | Glass cloche, natural substrate, discreet attachment | [Etsy skull-display market](https://www.etsy.com/market/skull_display_dome) |
| Raccoon skull botanical cloche | **$135** | Large cloche, faux botanicals, minerals, base | [Etsy skull-display market](https://www.etsy.com/market/skull_display_dome) |
| Small vial/cork display | **$12.50** | Mini dome/vial, cork, moss, small label | [Etsy skull-display market](https://www.etsy.com/market/skull_display_dome) |
| Fox vertebrae shadow box | **$167** | Deep frame, backing, attachment wire/adhesive, label | [Etsy bone-shadow-box market](https://www.etsy.com/market/bone_shadow_box) |
| Fox jaw shadow box | **$68–$145** sampled | Shadow box, velvet/linen backing, pins, wall hardware | [Etsy bone-shadow-box market](https://www.etsy.com/market/bone_shadow_box) |
| Raccoon skull botanical shadow box | **$185** | Deep wood frame, botanicals, mounting hardware | [Etsy bone-display market](https://www.etsy.com/market/bone_display_shadow_box) |
| Coffin-frame snake assemblage | **$326.44** sale price | Custom frame, skeleton articulation, attachment, glass/acrylic | [Etsy bone-display market](https://www.etsy.com/market/bone_display_shadow_box) |
| Crystalized skeleton composition | **$142.50** sale price | Shadow box, crystals, flowers, bonding materials | [Etsy bone-shadow-box market](https://www.etsy.com/market/bone_shadow_box) |
| Mixed bone, moss, flower and crystal wall art | **$79.99** | Frame, moss, botanicals, mineral, chain, adhesive | [Etsy bone-shadow-box market](https://www.etsy.com/market/bone_shadow_box) |
| Jawbone floral artwork | **$40–$100** sampled | Frame, substrate, botanicals, attachment system | [Etsy bone-shadow-box market](https://www.etsy.com/market/bone_shadow_box) |
| Metal tabletop skull display | Stand alone **$38–$60** | Powder-coated stand, plate, rod, compatibility guide | [Etsy metal-stand market](https://www.etsy.com/market/metal_skull_stand) |
| Wood-slice and metal skull stand | **$88.96** | Natural base, welded rod, protective feet | [Etsy metal-stand market](https://www.etsy.com/market/metal_skull_stand) |
| Large skull pedestal | **$46.75–$94.99** | Acrylic/wood pedestal, mounting interface | [Etsy pedestal market](https://www.etsy.com/market/skull_mount_pedestal) |
| Carved ram-skull art with stand | **$300–$331.65** sampled | Carving tools, finish, substantial stand, packing | [Etsy ram-stand market](https://www.etsy.com/market/ram_skull_stand) |
| Rattlesnake vertebrae necklace | **$10–$48** sampled | Drill bits, rotary tool, wire, findings, clasps, polishing | [Etsy bone-jewelry market](https://www.etsy.com/market/bone_jewelry) |
| Bone moth jewelry | **about $32** | Micro drill, wire, findings, finish, presentation card | [Etsy bone-jewelry market](https://www.etsy.com/market/bone_jewelry) |
| Rib-bone necklace | **$28** | Drill/polish, cord/chain, clasp, card/box | [Etsy bone-jewelry market](https://www.etsy.com/market/bone_jewelry) |
| Mixed-media assemblage | Artist practice spans wood, clay, textile, ephemera, paint, and bone | Broad substrate and finish library | [Stefanie Vega](https://stefanievega.com/about-vega/) |
| Wall, shelf, jewelry, drum and wearable art | Multiple forms in one artist practice | Cross-category project taxonomy and supply lists | [The Green Wolf artwork](https://thegreenwolf.com/artwork/) |
| High-end natural-bone jewelry | Dedicated luxury positioning | Fine findings, presentation, photography, provenance | [Ossuaria](https://www.ossuaria.com/about) |
| Bone-ring jewelry | Rat skull and other bone rings | Ring findings, rotary tool, polish, micro photography | [Jennifer Podisdead](https://www.jenniferpodisdead.com/work/nyc-rat-skeleton-jewelry) |
| Framed insect/natural-history art | **$40–$125+** sampled at Paxton Gate | Double-glass frames, Riker frames, labels, display lighting | [Paxton Gate](https://paxtongate.com/) |
| Resin-embedded insect collections | **$79–$109** at Evolution | Casting resin, molds, polishing, packaging | [Evolution Store entomology](https://theevolutionstore.com/categories/entomology/) |

### Demand and price signals

- Etsy displayed **655+** results for “bone shadow box” and **901+** for “display stands for skulls” during this pass. Search-result counts are fluid and include irrelevant items, but they demonstrate that the customer vocabulary and merchandising formats are established. [Bone shadow boxes](https://www.etsy.com/market/bone_shadow_box), [display stands](https://www.etsy.com/market/display_stands_for_skulls)
- The sampled finished-piece price ladder is broad: mini displays around **$12.50**, framed pieces often **$40–$185**, complex coffin-framed work around **$326**, and extraordinary one-off natural-history pieces far higher. This supports good/better/best merchandising rather than one fixed kit.
- A current review on an established Etsy oddities shop specifically wished a piece had been placed under **glass rather than plastic**. This is only one qualitative comment, but it is a useful hypothesis: material authenticity and enclosure quality may matter enough to test. [oddconserva](https://www.etsy.com/shop/oddconserva)
- Paxton Gate combines objects, framed work, workshops, gift cards, and editorial-style curation. That is a stronger reference model than a raw catalog because it joins learning, discovery, and purchasing. [Paxton Gate](https://paxtongate.com/)

## Project-to-Product Taxonomy

Every finished-work feature should be tagged against this taxonomy so the same content can power the Atlas, shop collections, buying guides, and videos.

| Stage | Product families | Natural content moment |
|---|---|---|
| Field documentation | phone/camera support, ruler/scale, notebook, labels, bags, location logging, gloves | discovery and lawful documentation |
| Safe handling | chemical-resistant gloves, splash goggles, respirator where product instructions require it, aprons, tubs, tongs | preparation setup and safety explanation |
| Cleaning and preparation | dedicated containers, brushes, strainers, degreasing supplies, low-concentration peroxide products where appropriate, drying racks | process tutorial with explicit safety limits |
| Cutting, drilling and shaping | rotary tools, micro bits, flex shafts, engraving tools, hand drills, saws, clamps | controlled studio technique |
| Attachment | epoxy, craft adhesive, pins, wire, threaded rod, brass rod, clear rod, micro clamps, brackets | assembling the work |
| Substrates | wood plaques, slabs, cork, velvet, linen, preserved moss, stone/mineral accents, shadow-box backings | design choice and composition |
| Enclosures | glass domes, acrylic cubes, shadow boxes, double-glass frames, wall cases | final protection and presentation |
| Mounts and stands | wall brackets, table stands, rods, pedestals, adjustable arms, base plates | final display decision |
| Finishing | paints, stains, waxes, sealers, polishing systems, protective feet | finishing sequence and aesthetic options |
| Documentation | provenance cards, legal-source notes, species labels, QR codes, care cards | trust, education, and gifting |
| Photography | light box, sweep, turntable, tripod, scale/color card | listing photos and project reveal |
| Storage | clear bins, archival boxes, dividers, labels, humidity control | studio organization |
| Packing and shipping | 200/275-pound-test boxes, glass partitions, foam, bubble cushioning, fragile labels | fulfillment and damage prevention |

## Representative Product and Price Ledger

Prices were observed on August 18, 2026 and can change. Availability is based on the cited page at access time. Shipping, tax, and location effects are excluded.

### Display, frame, and mounting products

| Product | Observed price | Availability/constraint | Best use | Source |
|---|---:|---|---|---|
| shopPOP 4-inch acrylic five-sided cube | **$15.58** | stock/same-day shown | mini tabletop work | [shopPOP cases](https://www.shoppopdisplays.com/display-boxes-and-cases.html) |
| shopPOP 6-inch acrylic five-sided cube | **$25.19** | stock/same-day shown | small skull or assemblage | [shopPOP cases](https://www.shoppopdisplays.com/display-boxes-and-cases.html) |
| shopPOP 8-inch acrylic five-sided cube | **$34.74** | stock/same-day shown | medium tabletop work | [shopPOP cases](https://www.shoppopdisplays.com/display-boxes-and-cases.html) |
| shopPOP custom-size box with base | **from $37.32** | dimensions affect price | custom-fit enclosure | [shopPOP custom box](https://www.shoppopdisplays.com/P_Box-ABCL/acrylic-display-box-with-clear-base.html) |
| shopPOP wall-mount acrylic case/shelf | **from $58.32** | same-day shown for configured item | protected wall display | [shopPOP wall case](https://www.shoppopdisplays.com/P_Box-ABBKSBK/acrylic-display-case-with-black-wall-mount-shelf.html) |
| Displays2Go small glass dome | **$92.99** | in-stock page; bulk quote offered | premium tabletop enclosure | [Displays2Go small dome](https://www.displays2go.com/P-40901/Small-Glass-Bell-Jar-Baseless-Bottom) |
| Displays2Go pine dome base | **from $12.99** | sale/category price | pair with dome | [Displays2Go decorative cases](https://www.displays2go.com/C-30069/Decorative-Countertop-Display-Cases-Terrariums-Crystals-Keepsakes) |
| Displays2Go lift-off cases | **$65.99–$180.99** sampled | multiple sizes | geometric glass enclosure | [Displays2Go decorative cases](https://www.displays2go.com/C-30069/Decorative-Countertop-Display-Cases-Terrariums-Crystals-Keepsakes) |
| Michaels Honey Belmont shadow box | **$12.49–$17.49** sale range | pickup/shipping shown | accessible starter frame | [Michaels shadow boxes](https://www.michaels.com/shop/frames/shadow-boxes-display-cases/shadow-boxes?material=Wood&refinementColor=Brown) |
| Michaels 18-by-24 walnut shadow box | **$29.99** sale price | shipping shown | larger wall piece | [Michaels shadow boxes](https://www.michaels.com/shop/frames/shadow-boxes-display-cases/shadow-boxes?material=Wood&refinementColor=Brown) |
| Skull Hooker “The Hook” | **$11.99** | product page active | simple wall display | [The Hook](https://www.skullhooker.com/product/the-hook/) |
| Skull Hooker Little Hooker | **$42.99** | product page active | adjustable smaller-game wall mount | [Little Hooker](https://www.skullhooker.com/product/little-hooker/) |
| Skull Hooker Big Hooker | **$69.99** | product page active | large wall display | [Big Hooker](https://www.skullhooker.com/product/big-hooker/) |
| Skull Hooker Table Hooker | **$69.99** | catalog price | tabletop display | [Skull Hooker shop](https://www.skullhooker.com/shop/) |
| Skull Hooker Trophy Tree | **$189.99** | catalog price | multi-piece floor display | [Skull Hooker shop](https://www.skullhooker.com/shop/) |
| Etsy black metal tabletop stand | **$38** | marketplace listing | price benchmark for artist stand | [Etsy metal stands](https://www.etsy.com/market/metal_skull_stand) |
| Etsy 12-inch ram-skull stand | **$54–$60** | marketplace listing | price benchmark | [Etsy metal stands](https://www.etsy.com/market/metal_skull_stand) |
| Etsy metal stand with wood-slice base | **$88.96** | made to order | aesthetic benchmark | [Etsy metal stands](https://www.etsy.com/market/metal_skull_stand) |

### Tools, attachment, and studio supplies

| Product | Observed price | Use/constraint | Source |
|---|---:|---|---|
| Dremel Stylo+ craft rotary kit | **$59.97** | light precision work | [Home Depot Dremel category](https://www.homedepot.com/b/Tools-Power-Tools-Power-Multi-Tools-Rotary-Tools/Dremel/Rotary-Tool/N-5yc1vZc2fpZgrZ1z1dh09) |
| Dremel 3100 kit | **$64.97** | entry variable-speed rotary work | [Home Depot Dremel category](https://www.homedepot.com/b/Tools-Power-Tools-Power-Multi-Tools-Rotary-Tools/Dremel/Rotary-Tool/N-5yc1vZc2fpZgrZ1z1dh09) |
| Dremel 4000 kit | **$99.97** | more capable studio option | [Home Depot Dremel category](https://www.homedepot.com/b/Tools-Power-Tools-Power-Multi-Tools-Rotary-Tools/Dremel/Rotary-Tool/N-5yc1vZc2fpZgrZ1z1dh09) |
| Dremel 4300 kit | **$129–$134** observed across pages | premium studio option; price varies by bundle | [Home Depot Dremel category](https://www.homedepot.com/b/Tools-Power-Tools-Power-Multi-Tools-Rotary-Tools/Dremel/Rotary-Tool/N-5yc1vZc2fpZgrZ1z1dh09) |
| E6000 2-ounce adhesive | **$4.88** | common craft bond; follow label ventilation/PPE | [Lowe’s adhesive best sellers](https://www.lowes.com/best-sellers/glues-tapes/glues/multipurpose-adhesive/4294416311) |
| J-B Weld ClearWeld | **$6.98–$7.98** | rigid clear epoxy; test compatibility first | [Lowe’s epoxy best sellers](https://www.lowes.com/best-sellers/glues-tapes/glues/epoxy-adhesives/4294417387) |
| Gorilla clear epoxy | **$7.98** | five-minute repositioning window | [Lowe’s Gorilla epoxy](https://www.lowes.com/pd/Gorilla-Epoxy-Clear-Epoxy-Adhesive/5002785627) |
| Reindeer moss | **$7.99** | decorative substrate | [Michaels framed-floral project](https://www.michaels.com/project/art-de-fleurs-sechees-encadrees-B_92205) |
| Glue Dots mini dots | **$5.99** | lightweight botanical attachment | [Michaels framed-floral project](https://www.michaels.com/project/art-de-fleurs-sechees-encadrees-B_92205) |
| Craft scissors | **$4.99** | substrate trimming | [Michaels framed-floral project](https://www.michaels.com/project/art-de-fleurs-sechees-encadrees-B_92205) |
| Nitrile gloves, 120 pack | **$19.98** | basic hand protection; match glove to chemical SDS | [Home Depot safety accessories](https://www.homedepot.com/b/Safety-Equipment-Safety-Accessories/FITMENT/Pick-Up-Today/N-5yc1vZc2ftZ1z175a5Z1z18gk3) |
| N95 respirators, 15 pack | **$28.98** | particles only; not a substitute for chemical-vapor protection | [Home Depot HDX safety](https://www.homedepot.com/b/Safety-Equipment/Highly-Rated/HDX/N-5yc1vZc4owZ9tkZbwo5o/) |
| Splash goggles plus work gloves | **$10.45** | entry splash protection bundle | [Home Depot chemical-splash bundle](https://www.homedepot.com/p/sets/Chemical-Splash-1-Pack-and-Large-Nitrile-Coated-Work-Gloves-5-Pack-Combo/337487239) |

### Photography, labels, storage, and packaging

| Product | Observed price | Best use/constraint | Source |
|---|---:|---|---|
| Foldio3 25-inch studio kit | **$226** | medium product photography | [B&H Foldio3](https://www.bhphotovideo.com/c/product/1798514-REG/orangemonkie_foldio3_mini_studio_and.html/specs) |
| MyStudio PS5LED | **$189.95** | compact tabletop product photography | [B&H PS5LED](https://www.bhphotovideo.com/c/product/1357152-REG/mystudio_mystudio_ps5led_tabletop_lightbox.html/ask-question) |
| Foldio2 Plus with turntable | **$269** | 360-degree imagery | [B&H Foldio2 Plus](https://www.bhphotovideo.com/c/product/1798513-REG/orangemonkie_foldio2_plus_portable_lightbox.html/ask-question) |
| Avery 2.25-by-2.75-inch custom printable labels, 100 | **$27** | provenance/care/product labels | [Avery labels](https://www.avery.com/blank/labels/94282?height=2.75&ptte=Y&shape=rectangle&width=2.25) |
| Avery same label, 250 | **$50** | lower $0.20 unit cost | [Avery labels](https://www.avery.com/blank/labels/94282?height=2.75&ptte=Y&shape=rectangle&width=2.25) |
| Uline 10-by-8-by-8 box | **$0.72 each** at 25 | small shipping format; bundle purchase required | [Uline catalog specials](https://www.uline.com/Promotion/AdvSaleItems?PageNumber=2&SearchID=0&subgroup=401) |
| Uline 12-by-12-by-6 box | **$0.99 each** at 25 | shallow display shipment | [Uline cart/product result](https://www.uline.com/Product/ViewCart?action=detail&model=S-4122&qty=25) |
| Uline 20-by-12-by-3 box | **$1.86 each** at 25 | frames/flat work; 200-pound test | [Uline S-19079](https://www.uline.com/Product/Detail/S-19079/Corrugated-Boxes-200-Test/20-x-12-x-3-Corrugated-Boxes) |
| Uline 24-by-12-by-6 glass-pack kit | **$8.77 each** at 5 | partitioned fragile packing | [Uline glass-pack kit](https://www.uline.com/Product/Detail/S-13273/Moving-Boxes/24-x-12-x-6-275-lb-Glass-Pack-Kit) |
| Uline 12-inch by 175-foot bubble roll | **$20** | cushioning; sustainability tradeoff | [Uline moving supplies](https://www.uline.com/BL_7907/Moving-Kits) |
| Uline clear 4-by-12-by-4 shelf bins | **$2 each** in carton of 24 | labeled small-parts storage | [Uline clear shelf bins](https://www.uline.com/BL_8822/Clear-Plastic-Shelf-Bins) |
| University Products archival photo box | **$27.99** | records, labels, photographs; not a chemical-storage container | [Container Store media boxes](https://www.containerstore.com/shopping/media-box) |

## Supplier and Partner Opportunity Map

“Supplier-direct” below means a path worth asking about; it does **not** mean shipping directly to the end customer has been verified. Do not promise that service until the supplier confirms it in writing.

| Source | Relevant offer | Commercial path | Key requirement or risk | Recommendation |
|---|---|---|---|---|
| Lowe’s | tools, PPE, adhesives, hardware | creator affiliate | up to 20%, category tiers vary; US creator eligibility | **Apply first**; strong breadth and content fit. [Program](https://www.lowes.com/l/creator/joinlowescreator) |
| Michaels/MakerPlace | frames, moss, craft materials | 10% standard / 15% premium on linked Michaels supplies | documented in classes/how-to supply lists; plan rules apply | **High priority** for art-project supply lists. [Program update](https://www.michaels.com/makerplace/seller-support-center/store-management/whats-new) |
| Displays2Go | domes, cases, bases, signage | affiliate via Impact; reseller 10% entry discount | reseller margin thin; bulky/fragile returns | **Affiliate first**, reseller only after customer-paid shipping or special terms. [Affiliate](https://www.displays2go.com/affiliates), [reseller](https://www.displays2go.com/S-4628/resellers) |
| Avery | labels, cards, custom printing | affiliate up to 10%; reseller inquiry | commissions limited to qualifying net sales/product classes | **Apply**; provenance and care-card content is evergreen. [Program](https://www.avery.com/custom-printing/partners/partnership/) |
| B&H | light boxes, tripods, camera accessories | affiliate 2% initially, 3% if eligible later | low rate but higher ticket | **Secondary**; use for professional photo guides. [Terms](https://affiliates.bhphotovideo.com/Agreement.htm) |
| Home Depot | tools, PPE, hardware | affiliate through Impact | 1% most products; 8% select décor; one-day cookie | **Fallback/link coverage**, not primary earnings engine. [Program](https://www.homedepot.com/c/SF_MS_The_Home_Depot_Affiliate_Program) |
| Amazon Associates | long-tail supplies | typically 3% for home/tools/outdoors | low rate and program volatility; convenient checkout | **Gap filler**, never sole supplier. [Current rate table](https://affiliate-program.amazon.com/help/node/topic/GRXPHT8U84RAYDXZ) |
| Skull Hooker | wall/table/floor mounting systems | verified wholesale for qualified retailers | licensed business proof, agreement, price sheet, MAP; direct fulfillment unverified | **Apply after business setup**; useful benchmark and product test. [Wholesale](https://www.skullhooker.com/about-skullhooker/become-a-wholesaler/) |
| shopPOPdisplays | stock/custom acrylic cases | retail and custom quote | affiliate path not found in this pass; custom shipping must be quoted | **Use as product source/benchmark**, ask about trade terms. [Catalog](https://www.shoppopdisplays.com/display-boxes-and-cases.html) |
| Choice Acrylic Displays | made-to-order US acrylic displays | wholesale-branded source, no order minimum stated | lead time varies; direct fulfillment unverified | **Strong prototype inquiry**. [Supplier](https://wholesaleacrylicdisplays.com/) |
| Plexiboxes4u | stock and custom acrylic boxes | wholesale prices, no minimum stated | obtain freight, return, and direct-ship terms | **Strong prototype inquiry**. [Supplier](https://www.plexiboxes4u.com/) |
| American Acrylic Display | stock/custom displays | bulk and custom wholesale inquiry | price/lead time by quote | **Prototype/US production candidate**. [Supplier](https://acrylicdisplayinc.com/) |
| Displays and Holders | custom acrylic | custom MOQ 50; wholesale application | working capital and forecast required | **Later owned-product candidate**. [Custom program](https://www.displaysandholders.com/custom-displays) |
| Wetop Acrylic | custom cases, UV options | custom MOQ 100; sample 3–5 days | overseas freight, quality, tariff and lead-time risk | **Later cost benchmark**, not first launch. [Supplier](https://wetopacrylic.com/products/acrylic-cases/) |
| Sunday Knight | custom acrylic | wholesale; MOQ typically starts at 100 | overseas freight and quality-control burden | **Later cost benchmark**. [Supplier](https://www.sunday-knight.com/product/2677-en.html) |
| DisplayIt | acrylic boxes with hardwood bases | wholesale; $200 minimum; business-only | modest minimum but pricing/login needed | **Good early wholesale inquiry**. [Supplier](https://displayit-info.com/acrylic/acrylic2_box.html) |
| Faire | glass domes, cases, decorative products | wholesale marketplace; retailer referral affiliate | wholesale prices behind account; many brands prohibit marketplace resale | **Use for discovery after retailer setup**. [Glass dome category](https://www.faire.com/discover/glass-dome-cloche-wood-base), [affiliate](https://www.faire.com/affiliates) |
| Ragon House | glass cloche with wood base | registered wholesale buyers | case packs; 20% restocking on qualifying returns; damage claims quickly | **Quote after business setup**. [Product/terms](https://ragonhouse.com/everyday/9-75-glass-cloche-w-wood-base/) |
| Uline | packaging and studio storage | quantity price breaks; no distributor program | shipping can materially change landed cost | **Operational source**, not a resale engine. [Pricing policy](https://www.uline.com/CustomerService/ULINE_FAQ_Ans?FAQ_id=21&SearchKeyword=affiliate&keywords=affiliate) |
| Container Store | archival and clear storage | retail/trade; affiliate existence referenced in trade terms | current affiliate details not verified in this pass | **Use for storage content only after program verification**. [Acid-free category](https://www.containerstore.com/s/Acid-Free/f) |
| Oddities For Sale | consignment with fulfillment and returns | consignor states desired payout; platform sets price | approval selective; requires sending inventory | **Potential artist referral/consignment partner**, not no-inventory supply source. [Consignment](https://odditiesforsale.com/consignment/) |
| Strange Remains Curio Shop | wholesale/consignment art and home goods | application/price sheet by contact | category and marketplace permissions vary | **Possible creator-network partner**. [Wholesale](https://www.strangeremainscurioshop.com/wholesale) |
| Paxton Gate | broad curated natural-history retail and classes | possible vendor inquiry; direct terms not public | not a commodity supplier | **Benchmark and potential editorial/class partner**. [FAQ](https://paxtongate.com/pages/faqs) |
| SkullStore | broad natural-history catalog and museum tie-in | retail; international shipping | cross-border restrictions and product legality vary | **Benchmark only unless written partner terms emerge**. [Store](https://www.skullstore.ca/) |
| Evolution Store | entomology, natural-history, jewelry | retail | partner terms not found | **Adjacent benchmark**. [Store](https://theevolutionstore.com/) |
| Etsy | finished art, made-to-order stands, project supplies | marketplace and supplier discovery | seller rights, production-partner rules, and resale policies must be checked | **Demand laboratory and creator discovery**, not an assumed sourcing free-for-all. |

## Comparable and Adjacent Business Models

### Paxton Gate: curation plus education

Paxton Gate groups skulls/bones/skeletons, taxidermy, bugs, jewelry, fossils, and oddities; it also markets classes and gift cards. Current product prices range from tiny fossil items to four- and five-figure statement pieces. The lesson is not to imitate inventory breadth immediately. It is to emulate the **editorial merchandising structure**: category worlds, new arrivals, best sellers, workshops, and giftable entry points. [Paxton Gate](https://paxtongate.com/)

### SkullStore: catalog breadth plus museum authority

SkullStore describes itself as the gift shop of the Prehistoria Museum and combines a very broad catalog with education and social distribution. Its authority is strengthened by a real institution, but cross-border inventory makes it a poor direct operational model for a bootstrapped US launch. The useful lesson is the **trust flywheel** between education, exhibits, catalog depth, and social content. [SkullStore](https://www.skullstore.ca/)

### Evolution Store: tightly organized natural-history categories

Evolution uses recognizable natural-history departments and carries both higher-ticket collections and accessible jewelry/keychains. The lesson is to build **price-entry ladders** and easy-to-understand collections rather than a visually impressive but unsearchable assortment. [Evolution Store](https://theevolutionstore.com/)

### Etsy: demand laboratory, not a single competitor

Etsy reveals project formats, price anchors, customer vocabulary, materials, review concerns, and the prevalence of made-to-order stands. It should be monitored as a **living product-research surface**. Each sampled listing must be verified before publication; never infer sales from the marketplace result count alone.

### Oddities & Curiosities Expo: curated network and content engine

The Expo states that its show is heavily curated and does not accept direct-sale/franchise businesses. It collaborates with in-house vendors and runs merchandise, classroom, and museum components. The opportunity for BonesAndHoes is relationship building, creator interviews, product observation, and permissioned spotlights—not treating the event as a generic booth market. [Expo FAQ](https://odditiesandcuriositiesexpo.com/pages/faq)

## Market Friction and Gaps

1. **No unified project bill of materials.** Finished pieces show the result, while mounts, rod sizes, adhesives, substrate depth, case dimensions, labels, and packing choices are scattered across vendors.
2. **Artist needs are poorly served by hunting-oriented mount language and aesthetics.** Current adjustable hardware is functional and proven, but much of it is designed around trophy rooms and large game. Small, refined, neutral hardware for art displays is a distinct opportunity.
3. **Compatibility is opaque.** A buyer needs internal case dimensions, base thickness, rod diameter, load rating, mounting-interface shape, and whether attachment is reversible. Most category pages do not translate these into project compatibility.
4. **Glass versus acrylic is an unresolved tradeoff.** Glass communicates weight and premium craft but is fragile and expensive to ship. Acrylic is lighter, customizable, and available with UV-filtering grades, yet may feel less premium. This should be tested by project type and price tier.
5. **Provenance and care presentation is inconsistent.** Labels and documentation can become a signature trust layer: origin context, lawful-acquisition note, species, artist, process, care, and QR link.
6. **Fragile packing is an overlooked content and product category.** Domes and articulated work create high damage risk. A tested packing guide and size-specific packing list can attract both makers and collectors.
7. **Most broad retailers monetize one item, not the whole project.** BonesAndHoes can own the cross-retailer layer: complete supply list, choices by budget, compatibility notes, and substitutions.
8. **Creator discovery and commerce are disconnected.** Permissioned reposts can lead to the artist, then to the supporting materials used in that project. This preserves credit while creating commerce around the work.

## Provisional Unit Economics

These examples use published program rates and observed prices. They are **illustrative**, exclude returns and taxes, and do not predict conversion. Final rates must be verified after account approval because product-category tiers and exclusions vary.

| Example link | Retail price | Published rate | Illustrative commission |
|---|---:|---:|---:|
| Displays2Go small glass dome | $92.99 | up to 8% reported by program manager profile | **up to $7.44** |
| B&H Foldio3 kit | $226 | 2% initial / 3% later if eligible | **$4.52 / $6.78** |
| Avery 100-label order | $27 | up to 10% | **up to $2.70** |
| Amazon-category $50 tool/supply basket | $50 | 3% relevant categories | **$1.50** |
| Home Depot $134 Dremel | $134 | 1% ordinary product rate | **$1.34** |
| Michaels $13.98 moss + dots | $13.98 | 10% standard / 15% premium for qualifying linked supply sales | **$1.40 / $2.10** |

### Why affiliate-first is economically rational

- Affiliate links carry no inventory, packing, breakage, return, or chargeback handling by BonesAndHoes.
- A single project can contain 10–25 linkable products. Low commission per item can compound across the full bill of materials and across an evergreen content library.
- Supplier breadth lets the team optimize price and availability without owning a warehouse.
- Conversion and click data reveal which items justify wholesale negotiation or product development.

### Why simple retail arbitrage is weak

Displays2Go’s entry reseller discount is **10%**. If a product is resold at the public list price through a channel whose transaction, payment, or promotional costs approach 10%, there is no room left for shipping, damage, support, or profit. Therefore:

- Do not list generic catalog items as owned inventory merely because a reseller discount exists.
- Pursue reseller commerce only with a materially better wholesale cost, supplier-direct fulfillment, customer-paid shipping, a bundled value-add, or an exclusive/custom product.
- Never buy from another public retailer after an order and present that as a stable fulfillment system. Written supplier authorization and service terms are required.

## Ranked Bootstrapped Opportunities

### Tier 1 — launch with no inventory

1. **Project supply lists:** every creator feature, tutorial, or Atlas project receives a verified, multi-retailer list with budget and premium choices.
2. **Preparation and safety storefront:** PPE, tubs, tools, brushes, rotary equipment, and storage—carefully tied to product instructions and safety data.
3. **Display-builder storefront:** frames, domes, acrylic cases, stands, bases, rods, wire, adhesives, moss, botanicals, labels, and lighting.
4. **Photography and selling guide:** a light-box and listing-photography collection for artists preparing Etsy/TikTok listings.
5. **Packing guide and supply collection:** box sizing, internal immobilization, glass separation, labels, and damage documentation.
6. **Provenance-card templates and label guide:** digital templates plus linked label stock and printers.

### Tier 2 — negotiate after click and conversion evidence

1. Skull Hooker wholesale account for validated mount demand.
2. Displays2Go/DisplayIt trade quotes for recurring enclosure sizes.
3. Made-to-order custom acrylic partnerships with Choice Acrylic, Plexiboxes4u, or American Acrylic.
4. Faire wholesale sourcing for domes and art-adjacent décor after marketplace permissions and landed cost are checked.
5. Artist consignment/referral relationships with clear credit, permissions, and payout terms.

### Tier 3 — later owned products

1. **Discreet modular tabletop stand:** neutral black/brass finishes, multiple rod heights, cushioned contact points, replaceable adapters, published load/size guide.
2. **Base-and-enclosure system:** reversible wood/black base, routed rod positions, label slot, acrylic or glass options, replacement covers.
3. **Small-specimen rod-and-clamp kit:** micro hardware that looks intentional rather than improvised from laboratory or floral parts.
4. **Shadow-box mounting insert:** removable, pre-gridded backing that supports pins, wire, and reversible attachment without damaging the frame.
5. **Provenance and care system:** premium cards, QR labels, archival sleeves, and a digital record template.
6. **Fragile-art packing system:** size-matched box, partition, cushioning map, and photo-based pack-out checklist.

## Owned-Product Validation Gates

Do not manufacture because a product looks attractive. Advance only when all gates are met:

1. At least 90 days of click/conversion data identifies a recurring product and size need.
2. At least 20 direct customer or creator interviews confirm the friction and acceptable price.
3. Three supplier quotes include tooling, samples, MOQ, lead time, freight, damage allowance, and replacement policy.
4. A prototype survives load, tip, vibration, pack, and drop testing appropriate to its use.
5. Landed cost supports the target channel after fees, shipping subsidy, returns, and customer support.
6. The design does not depend on possessing or selling regulated biological material; compatibility testing can use lawful owner-provided measurements or inert dimensional forms.
7. Marketplace and advertising language has been reviewed for policy and legal accuracy.

## Recommended Merchandising Architecture

### Shop by project outcome

- Glass-dome displays
- Shadow-box and framed work
- Tabletop stands
- Wall displays
- Jewelry and wearable projects
- Botanical and mineral compositions
- Carved, painted, and finished skull art
- Photography and listing setup
- Studio storage and labeling
- Fragile packing and shipping

### Shop by workflow stage

- Document and handle
- Prepare safely
- Drill, shape, and finish
- Build and attach
- Display and protect
- Photograph and publish
- Store and ship

### Every product card should show

- exact job it performs;
- compatible project formats and measurements;
- why this item was chosen over alternatives;
- current price and last verification date;
- merchant, fulfillment, shipping, and return notes;
- affiliate, wholesale, or direct-source status;
- safety and compliance flags;
- at least one lower-cost and one premium alternative when useful;
- a confidence rating.

## Content-to-Commerce Operating Pattern

1. Feature the discovery or lawful source context.
2. Explain preparation and safety without sensationalism.
3. Show the artist’s concept and credit the artist prominently.
4. Demonstrate each real tool, substrate, stand, enclosure, and finish during use.
5. Reveal the final piece and explain the design choices.
6. Mention naturally that the tools and materials are listed below.
7. Publish the full supply list with alternatives and compatibility notes.
8. Reuse the same structured data in the Atlas, shop collections, email, Pinterest, TikTok Shop where eligible, Etsy resources, and the owned site.
9. Record clicks, saves, questions, out-of-stock events, returns, and requests for unavailable sizes.
10. Feed recurring unmet needs into wholesale negotiation and owned-product validation.

## Ninety-Day Product Research Plan

### Days 1–14: foundation

- Apply to Lowe’s Creator, Michaels/MakerPlace if suitable, Displays2Go, Avery, B&H, Home Depot, and Amazon Associates.
- Build a product ledger with SKU, URL, dimensions, price, availability, rate, shipping, returns, and last-checked date.
- Create 8 project taxonomies and 5 standard supply-list templates.
- Contact Skull Hooker, Choice Acrylic, Plexiboxes4u, DisplayIt, and American Acrylic for program and direct-fulfillment terms.

### Days 15–45: publish and measure

- Publish 12 project-to-supply posts across at least four formats: dome, frame, stand, jewelry.
- Feature at least 12 creators with permission/credit protocols and link to their work.
- Test budget versus premium enclosure choices and glass versus acrylic preference.
- Track outbound clicks by project, product family, price tier, and merchant.

### Days 46–90: narrow and negotiate

- Rank the top 25 products by qualified clicks, saves, questions, and conversion where available.
- Replace weak merchants and out-of-stock products.
- Negotiate trade pricing only for repeated demand.
- Interview 20 creators/customers about mounting, dimensions, enclosure material, and price.
- Select at most two owned-product concepts for prototyping.

## Further Questions Requiring Owner or Account Data

1. Which existing Anna/Haley posts generate saves, DMs, and product questions—not just views?
2. Which states and audience segments dominate the current following?
3. Are Anna and Haley eligible today for each platform’s creator and shop programs?
4. Which preparation materials are already used and trusted in their real process?
5. Which creator relationships already permit reposting or collaboration?
6. What price range produces the strongest audience response?
7. Will the brand accept supplier-direct fulfillment only, or also artist consignment after revenue begins?
8. Is the owned-product ambition limited to display hardware and documentation, or does it include custom enclosures and packing systems?

## Caveats and Research Shortfalls

- This pass did not reach the directive’s full target of 150 individually verified product records or 50 deeply profiled creators. It provides **50+ price/product observations, 25+ project/format observations, and 25 supplier/partner records** sufficient to establish the strategy and next research queue. A database pass should expand and recheck these before publication.
- Etsy result counts and review counts are directional. They are not a substitute for seller analytics, conversion, or confirmed units sold.
- Wholesale prices are often hidden behind approved business accounts. Skull Hooker, Faire, Ragon House, and several acrylic manufacturers require applications or quotes; margin cannot be stated until those are received.
- Direct-to-customer fulfillment was not confirmed for most wholesale sources. It must be obtained in writing before the brand advertises supplier-direct delivery.
- Prices and affiliate terms change. Every public Atlas price should show a verification date, and operational product feeds should be checked at least monthly.
- Chemical handling, biological-material law, wildlife law, shipping restrictions, and platform policies require separate authoritative review. Product listings must not imply that a generally available supply makes a particular acquisition, preparation method, transfer, or sale lawful.
- Finished-work images remain the creators’ property. Reposting requires permission or a valid platform-native sharing method and clear credit.

## Validation Report

### Overall Assessment: Share with caveats

**Methodology.** Current retailer, manufacturer, marketplace, and program pages were searched and compared. Public prices and program terms were captured as of August 18, 2026. Marketplace examples were used to identify formats and price anchors; they were not treated as verified sell-through data.

**High-impact checks.** Published affiliate rates were taken from first-party program pages where possible. Displays2Go’s “up to 8%” rate comes from an affiliate-program management profile and should be confirmed inside Impact after approval. Illustrative commissions were recomputed as retail price multiplied by the stated rate.

**Material limitations.** Wholesale costs, landed freight, platform fees by actual channel, return rates, conversion, and audience analytics are not yet available. Therefore owned-product margin and sales forecasts are intentionally not asserted.

**Decision confidence.** High confidence in the affiliate-first, project-to-supply direction; medium confidence in the display-hardware owned-product hypothesis; low confidence in any specific custom product’s economics until customer interviews and supplier quotes are completed.

## Source Index

All sources below were accessed August 18, 2026.

- [Etsy bone shadow boxes](https://www.etsy.com/market/bone_shadow_box)
- [Etsy bone-display shadow boxes](https://www.etsy.com/market/bone_display_shadow_box)
- [Etsy skull-display domes](https://www.etsy.com/market/skull_display_dome)
- [Etsy metal skull stands](https://www.etsy.com/market/metal_skull_stand)
- [Etsy skull pedestals](https://www.etsy.com/market/skull_mount_pedestal)
- [Etsy bone jewelry](https://www.etsy.com/market/bone_jewelry)
- [Paxton Gate](https://paxtongate.com/)
- [SkullStore](https://www.skullstore.ca/)
- [Evolution Store entomology](https://theevolutionstore.com/categories/entomology/)
- [Oddities & Curiosities Expo FAQ](https://odditiesandcuriositiesexpo.com/pages/faq)
- [Displays2Go decorative cases](https://www.displays2go.com/C-30069/Decorative-Countertop-Display-Cases-Terrariums-Crystals-Keepsakes)
- [Displays2Go affiliate program](https://www.displays2go.com/affiliates)
- [Displays2Go reseller program](https://www.displays2go.com/S-4628/resellers)
- [shopPOP acrylic cases](https://www.shoppopdisplays.com/display-boxes-and-cases.html)
- [Skull Hooker shop](https://www.skullhooker.com/shop/)
- [Skull Hooker wholesale](https://www.skullhooker.com/about-skullhooker/become-a-wholesaler/)
- [Michaels shadow boxes](https://www.michaels.com/shop/frames/shadow-boxes-display-cases/shadow-boxes?material=Wood&refinementColor=Brown)
- [Michaels MakerPlace program updates](https://www.michaels.com/makerplace/seller-support-center/store-management/whats-new)
- [Lowe’s Creator Program](https://www.lowes.com/l/creator/joinlowescreator)
- [Home Depot Affiliate Program](https://www.homedepot.com/c/SF_MS_The_Home_Depot_Affiliate_Program)
- [B&H Affiliate Agreement](https://affiliates.bhphotovideo.com/Agreement.htm)
- [Avery Affiliate Partnership](https://www.avery.com/custom-printing/partners/partnership/)
- [Amazon Associates rate table](https://affiliate-program.amazon.com/help/node/topic/GRXPHT8U84RAYDXZ)
- [Uline moving and packing supplies](https://www.uline.com/BL_7907/Moving-Kits)
- [Uline distributor-pricing policy](https://www.uline.com/CustomerService/ULINE_FAQ_Ans?FAQ_id=21&SearchKeyword=affiliate&keywords=affiliate)
- [Choice Acrylic Displays](https://wholesaleacrylicdisplays.com/)
- [Plexiboxes4u](https://www.plexiboxes4u.com/)
- [American Acrylic Display](https://acrylicdisplayinc.com/)
- [Displays and Holders custom program](https://www.displaysandholders.com/custom-displays)
- [Wetop custom acrylic cases](https://wetopacrylic.com/products/acrylic-cases/)
- [DisplayIt wholesale acrylic cases](https://displayit-info.com/acrylic/acrylic2_box.html)
- [Faire glass-dome wholesale category](https://www.faire.com/discover/glass-dome-cloche-wood-base)
- [Faire affiliate program](https://www.faire.com/affiliates)
- [Ragon House wholesale glass cloche](https://ragonhouse.com/everyday/9-75-glass-cloche-w-wood-base/)
- [Oddities For Sale consignment](https://odditiesforsale.com/consignment/)
- [Strange Remains wholesale](https://www.strangeremainscurioshop.com/wholesale)

