# BonesAndHoes Expo Vendor Census and Monetization Report

**Research cut:** 2026-08-18  
**Scope:** Oddities & Curiosities Expo circuit, with special attention to repeat-tour operators and the 2026 Pacific Northwest stops  
**Companion data:** `BonesAndHoes_Expo_Vendor_Intelligence_Directory_2026-08-18.csv`

## Executive finding

The inherited Expo workbook was useful but incomplete. It contained 26 records, including organizers, instructors, historical observations and a “no sponsor found” row—not 26 current outside vendors. This expansion identifies **48 directly verifiable 2026 vendors**, plus two official instructors, one partner-distribution record, the organizer, three historical observations and three discovery/historical leads. The companion CSV contains **58 total records**.

This is a much stronger working directory, but it is **not a complete official roster**. The organizer does not expose a stable public city-by-city vendor list, and many vendor spotlights are confined to partially indexed social posts. The correct publication language is therefore:

> A verified public-source census of discoverable 2026 vendors and operators—not the official or complete Expo roster.

The strongest finding is not any single product. It is the range of operating models already functioning inside the circuit:

- portable art merchandise sold online, wholesale and at events;
- one-of-one art supported by timed shop updates;
- multi-maker retail collectives that keep a store open while a travel team vends;
- partner-booth inventory placement that avoids staffing every stop;
- education bundled with materials and an admission ticket;
- retail-stockist networks that continue selling between events;
- service revenue from custom work, preparation, memorial work and workshops;
- highly selective event attendance when scarcity and quality matter more than circuit volume.

For BonesAndHoes, the most defensible opportunity is to become the **project-to-supply and creator-to-audience connector** around this ecosystem: interview artists, decode their project materials and display choices, publish permissioned supply lists, curate difficult-to-find substrates and hardware, and turn each Expo relationship into future creator features and legitimate commerce paths.

## What was verified

### Current census counts

| Classification | Count | Meaning |
|---|---:|---|
| Verified 2026 vendors | 48 | A vendor-owned calendar, shop announcement, event page or credible 2026 report explicitly connects the vendor to at least one O&C Expo stop. |
| Official tour instructors | 2 | The Sleeping Sirens and Violet Eyes Entomology are named by the organizer’s class program. |
| Verified partner-vendor record | 1 | Bright Side Studios is documented as carrying another maker’s inventory across part of the circuit. |
| Organizer | 1 | The Expo’s own merchandise and operating model. |
| Historical observations | 3 | Useful demand examples, but not current-roster evidence. |
| Discovery/historical leads | 3 | Public evidence is incomplete, date-limited or awaiting direct confirmation. |
| **Total directory records** | **58** | All records retain an evidence label and direct public source. |

### High-recurrence operators found

These are the most useful people to interview because they can compare cities, booth formats, product portability and follow-up behavior.

| Operator | Public recurrence signal | Why it matters |
|---|---:|---|
| Space Wolf | Reported all-tour operator | Broadest city-comparison opportunity; confirm itinerary directly. |
| Monsterologist | 16+ listed stops | Mature online, event and wholesale system; 400+ retailers reported. |
| Clockwork Art | 16 listed or partner-carried stops | Clear evidence that a maker’s work can travel without the maker attending every stop. |
| Harrison Farm | 15 listed stops | Provenance-led raw-material supplier serving artists. |
| Cult of Asmodeus | 14 listed stops | Crosses oddities, anime, goth and tattoo audiences. |
| LABCREATURE | 12 listed stops | Moving from table format toward a larger booth at most stops. |
| Burning Paper Hearts | 12 listed stops | Portable artist inventory across Southwest, Texas and Midwest routes. |
| Strong and Hardy | 10+ listed stops | Strong Portland relevance and repeat-tour perspective. |
| Skullgarden | 9 listed stops | Useful comparison between art festivals and oddities audiences. |
| Odds and Ends by Chloe | 9 listed stops | Dimensional wall art paired with online restocks. |

## Coverage and evidence method

The census began with the project’s [2026 Expo Intelligence and Vendor Landscape](https://docs.google.com/document/d/1xrRokaOO-Th_3mwjr52y8T7PvSP3FV-buMTNUw3-Z4M/edit) and the Expo Vendors tab in the [market-intelligence workbook](https://docs.google.com/spreadsheets/d/1Hwg3XA6WJ8B-3CKAD_vZvATUErpzn03t9UHVjXBo6Ng/edit). It then triangulated:

1. the [official schedule](https://odditiesandcuriositiesexpo.com/pages/schedule-tickets), [FAQ](https://odditiesandcuriositiesexpo.com/pages/faq), [classes](https://odditiesandcuriositiesexpo.com/pages/classes), and [vendor application page](https://odditiesandcuriositiesexpo.com/pages/application);
2. vendor-owned event calendars and shop announcements;
3. vendor-owned catalogs, retail-stockist pages and wholesale pages;
4. credible event reporting where a vendor’s own source was unavailable;
5. public marketplace metrics only when the platform exposed them.

No private sales, margins, conversion rates or attendance were invented. “Sold out” is treated as an inventory observation, not proof of broad category demand. Follower counts were not systematically captured because live platform access is inconsistent and a follower count alone does not prove purchasing intent.

### Important schedule discrepancy

The current official schedule-page search result describes **40 cities across the United States, Canada and Australia**. The earlier project document describes **40 North American cities plus four Australian dates**. Those statements are not identical. The final Atlas should use the live organizer schedule as the operational source and ask the organizer to confirm the total before publishing a headline number.

## Monetization-pattern matrix

| Pattern | Verified examples | Public evidence | What BonesAndHoes can ethically adapt | Validation question |
|---|---|---|---|---|
| Portable impulse merchandise | Monsterologist; LABCREATURE; Hyper Finch | Monsterologist lists patches around $8-$8.50; LABCREATURE prints at $16; Expo souvenirs start at $5. | Create project-linked low-cost media or tools only when they add real utility; use creator features to build themed shopping lists. | Which small items create the most post-event follows or later orders? |
| Wholesale plus direct retail | Monsterologist; The Wondering Alchemist | Monsterologist publishes 50% wholesale pricing, $75 minimum and three-per-item MOQ; Wondering Alchemist accepts wholesale inquiries and has three named stockists. | Build a verified supplier and stockist map before holding inventory; negotiate direct relationships around proven demand. | Which categories survive a true two-times retail markup after freight and returns? |
| Partner-booth distribution | Showtime Taxidermy + Bright Side Studios; Hyper Finch + Rhiannon Yates; Clockwork Art’s helper-carried stops | Vendor calendars explicitly disclose inventory or work appearing through a partner. | Test a small, tracked assortment through an established booth before applying for a full tour. | How are loss, shrinkage, card fees, unsold stock and payout timing handled? |
| Collective storefront plus touring team | Dark Matter Oddities & Artisan Collective + Black Moth Candle Co. | Dark Matter published booth numbers and shipping pauses while its French Quarter store stayed open; Black Moth is stocked there and shares event space. | Build a creator network that can become a regional pickup/retail map and later a shared merchandising channel. | What accounting and inventory system makes multi-maker settlement trustworthy? |
| Materials-included beginner workshops | The Sleeping Sirens; Violet Eyes Entomology; Mz. Jones’ Curio | Official classes bundle admission and supplies; published North American prices are $150-$175 for short formats and $325 for the long format. | Begin with documented digital learning and product lists; later test small local workshops only after safety, permits and insurance are resolved. | Which repeated beginner fear does the class remove, and what part of the kit is hardest to source? |
| One-of-one drops and rotating stock | Showtime Taxidermy; Poltergeist Heist; Chronographia; Wondering Alchemist | Public shop messages describe drops, restocks, rotating one-of-one pieces and event-related availability. | Use a “project reveal → full material list → limited relevant find” cadence without manufacturing false urgency. | What share of buyers joins email before a drop, and which content triggers that sign-up? |
| Service plus physical product | Poltergeist Heist; Wondering Alchemist; Southern Curiosities; Sterling Fox Taxidermy | Public offerings include memorial work, cleaning, custom orders and planned educational material. | Monetize expertise first through useful guides, verified shopping paths and selected services; add owned goods only after demand. | Which service requests recur enough to standardize? |
| Retail-stockist network | Wondering Alchemist; Woodland Shrine; Mountain Medusa; Monsterologist | Named stockists range from several local stores to 400+ retailers. | Create a regional creator/shop directory, then turn it into mutually beneficial features, referrals and product discovery. | Which stockists attract the right buyer rather than simply more foot traffic? |
| Selective premium-event strategy | Lady Stardust Handmade; Mallory Hart Art; Dug Stanat | Lady Stardust publicly reduced event volume to focus on brand fit; premium artists carry larger or fragile work. | Do not assume maximum event count is the goal. Match product portability, gross margin and content value to each stop. | What is the true contribution after travel, breakage, lodging and time? |
| Event-to-owned-channel continuity | Bijoux StLou; Chronographia; Dark Matter; Sterling Fox | Some vendors pause online fulfillment while traveling; others keep a store operating or migrate listings to an owned site after marketplace-policy changes. | Establish email and owned-site capture before scaling event travel; publish fulfillment expectations plainly. | Can the business keep serving online buyers while the creators are away? |
| Cross-event audience portfolio | Cult of Asmodeus; Nomadical; Hex and Wax; Skullgarden | Vendor calendars mix O&C with tattoo, horror, goth, comic, art and regional markets. | Treat the Expo as one node in a wider network; compare audience quality and content access, not just attendance. | Which event produces repeat customers rather than one-time novelty purchases? |
| Consumable/gift repeat purchase | Black Moth Candle Co.; Hex and Wax; Spirited Sweets | Candles, incense and limited chocolates create replenishment or seasonal gifting. | Explore safe, lawful surrounding-project consumables and gifts through partners before owned production. | Is repeat purchase driven by the item, the scent/flavor, or the event memory? |
| High-ticket functional art | Mountain Medusa; Little Stuff and Finds (historical current shop); The Rustic Palace | Public examples include lamps, framed displays and handcrafted bags priced into the hundreds. | Focus product research on substrate, hardware, lighting, cases and difficult-to-find structural components used to make functional work. | Which hidden component causes the most time, failure or shipping risk? |

## Concrete ideas BonesAndHoes can adapt

### 1. Creator feature becomes a verified project map

With permission, each feature should capture:

- what the creator made and why;
- lawful origin/provenance language the creator can substantiate;
- preparation method at a safe, non-sensational level;
- substrate, enclosure, mount, wire, rod, adhesive, finish, light and label choices;
- low/mid/premium alternatives for the surrounding supplies;
- the creator’s shop, upcoming events and preferred credit language;
- a short list of products actually used, linked beneath the content.

This turns a creator interview into discovery, education, networking and commerce without forcing the creator’s work into a standardized project.

### 2. “How the booth works” Expo interview series

The most commercially valuable interview is not “What do you sell?” It is a structured operator conversation:

1. What draws attention but rarely converts?
2. What sells first on Saturday, and what sells on Sunday?
3. What is the normal transaction range—not the record sale?
4. What travels safely and what breaks, leaks, melts or becomes unprofitable?
5. Which display stand, enclosure, light or fastener changed your booth?
6. What do buyers repeatedly ask about origin and legality?
7. What goes into a partner’s booth when you cannot attend?
8. How do you reconcile partner sales and unsold inventory?
9. What percentage of the event’s value arrives later through email or the website?
10. What would you never carry again?

### 3. Difficult-to-find infrastructure index

Vendors show that attention concentrates on finished work, while the supporting infrastructure remains fragmented. Build a live research list for:

- unusual wood and stone substrates;
- bell jars, domes, shadow boxes and custom acrylic/glass enclosures;
- discreet rods, wire, pins, fasteners and hidden mounting hardware;
- small drills, clamps, cutting and finishing tools;
- museum-style labels, archival paper and provenance sleeves;
- portable booth lighting, risers and secure display fixtures;
- packing materials for fragile dimensional work;
- secondhand frames, bases, cabinets and unusual found objects.

The content layer can show creators finding these materials at thrift stores, architectural salvage stores, reuse centers, estate sales, yard sales, Facebook Marketplace and local free groups—then compare the found-object route with a verified readily purchasable alternative.

## Ranked interview and networking targets

### Tier 1 — contact first

| Rank | Target | Primary learning objective | Proposed opening offer |
|---:|---|---|---|
| 1 | The Wondering Alchemist | Portland retail placements, wholesale, custom orders, local markets and three-stop O&C route | Permissioned maker profile with full credit, store links and a material/process spotlight. |
| 2 | Woodland Shrine | Portland/Seattle circuit, stockists and co-hosted immersive event model | Regional creator feature and shared PNW resource map. |
| 3 | Clockwork Art | Sixteen-stop route, partner-carried appearances and gallery crossover | Tour-operations interview focused on work traveling through trusted helpers. |
| 4 | Strong and Hardy | Ten-plus stops including Portland and Sacramento | Portland pre-event operator interview and booth/material feature. |
| 5 | The Sleeping Sirens | Class design, kit composition, safety, sourcing and repeated beginner objections | Education-focused interview routed through official Expo permission. |
| 6 | Harrison Farm | Traceability, bulk artist supply and lawful documentation | Farm-to-maker provenance profile and supplier-education conversation. |
| 7 | Monsterologist | Mature wholesale, 400+ retailers, portable inventory and national events | Case study on building a low-fragility artist merchandise ladder. |
| 8 | Showtime Taxidermy + Bright Side Studios | Partner-booth distribution and drop-based inventory | Joint interview on settlement, tracking, staffing and customer handoff. |
| 9 | LABCREATURE | Scaling from table to booth across twelve cities | Visual before/after booth-growth feature and portable-product economics. |
| 10 | Dark Matter Oddities + Black Moth Candle Co. | Collective store, shared booths and continued fulfillment during travel | Joint operational interview and New Orleans collective spotlight. |

### Tier 2 — high thematic or operational value

11. Poltergeist Heist Oddities — professional cleaning, memorial work and one-of-one art.  
12. Mountain Medusa — functional lamps/jewelry and five named stockists.  
13. The Oddities Museum — education, workshops and community authority.  
14. Mz. Jones’ Curio — events feeding year-round in-store programming.  
15. Sterling Fox Taxidermy — supplies, owned-channel migration and planned beginner book.  
16. Blackhollow Fever — antique sourcing and booth-size flexibility from 6 to 30 feet.  
17. Lady Stardust Handmade — deliberate reduction in event volume to protect quality and brand fit.  
18. The Rustic Palace — frames, enclosures and presentation quality.  
19. Strange Remains Curio Shop — booth styling and Mountain/West Coast routing.  
20. Oddity Bug Club or Violet Eyes Entomology — international entomology presentation and class logistics.

## Portland and Pacific Northwest field plan

The Portland stop is scheduled for **November 7-8, 2026** at the [Oregon Convention Center](https://www.oregoncc.org/attend/events/2026/11/oddities-and-curiosities-expo-2026). Publicly discoverable Portland-confirmed vendors in this census include The Wondering Alchemist, Woodland Shrine, Clockwork Art and Strong and Hardy. Seattle-confirmed or regional records add Rosy Ghost Curios, LABCREATURE, Blackhollow Fever, Harrison Farm and other touring operators. This remains an incomplete list.

### Before the Expo

- Ask the organizer for press/content permission, current filming rules and any publishable vendor directory.
- Ask the four Portland-confirmed vendors for 15-minute scheduled interviews before the event becomes noisy.
- Prepare a one-page creator permission form covering name, images, quotes, shop links, materials and correction rights.
- Build a booth-sampling grid: product category, visible price ladder, substrate/display, queue, public stockout sign and shopper question.
- Do not photograph no-photo booths or infer private numbers from crowd size.

### On the floor

- Sample 20 category-diverse booths every 60-90 minutes.
- Record public prices and visible item types; separate direct observation from vendor statements.
- Ask every interviewed maker to name one hard-to-find substrate or display component.
- Capture the shop/website/QR follow-up path with permission.
- Collect creator recommendations: “Who else should we speak with?” This is the beginning of the networking chain.

### After the Expo

- Send each creator their proposed attribution and links for verification.
- Track public post-event emails and shop updates for 30 days.
- Publish creator spotlights in a sequence that links each maker to a relevant supplier, technique, display choice or next event.
- Update the directory with interview dates, permission status, next action and warm introductions.

## What remains unknown

These are real research gaps, not unfinished prose:

1. **Complete city rosters and booth numbers:** no stable official public directory was located.
2. **Private economics:** sales, margins, conversion, average transaction and travel contribution are unknown until vendors disclose them.
3. **Organizer-reported tour total:** current and inherited sources phrase the 2026 city count differently.
4. **Sponsor/partner roster:** a conventional sponsor list was not located; operating partners are visible, but absence of a public roster does not prove absence of local or in-kind partners.
5. **Live social reach:** follower and engagement snapshots were not consistently accessible or comparable.
6. **Product-level provenance:** general brand claims do not replace item-level origin, permit and transfer documentation.
7. **Portland completeness:** four directly discoverable Portland vendors are not the complete city roster.
8. **Event profitability:** recurrence signals fit and operating capability, not profitability.

## Recommended next actions

1. Send the organizer a concise request for the Portland vendor list, press rules and a short organizer interview.
2. Begin Tier 1 outreach with the four Portland-confirmed vendors; ask each for two referrals.
3. Import the companion CSV into the master networking system and add owner, outreach status, permission status, next action and introduction source.
4. Build a separate product-infrastructure table from the top 20 interviews; prioritize cases, mounts, substrates, lighting, hardware and packing materials.
5. Use the Expo trip as research and documentary-content acquisition, not as an inventory commitment.
6. Refresh the census after Richmond, after the selected Expo visit and when the 2027 application opens.

## Core source list

- [Oddities & Curiosities Expo schedule](https://odditiesandcuriositiesexpo.com/pages/schedule-tickets)
- [Expo FAQ and vendor standards](https://odditiesandcuriositiesexpo.com/pages/faq)
- [Expo classes](https://odditiesandcuriositiesexpo.com/pages/classes)
- [Expo vendor application](https://odditiesandcuriositiesexpo.com/pages/application)
- [Oregon Convention Center Portland event page](https://www.oregoncc.org/attend/events/2026/11/oddities-and-curiosities-expo-2026)
- [Monsterologist events](https://monsterologist.com/pages/events), [shop](https://www.etsy.com/shop/Monsterologist), [wholesale](https://monsterologist.com/en-ca/pages/wholesale), and [retailers](https://monsterologist.com/pages/retailers)
- [Clockwork Art calendar](https://www.clockworkart.com/exhibits--events.html)
- [Harrison Farm oddities](https://www.harrisonfarm13.com/oddities)
- [LABCREATURE calendar](https://labcreature.com/pages/events-schedule) and [catalog](https://labcreature.com/collections)
- [Wondering Alchemist shop/calendar](https://www.etsy.com/shop/WonderingAlchemist)
- [Woodland Shrine calendar](https://www.woodlandshrine.com/2026-events-and-where-you-can-find-our-work)
- [Strong and Hardy calendar](https://www.strongandhardy.com/find-us)
- [Dark Matter Oddities shop announcement](https://www.etsy.com/shop/DarkMatterOddities)
- [Black Moth Candle Company calendar](https://blackmothcandleco.com/pages/market-schedule)
- [Mz. Jones’ Curio calendar](https://mzjonescurio.com/pages/upcoming-events)
- [Poltergeist Heist calendar/catalog](https://poltergeistheist.com/)
- [Sterling Fox Taxidermy](https://sterlingfoxtaxidermy.com/)
- [Mountain Medusa link hub/calendar](https://linktr.ee/mountainmedusa)
- [Austen Mengler calendar](https://www.austenmengler.com/events)
- [2026 Toronto report](https://6ixretail.com/2026/06/oddities-curiosities-expo-toronto-2026/)

Every directory row includes its own direct evidence URL and access date. This report should be integrated into the research master and networking atlas, while the CSV remains the operational artifact for outreach and later verification.
