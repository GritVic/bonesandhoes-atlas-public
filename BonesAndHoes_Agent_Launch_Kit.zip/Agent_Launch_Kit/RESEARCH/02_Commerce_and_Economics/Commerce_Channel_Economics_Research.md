# BonesAndHoes Commerce-Channel and Unit-Economics Research

**Decision report for Anna and Haley**  
**Research date:** August 18, 2026  
**Market:** United States unless otherwise stated  
**Evidence rule:** Platform rules, fees, and eligibility are sourced from first-party platform documentation. Assumptions and recommendations are labeled as such.

## Executive Summary

- **Start as a media-and-curation business, not as an inventory business.** The lowest-risk launch is a free legal-acquisition guide and project resource library, followed by affiliate links to products genuinely used in content. This proves which substrates, mounts, enclosures, tools, finishes, and safety supplies convert before committing cash to inventory.
- **Use a three-layer commerce stack.** Layer 1 is affiliate/creator commerce (TikTok Shop Creator, Amazon Associates, ShopMy, Impact/Awin programs). Layer 2 is digital products plus an Etsy shop limited to qualifying original/digital work. Layer 3 is an owned store, initially Square Online Free or Payhip for digital-only sales, migrating to Shopify when Shopify Collective or multichannel synchronization creates enough value to justify the monthly cost.
- **Do not use a single fulfillment method everywhere.** TikTok Shop allows a third-party fulfillment provider only when the seller owns the inventory; it expressly prohibits buying from another online retailer and having that retailer ship directly to the TikTok customer. Shopify Collective, by contrast, is designed for a retailer to sell a supplier's products with no inventory commitment while the supplier fulfills the order. Etsy permits production partners only for the seller's original designs or buyer-personalized items and generally does not permit reselling ordinary ready-made products.
- **The best early commercial role for TikTok is creator affiliate, not seller.** An Affiliate Creator needs 1,000 followers; a bound Official Account has no follower minimum but can only promote its own shop; a Marketing Account can self-sell without a follower minimum but needs 5,000 followers to access other sellers' marketplace products. Seller launch should wait until there is a compliant owned-product or authorized domestic-fulfillment arrangement.
- **The economics favor digital products and authorized supplier-direct products.** A $12 digital guide on Payhip Free can retain roughly $10.75 before income tax under the stated card-fee assumption. A $65 supplier-direct physical order can contribute about $13 in a base case, but only if the supplier cost, shipping, returns, and creator commission stay within defined limits. Affiliate earnings are low per view but carry almost no fulfillment risk and reveal demand.

## The Recommended Commercial Architecture

### Phase 0 — Build trust and capture demand (weeks 0–4)

1. Publish the free 50-state legal-acquisition and personal-use directory with a prominent source date, official-agency links, and non-legal-advice notice.
2. Build content around the full project journey: lawful discovery, documentation, preparation, material selection, build, finished display, and a complete supply list.
3. Apply for Amazon Associates, Impact/Awin publisher programs, and ShopMy if the public content presence is strong enough for review.
4. Use tagged links and a simple product taxonomy so every click and sale can be tied to a project stage and product family.
5. Do not buy inventory.

### Phase 1 — Monetize recommendations and digital knowledge (weeks 2–8)

1. Join TikTok Shop as an Affiliate Creator after the account reaches 1,000 followers and passes identity/age/compliance review.
2. Launch a free Payhip storefront for digital guides, project worksheets, sourcing checklists, finishing records, and legal-directory updates. Payhip permits free products that collect an email address and charges no monthly fee on its Free plan.
3. Open Etsy only for qualifying original digital products, original artwork, seller-made work, curated qualifying supplies, or original designs fulfilled by a disclosed production partner. Do not load ordinary mass-market shop supplies into Etsy.
4. Create product collections by real creative outcome rather than generic "kits": display stands; shadow-box and enclosure options; wood, metal, stone, textile, and botanical substrates; fasteners and armatures; adhesives; cleaning and finishing materials; safety gear; documentation and photography.

### Phase 2 — Establish an owned checkout and supplier-direct catalog (weeks 6–16)

1. Use **Square Online Free** if the first need is a no-monthly-cost owned checkout. Its cited plan has $0 monthly cost and online payment processing; a custom domain and stronger presentation require a paid tier.
2. Move to **Shopify Basic** when one of these triggers occurs:
   - Shopify Collective has at least 20 approved, relevant products with modeled contribution margins above 20%;
   - monthly gross profit attributable to store functions exceeds three times the monthly platform cost;
   - TikTok, Google, Meta, Pinterest, and YouTube catalog synchronization materially reduces operating work;
   - customer retention and email ownership become more valuable than marketplace-only discovery.
3. Use Shopify Collective for eligible domestic supplier relationships. The supplier fulfills; inventory and tracking synchronize; typical retailer margins cited by Shopify range from 20% to 50%. Negotiate returns and shipping before publishing products.
4. For manufacturers outside Collective, obtain written authorization, wholesale price lists, inventory feeds, shipping service levels, neutral/branded packing terms, return rules, product-liability allocation, and permission to use product imagery. Treat these as direct commercial agreements, not casual retail ordering.

### Phase 3 — Add marketplace seller channels only after product-market proof (months 4–12)

1. Launch a TikTok Seller account only for products backed by owned inventory, Fulfilled by TikTok, or a compliant third-party fulfillment provider holding the seller's inventory.
2. Add eBay selectively for standardized mounts, stands, vintage display hardware, unusual tools, and search-led products where buyers already know what they want.
3. Add Amazon Handmade only for qualifying handcrafted work with repeatable production and enough gross margin to absorb a 15% referral fee.
4. Use Faire later as a wholesale channel for owned difficult-to-find products sold to verified retailers. Faire is not the initial consumer storefront.

## Ranked Channel Decision Matrix

Scores are **strategic judgments**, not platform claims: 5 is best. "Data" means practical ownership/access to first-party customer relationships. "Ops" means lower operational burden scores higher.

| Rank | Channel | Best role | Cash risk | Data | Discovery | Margin potential | Ops | Launch stage | Decision |
|---:|---|---|---:|---:|---:|---:|---:|---|---|
| 1 | TikTok Shop Creator Affiliate | Content-linked products from other sellers | 5 | 1 | 5 | 2 | 5 | Phase 1 | Launch at eligibility; strongest native discovery test |
| 2 | Payhip | Free guide, digital resources, email capture | 5 | 4 | 2 | 5 | 5 | Phase 1 | Launch immediately; lowest-cost digital storefront |
| 3 | Amazon Associates | Broad tools/materials affiliate layer | 5 | 1 | 2 | 2 | 5 | Phase 0–1 | Launch early; useful breadth but modest rates |
| 4 | ShopMy / Impact / Awin publisher | Curated storefront and direct brand programs | 5 | 2 | 3 | 3 | 4 | Phase 0–1 | Apply early; prioritize relevant approved brands |
| 5 | Etsy | Original digital resources and qualifying art | 4 | 2 | 4 | 4 | 3 | Phase 1 | Use narrowly; marketplace fit is strong, resale rules are strict |
| 6 | Shopify + Collective | Owned store with supplier-direct catalog | 4 | 5 | 2 | 4 | 3 | Phase 2 | Best long-term commerce hub once demand is proven |
| 7 | Square Online Free | No-monthly-cost owned checkout | 5 | 5 | 2 | 4 | 4 | Phase 2 | Best bridge before Shopify if Collective is not yet needed |
| 8 | Pinterest Catalog + Google free listings | Evergreen discovery to owned checkout | 5 | 4 | 4 | n/a | 4 | Phase 2 | Add after a compliant website/catalog exists |
| 9 | Meta Shops | Product discovery and tagging to website checkout | 5 | 4 | 4 | n/a | 3 | Phase 2 | Add after owned checkout and catalog are stable |
| 10 | YouTube Shopping | Long-form project commerce | 5 | 4 | 4 | 3 | 4 | Phase 2–3 | Excellent fit after YouTube Partner Program eligibility |
| 11 | TikTok Shop Seller | Native owned-product sales | 2 | 2 | 5 | 4 | 2 | Phase 3 | Delay until fulfillment is fully compliant and proven |
| 12 | eBay | Search-led standardized/vintage supply sales | 3 | 2 | 4 | 3 | 3 | Phase 3 | Selective test, not brand home |
| 13 | Amazon Handmade | Qualifying handcrafted finished work | 2 | 1 | 5 | 2 | 2 | Phase 3 | High reach, high fee; only for high-margin repeatable items |
| 14 | Faire | Wholesale distribution of owned products | 2 | 3 | 4 | 3 | 2 | Phase 3 | Launch only after wholesale-ready SKUs exist |
| 15 | Gumroad | Digital backup/discovery marketplace | 5 | 3 | 3 | 3 | 5 | Optional | Payhip is financially better for direct sales at launch |

### Channel roles that should not be confused

- **Affiliate publisher/creator:** earns a commission; the merchant owns checkout, fulfillment, returns, and most customer data.
- **Marketplace seller:** BonesAndHoes is seller of record within the marketplace rules and carries fulfillment/customer-service obligations.
- **Owned-store retailer using an authorized supplier:** BonesAndHoes owns the customer relationship and retail offer; the supplier fulfills under a written commercial arrangement.
- **Wholesale brand:** BonesAndHoes owns or controls the product offered to retail businesses.

## TikTok Shop Playbook

### Route A — Affiliate Creator: launch first

**Verified eligibility (United States):** at least 18, US-based, no revoked e-commerce permission, policy compliance, identity verification, and at least 1,000 followers. New Affiliate Creators below 5,000 followers enter a pilot with product and posting limits. Official Shop Accounts and Marketing Accounts can bind to a seller with no follower minimum for self-selling; a Marketing Account needs at least 5,000 followers to promote marketplace products from other sellers. [S1]

**Setup sequence:**

1. Maintain a public, niche-consistent account with original content and a clean compliance record.
2. In the TikTok app, open TikTok Studio → Monetization → TikTok Shop for Creator → Join now.
3. Complete age confirmation and identity verification when prompted.
4. Establish the commission account with required personal and tax information before withdrawal.
5. Build a small showcase organized around actual project stages; do not create a random high-commission catalog.
6. Order or use products only when they are genuinely relevant. Show the product working inside the project and mention availability naturally.
7. State the commercial relationship clearly in the video/caption and follow FTC disclosure guidance.
8. Track views → product clicks → orders → net commission by product, creator format, and project stage.

**Pilot constraints:** TikTok's June 30, 2026 guidance says Affiliate Creators under 5,000 followers enter a 30-day pilot. The same page contains multiple frequency descriptions that are not perfectly aligned—three promotional videos per day in the detailed pilot section and five per week in an FAQ. Treat the in-app quota as controlling and verify it before scheduling. Campaign access is restricted during the pilot. [S1]

**Economics:** seller-set commissions vary by product. The creator should record the displayed commission, expected return/cancellation risk, price competitiveness, seller shop performance, and shipping promise before selecting an item.

**Data limitation:** the creator receives performance and commission information, not a first-party customer list. Affiliate commerce is a demand sensor and revenue layer, not the owned customer database.

### Route B — Seller: launch only after fulfillment proof

**Verified setup:** business verification, W-9, ship-from/return warehouse, product upload, and one Official TikTok Account. Product listings are reviewed and do not become visible until tax information and approval are complete. TikTok Shipping is the default during setup; products may also synchronize from an external store. [S2]

**Fees and cash flow:** most listed product categories carry a 6% referral fee; exact category rates must be verified before pricing. TikTok's current policy can pay sellers 1–31 days after delivery based on performance, and may hold reserve funds for 30 days. After-sales issues must be resolved before payout. [S3][S4][S5]

**Fulfillment red line:** TikTok permits third-party fulfillment when the seller owns the inventory. It prohibits purchasing products from another online retailer and directing that retailer to ship the order to the TikTok customer. US sellers also may not use international third-party suppliers or consolidation services under the cited fulfillment guidance. [S6][S7]

**Seller setup sequence:**

1. Choose the legal seller entity and make the entity name, tax record, bank information, address, and identity documents match exactly.
2. Establish a verified US ship-from and return address.
3. Select one compliant model for every SKU:
   - seller-owned stock shipped by seller;
   - seller-owned stock held by a US fulfillment provider;
   - Fulfilled by TikTok;
   - authorized arrangement that clearly satisfies TikTok's ownership and shipping rules.
4. Obtain safety data, labels, instructions, certificates, and product-liability coverage where applicable, particularly for chemicals, tools, electrical products, and protective equipment.
5. Build product detail pages with accurate materials, dimensions, compatibility, photographs, warnings, shipping, and return expectations.
6. Price with a reserve for 6% referral fee, creator commission, refunds, shipping adjustments, promotions, and payout delay.
7. Start with 5–10 proven products, not a large unverified catalog.
8. Audit on-time dispatch, tracking scans, cancellations, returns, customer messages, and contribution margin weekly.

**Returns and customer information:** TikTok can initiate eligible partial-refund requests and enforces its return/refund workflow. Buyer information may be used only for permitted order/service purposes; off-platform solicitation and misuse are restricted. [S8]

**Launch gate:** no Seller launch until every SKU has a named supplier, written authorization, product cost, inventory-ownership status, ship-from address, tracking method, delivery SLA, return owner, safety documents, platform category approval, and positive base-case contribution margin.

## Etsy Playbook

### What belongs in the shop

- Original downloadable legal-research summaries, checklists, records, worksheets, sourcing guides, and project planners.
- Original artwork and seller-made finished pieces that comply with applicable law and Etsy's prohibited-items policy.
- Original designs produced by a disclosed production partner.
- Qualifying craft and party supplies, if the exact items meet Etsy's Creativity Standards.

### What does not belong

- Ordinary mass-produced products merely sourced from another retailer.
- Undesigned ready-made goods fulfilled by a production partner.
- Listings used to move Etsy-initiated buyers to an off-platform checkout.
- Any product whose legal origin, sale, transfer, or material status has not been verified.

Etsy states that use of production partners is allowed when the item is the seller's original design or buyer-personalized; otherwise it can violate policy. Etsy also prohibits moving a transaction initiated on Etsy off-platform. [S9][S10]

### Setup sequence

1. Create the Etsy account and open the shop from a desktop browser.
2. Select shop language, country, currency, and a 4–20 character shop name.
3. Connect a bank account, add a payment card, supply tax/business information, and pay the displayed one-time setup fee, which varies by location.
4. Complete identity verification using a government ID and selfie/manual-review option.
5. Publish at least one fully compliant listing; build banner, logo, About section, policies, processing times, and FAQs.
6. For digital products, show clear page previews, file contents, version date, scope, limitations, and update policy.
7. For physical work, disclose who made/designed it and any production partner.
8. Use Etsy search data to test wording and demand, while maintaining the owned email list through lawful, opt-in interactions outside any effort to divert an Etsy transaction.

### Fees and pricing

- Listing: $0.20 per listing or renewal; a listing generally lasts four months.
- Transaction: 6.5% of item price plus charged shipping and gift wrapping.
- Payment processing: varies by bank country and is charged on the total transaction; verify the US rate in the live onboarding/payment policy before final modeling.
- One-time setup fee: varies by location and appears during onboarding.
- Optional advertising, Offsite Ads, shipping labels, currency conversion, and regulatory fees can add cost. [S10][S11]

**Planning allowance:** until the live US payment rate and Offsite Ads status are confirmed, reserve **10%–15% of revenue plus $0.20 per unit** for Etsy/platform/payment costs, excluding postage and income tax. This is a conservative planning assumption, not an Etsy quote.

### Etsy launch assortment

1. Free/low-cost state-law research worksheet that points to official sources.
2. Personal-use project documentation journal.
3. Preparation and safety checklist.
4. Display-design planning sheets for multiple substrates and mounting approaches.
5. Vendor-comparison workbook for stands, enclosures, tools, finishes, and hardware.
6. Original printable art or educational visual resources.

**Launch gate:** every listing passes a Creativity Standards review, prohibited-items review, origin/legal review, and margin check.

## Other Channel Playbooks

### Owned store: Square first, Shopify when synchronization pays for itself

**Square Online Free:** cited US pricing is $0 per month. The source captured online processing at 2.9% + $0.30 on the prior plan page, while a newer unified-pricing page displays 3.3% + $0.30 for the Free tier; verify the rate shown in the account at signup. A paid plan is required for a custom domain and stronger customization. Square supports shipping, customer accounts, social selling, and multiple payment types. [S12]

**Shopify Basic:** $39 month-to-month or $29/month billed yearly as displayed on August 18, 2026. It offers an owned checkout, unlimited products, and social/marketplace integrations. Shopify's TikTok channel can synchronize catalog, inventory, orders, and fulfillment. [S13][S14]

**Decision:** start Square Free if the catalog is manually manageable. Choose Shopify directly if Collective is central to the initial physical catalog or multichannel synchronization is worth at least $29–$39 each month.

### Shopify Collective and authorized supplier-direct commerce

Collective is free on eligible active Shopify plans, requires Shopify Payments and matching supported location/currency conditions, and has no minimum store-sales requirement. Retailers import supplier products without upfront inventory, the supplier ships to the customer, and tracking synchronizes. Shopify says retailer margins typically range from 20% to 50%. Default new-retailer return policy has the supplier processing returns with a 30-day window, but policies can be negotiated. [S15][S16][S17]

**Required supplier scorecard:** relevance; landed cost; discount/margin; price-control terms; inventory feed quality; same-day/two-day handling; carrier scans; packaging; returns; damage rate; warranty; product-liability insurance; safety documentation; content/image rights; customer-service escalation; termination/data terms.

**Do not promise a bundled box fulfilled by several unrelated retailers.** Present it as a curated project supply list or let customers add individual products to a cart. Only advertise a single bundled SKU when one responsible supplier/fulfillment operation can ship and support it as one compliant product.

### Meta Shops

Meta requires commerce-policy compliance, a represented business/domain, a supported country, trustworthiness, and accurate information. Current setup uses Commerce Manager, a Facebook Page/catalog as applicable, an Instagram business account for Instagram visibility, a delivery profile, and a required website checkout URL. Review can take up to four weeks. [S18][S19]

**Role:** discovery, product tagging, and retargeting that sends the buyer to the owned checkout. This preserves the website transaction and first-party customer relationship, subject to consent/privacy rules.

### Pinterest Shopping and Google free listings

Pinterest requires a business account, claimed website, Pinterest tag, and a website with contact, shipping, and refund policies. Catalog feeds require IDs, title, description, link, image, price, availability, and variants where applicable. [S20]

Google Merchant Center free listings can surface products across Search, Maps, Images, Lens, YouTube, Gemini, and Shopping. A return policy, shipping settings, accurate product data, and matching site/catalog prices are central requirements. [S21]

**Role:** evergreen discovery for visual project supplies and finished-display inspiration. Implement after the owned catalog is stable.

### YouTube Shopping

Creators can connect supported stores and tag owned products once eligible; connected products undergo policy review. Promoting other brands requires YouTube Partner Program eligibility, supported location, a non-music/non-kids channel, and a clean guideline status. YouTube reports tagged-product performance in Analytics. [S22][S23]

**Role:** pair long-form discovery, preparation, and build videos with exact supply lists. This is strategically excellent but eligibility-dependent.

### Amazon

**Associates:** relevant categories generally pay low single-digit fixed rates—3% for Home, Home Improvement, Tools, Outdoors, and related categories; 4.5% for Kitchen; 5% for Handmade under the cited current schedule. [S24]

**Seller:** Individual is $0.99 per unit plus category referral fees; Professional is $39.99/month plus referral fees. [S25]

**Handmade:** approved makers receive the ongoing Professional fee waiver after the first month, but each shipped unit carries a 15% or $0.30 minimum referral fee. [S26]

**Role:** Associates for broad supplies now; Handmade only later for qualifying high-margin handcrafted products. Amazon is not the home for the brand's customer relationship.

### eBay

Non-store sellers receive up to 250 zero-insertion-fee listings monthly. Final value fees vary by category and include a per-order fee ($0.30 at $10 or less; $0.40 above $10); eBay manages payment and deducts fees. Store plans start at $7.95 monthly or $4.95/month with yearly renewal, with category-dependent fee discounts and larger listing allowances. Payout cadence can be daily, weekly, biweekly, or monthly. [S27][S28]

**Role:** narrow assortment of known-search-intent hardware, vintage display objects, unusual stands, and tools. Verify each category's current fee and policy before listing.

### Faire

Faire is wholesale. For North American brands it is free to join; marketplace-discovered orders carry 15% commission plus a one-time $10 new-customer fee on the first order. Faire Direct orders from customers the brand brings carry 0% commission. Processing cost varies by payout speed. Faire manages eligible first-order returns within a 60-day window without reducing the brand's payout for standard returns. Verified retailers may qualify for Net 60 terms. [S29][S30][S31]

**Role:** later distribution of owned mounts, stands, display components, or other difficult-to-find branded products to independent stores. Wholesale pricing must still leave the retailer room for a normal retail markup.

### Affiliate networks and creator storefronts

- **Impact:** creator/publisher Marketplace signup is free; a verified media property, tax residency information, and marketplace application are required. Brand-side Starter begins at $30/month plus 2.5% on partner-driven transactions; full marketplace access begins on the much more expensive Essentials tier. Use as a publisher first, not as a brand running a program. [S32][S33]
- **Awin:** publisher earnings depend on advertiser approval/payment status; payment is generally on the 1st or 15th after commissions clear and the $20 network minimum is met. Brand-side Access is $49/month plus 3.5% of transaction value, in addition to the partner commission. Use as a publisher first. [S34][S35]
- **ShopMy:** curated creator application; storefront, affiliate links, codes, and brand collaborations. The platform states typical creator commissions of 10%–30% and Friday payouts through PayPal or Stripe, but category fit must be tested because much of its public positioning is premium lifestyle. [S36]
- **LTK/CJ/ShareASale:** evaluate when specific relevant brands are identified. Public first-party materials did not provide enough current, decision-grade onboarding/fee detail in this pass; mark as **unverified**, not assumed.

### Digital-product platforms

- **Payhip:** $0/month + 5%; $29/month + 2%; $99/month + 0%, plus payment-processor fees. Free products can collect email addresses. Immediate deposit is advertised. Best launch choice. [S37][S38]
- **Gumroad:** no monthly fee; 10% + $0.50 on profile/direct sales and 30% for Discover sales. Gumroad acts as merchant of record for indirect tax. [S39]
- **Ko-fi:** current primary-source pricing was not sufficiently verified in this pass; do not select it on remembered pricing.

## Unit-Economics Models

These are **planning models**, not forecasts. They exclude income tax, owner labor, legal/accounting costs, chargebacks beyond the listed reserve, and advertising unless shown. Replace every assumption with observed data after the first 30 orders.

### Model A — Affiliate content per 10,000 qualified views

Formula: `views × product-link click rate × merchant conversion rate × average order value × commission rate`

| Scenario | Link click rate | Merchant conversion | AOV | Commission | Orders | Creator revenue / 10k views |
|---|---:|---:|---:|---:|---:|---:|
| Conservative | 1.0% | 1.0% | $35 | 3% | 1 | $1.05 |
| Base | 2.0% | 2.5% | $55 | 8% | 5 | $22.00 |
| Upside | 4.0% | 4.0% | $85 | 15% | 16 | $204.00 |

**Interpretation:** affiliate revenue will be uneven and often small, but it costs little cash and reveals exactly which product, project, and creative format creates purchase intent. Optimize revenue per qualified click and repeatable content, not raw views.

### Model B — Authorized supplier-direct physical order

Base order AOV is $65. Percentages are of customer revenue. "Supplier cost" includes the wholesale product amount; shipping subsidy is any amount not paid by the customer.

| Scenario | Supplier cost | Platform/payment | Creator commission | Shipping subsidy | Return/damage reserve | Contribution | Dollars/order |
|---|---:|---:|---:|---:|---:|---:|---:|
| Conservative | 62% | 8% | 10% | 7% | 5% | 8% | $5.20 |
| Base | 55% | 6% | 10% | 5% | 4% | 20% | $13.00 |
| Upside | 45% | 5% | 8% | 4% | 3% | 35% | $22.75 |

**Launch gate:** reject or renegotiate any product below 15% base-case contribution before owner labor. Target 20%+ for standardized supplies and 30%+ for difficult-to-find owned products.

### Model C — $12 digital guide

Assumption: card processing of 2.9% + $0.30 where charged separately.

| Channel | Platform fee | Est. processor | Net before labor/tax | Net margin |
|---|---:|---:|---:|---:|
| Payhip Free | $0.60 | $0.65 | $10.75 | 89.6% |
| Gumroad direct | $1.70 | $0.65* | $9.65 | 80.4% |
| Etsy planning case | $0.20 + 6.5% + est. 3%+$0.25 | included in estimate | ~$10.41 | ~86.8% |

\*Gumroad's help page says card processing can be additional; actual settlement configuration must be checked. Etsy figure excludes setup, ads, taxes, and currency fees and is illustrative.

### Model D — Channel break-even triggers

- **Payhip Plus vs Free:** saves 3 percentage points for $29/month; break-even platform revenue is about **$967/month** before processor fees (`$29 ÷ 0.03`).
- **Payhip Pro vs Plus:** saves 2 percentage points for an extra $70/month; break-even is **$3,500/month**.
- **Shopify Basic annual vs Square Free:** if Shopify costs $29/month, it should create at least $87/month in incremental gross profit (3× hurdle), save three or more operating hours, or unlock Collective supply with materially better economics.
- **Amazon Individual vs Professional:** the $39.99 plan equals roughly 41 units at $0.99 each; Amazon itself suggests Individual below 40 units/month, before feature differences.

## Launch Sequence and Decision Gates

### First 30 days

- Publish one free lead magnet and one paid digital product on Payhip.
- Establish affiliate accounts available at current audience size.
- Build a 50-product approved recommendation library; every item must have an exact job in a project.
- Instrument every link with product family, project, platform, content, and date.
- Produce 12 content units across discovery, preparation, build, and reveal stages.

**Gate:** at least 100 qualified outbound clicks and a complete product-level click report.

### Days 31–90

- Apply for TikTok Shop Creator at eligibility.
- Launch 6–12 Etsy listings limited to qualifying products.
- Contact 25 manufacturers/brands for affiliate, wholesale, or Collective relationships.
- Score at least 50 supplier-direct products; publish none below the launch margin/fulfillment gate.
- Add Pinterest and Google feeds once an owned checkout exists.

**Gate:** at least 10 attributed transactions, three independently converting product families, and no unresolved compliance or fulfillment failure.

### Months 4–6

- Choose Square Free or Shopify based on the triggers above.
- If Shopify, onboard 2–5 Collective suppliers and test 10–20 products.
- Connect Meta Shops; prepare YouTube Shopping when eligible.
- Develop one owned difficult-to-find product only after repeated audience demand and supplier validation.

**Gate:** positive contribution after returns for two consecutive months and a documented customer-service process.

### Months 7–12

- Consider TikTok Seller only for compliant, proven SKUs.
- Evaluate eBay for search-led products and Amazon Handmade for qualifying high-margin work.
- Prepare Faire only when wholesale pricing, case packs, lead times, liability coverage, and retailer support are ready.

## Measurement Framework

Track weekly by content item, product, and channel:

- qualified views and saves;
- link clicks and click-through rate;
- merchant/product page conversion;
- orders, cancellations, returns, and net commission;
- AOV and items/order;
- supplier fill rate and late dispatch;
- net contribution dollars and percentage;
- digital lead-magnet opt-ins and email-to-sale conversion;
- repeat purchase and returning-customer revenue on the owned store;
- questions requested by viewers, coded into product and guide opportunities.

The first decision metric is **net contribution per 1,000 qualified views**, not follower count. The second is **net contribution per order after returns**. The third is **repeat demand by product family**.

## Risks, Caveats, and Open Questions

1. Platform rules and fees change. Recheck every cited policy at account setup and quarterly thereafter.
2. Several product families may involve chemicals, sharp tools, electrical items, or safety claims. Product-liability and required warnings need a separate review.
3. Legal treatment of naturally sourced materials varies by species, land ownership, acquisition method, state, locality, and federal law. The legal directory must rely on current government sources and cannot imply universal permission to sell or transfer material.
4. TikTok's current creator pilot page contains internally inconsistent posting-frequency wording; the live in-app quota controls.
5. LTK, CJ, ShareASale, and Ko-fi remain research gaps in this pass because current primary-source fee/onboarding evidence was not decision-grade.
6. The actual audience size, geographic mix, engagement, and content history were not provided to this workstream. Channel eligibility and revenue models must be recalibrated after those analytics are available.
7. Supplier margins of 20%–50% are Shopify's general Collective statement, not a promise for this niche. Every supplier price list must be modeled individually.

## Immediate Owner Decisions

1. Which public account will be the primary commerce identity, and what are its current follower and analytics figures?
2. Will the first owned checkout be Payhip-only for 30 days, or should Square Free launch concurrently?
3. Which five project types will anchor the initial product taxonomy?
4. Who will approve legal/safety language before publication?
5. What minimum gross margin and maximum delivery time will be non-negotiable for supplier-direct products?

## Primary Source Ledger

All sources accessed August 18, 2026.

- **S1 — TikTok Shop creator types, eligibility, pilot, and application:** https://seller-us.tiktok.com/university/essay?default_language=en&identity=1&knowledge_id=7608640301074219
- **S2 — TikTok Shop seller setup:** https://seller-us.tiktok.com/university/essay?default_language=en&identity=1&knowledge_id=5159959451715374
- **S3 — TikTok referral fee update:** https://seller-us.tiktok.com/university/essay?default_language=en&knowledge_id=5982454398175018
- **S4 — TikTok category referral rates:** https://seller-us.tiktok.com/university/essay?knowledge_id=5988482086864682
- **S5 — TikTok dynamic settlement/reserve:** https://seller-us.tiktok.com/university/essay?default_language=en&knowledge_id=3995852763531009
- **S6 — TikTok customer-order shipping policy:** https://seller-us.tiktok.com/university/essay?default_language=en&identity=1&knowledge_id=6837879804970754
- **S7 — TikTok fulfillment best practices:** https://seller-us.tiktok.com/university/essay?from=policy&identity=1&knowledge_id=6179821974439723&role=1
- **S8 — TikTok June 2026 policy update:** https://seller-us.tiktok.com/university/essay?knowledge_id=6747273381791534
- **S9 — Etsy production/reselling rules:** https://help.etsy.com/hc/en-us/articles/23948763872151-Does-Etsy-Allow-Drop-Shipping-or-Reselling
- **S10 — Etsy fees and off-platform transaction policy:** https://www.etsy.com/legal/fees/
- **S11 — Etsy shop setup:** https://help.etsy.com/hc/en-us/articles/115015672808-How-to-Open-an-Etsy-Shop
- **S12 — Square Online plans:** https://squareup.com/us/en/online-store/plans
- **S13 — Shopify pricing:** https://www.shopify.com/pricing
- **S14 — Shopify TikTok setup:** https://help.shopify.com/en/manual/online-sales-channels/social-commerce/tiktok/setup
- **S15 — Shopify Collective overview:** https://help.shopify.com/en/manual/online-sales-channels/shopify-collective
- **S16 — Shopify Collective retailer operations/margins:** https://help.shopify.com/en/manual/online-sales-channels/shopify-collective/retailers
- **S17 — Shopify Collective returns:** https://help.shopify.com/en/manual/online-sales-channels/shopify-collective/retailers/policies/returns
- **S18 — Meta commerce eligibility:** https://www.facebook.com/help/instagram/1627591223954487
- **S19 — Meta Shop setup:** https://www.facebook.com/help/instagram/1187859655048322/
- **S20 — Pinterest retail catalogs:** https://help.pinterest.com/en/business/article/before-you-get-started-with-catalogs
- **S21 — Google free product listings:** https://support.google.com/merchants/answer/13889434
- **S22 — YouTube Shopping eligibility:** https://support.google.com/youtube/answer/12257682
- **S23 — YouTube store connection:** https://support.google.com/youtube/answer/12258186
- **S24 — Amazon Associates commission schedule:** https://affiliate-program.amazon.com/help/node/topic/GRXPHT8U84RAYDXZ
- **S25 — Amazon seller plans:** https://sell.amazon.com/learn/faq
- **S26 — Amazon Handmade:** https://sell.amazon.com/programs/handmade
- **S27 — eBay selling fees:** https://www.ebay.com/help/selling/selling-fees/store-fees?id=4822
- **S28 — eBay store fees:** https://www.ebay.com/help/selling/fees-credits-invoices/store-selling-fees?id=4809
- **S29 — Faire North American brand fees:** https://www.faire.com/support/articles/360015893392
- **S30 — Faire returns:** https://www.faire.com/support/articles/360015893332
- **S31 — Faire retailer verification:** https://www.faire.com/support/articles/4415920212123
- **S32 — Impact creator/publisher onboarding:** https://help.impact.com/partner/readme/im-a-creator/step-1-work-with-brands
- **S33 — Impact pricing:** https://impact.com/integrated-platform-prices/
- **S34 — Awin advertiser pricing:** https://www.awin.com/us/pricing/advertisers
- **S35 — Awin publisher payment process:** https://www.awin.com/us/news-and-events/publisher-training/understanding-the-payment-process
- **S36 — ShopMy creator program:** https://shopmy.us/home/creators
- **S37 — Payhip pricing:** https://payhip.com/pricing
- **S38 — Payhip free products:** https://help.payhip.com/article/76-how-to-create-a-free-product
- **S39 — Gumroad pricing:** https://gumroad.com/pricing

## Research QA Record

- First-party sources used for every fee, eligibility, and policy claim: **Pass**
- Facts separated from recommendations and planning assumptions: **Pass**
- Direct URLs and access date preserved: **Pass**
- Platform-specific fulfillment conflicts surfaced: **Pass**
- Unverified channels labeled rather than guessed: **Pass**
- Unit-economics formulas and assumptions exposed: **Pass**
- Final prices/fees flagged for live-account confirmation: **Pass**
