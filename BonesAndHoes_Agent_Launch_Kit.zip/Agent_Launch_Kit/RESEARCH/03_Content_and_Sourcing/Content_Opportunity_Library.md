# BonesAndHoes Content Opportunity Library

**Research status:** Source-grounded working artifact  
**Geographic center:** Central Oregon, with Pacific Northwest extensions  
**Verified:** August 18, 2026  
**Purpose:** Give Anna and Haley a repeatable content system that turns authentic discovery, preparation, making, display, and community relationships into audience trust and ethical commerce.

## Executive recommendation

The content engine should not be built around product pitches. It should be built around three recurring audience promises:

1. **Help me find unusual materials responsibly.**
2. **Show me how an interesting object becomes a finished art project.**
3. **Introduce me to the people, places, techniques, and tools that make the niche richer.**

Products become useful because viewers see them solve real problems inside those stories. A single project can naturally expose a substrate, stand, enclosure, fastener, adhesive, finish, light, label, and storage solution without turning the episode into an advertisement. If a featured item produces compensation, the relationship must be disclosed clearly in the content and near the link.

The recommended launch stack is:

- A weekly **Found, Chosen, Made** project episode.
- A weekly **Treasure Route** sourcing episode or short.
- A monthly **Maker or Vendor Field Notes** interview.
- A monthly **One Find, Three Directions** design challenge.
- A durable project page or email containing the source story, material list, safety notes, maker credit, and shop links.

## Part I — Expo interview and content system

### 1. The editorial premise

The Expo is not merely an event recap. It is a temporary concentration of makers, vendors, methods, display decisions, pricing experiments, and customer questions. The goal is to document the ecosystem while giving each participant control over how their work is represented.

Every interview should extract four layers:

- **Human:** How the maker entered the field and what keeps them interested.
- **Creative:** Materials, process, display choices, and artistic point of view.
- **Commercial:** Offer structure, price ladder, sales channel, repeat customers, and operational lessons.
- **Network:** Suppliers, collaborators, communities, events, and experts worth meeting next.

### 2. Interview formats

| Format | Runtime | Best use | Core output |
|---|---:|---|---|
| The 60-Second Booth Story | 45–75 sec | High-volume short-form capture | Who they are, signature work, one surprising detail, where to follow |
| Object With a Story | 2–4 min | A visually striking work or material | Origin, transformation, technique, meaning, display decision |
| How the Booth Earns | 4–8 min | Vendors willing to discuss business | Offer ladder, best entry item, repeat-purchase driver, event lesson |
| Three Tools I Would Replace Tomorrow | 2–5 min | Supply-rich makers | Specific tools/materials and why they matter |
| First-Timer Field Note | 2–4 min | New exhibitor perspective | Expectations, setup, pricing, what surprised them |
| Veteran Debrief | 5–10 min | Experienced vendors | Market changes, audience behavior, merchandising, mistakes |
| Design Decision Walkthrough | 3–6 min | Display-focused booth | Stand, base, enclosure, lighting, label, transport, price card |
| Lightning Network Map | 60–90 sec | Every willing guest | “Who should we meet next, and why?” |
| After-Hours Roundtable | 15–30 min | Four to six participants | Shared challenges, ethics, sourcing, audience misconceptions |
| Silent Booth Study | 20–40 sec | No interview time | Detail shots plus approved text card and tagged credit |

### 3. Question bank

#### Opening and identity

- What do you make, and what do you want someone to notice first?
- What first pulled you into this work?
- What is the one object in this booth that best represents your point of view?
- What is often misunderstood about your process?

#### Project and process

- Walk us through this piece from first decision to finished display.
- Which step requires the most judgment?
- What substrate, stand, enclosure, or hardware choice made the work succeed?
- What tool or material solved a problem you could not solve another way?
- What failed before you found the current method?
- How do you document source, treatment, and materials?

#### Audience and demand

- What question do customers ask most often?
- What brings someone into the booth, and what helps them decide?
- Which entry-level item helps new customers understand your work?
- What do collectors return for?
- Is there something customers repeatedly request that is difficult to provide?

#### Monetization intelligence

- What are the distinct ways this practice supports itself: finished work, commissions, supplies, classes, digital resources, events, or other routes?
- Which offer is easiest to start with, and which takes the most time?
- What display or price-point change improved sales?
- Which channel works best for discovery, and which works best for transactions?
- Which cost surprises new vendors most?
- What would you never stock deeply before demand is proven?
- What supplier, service, or hard-to-find item would make your work easier?

#### Network expansion

- Which maker, teacher, supplier, event, museum, or organization should this audience know?
- Who taught you something that changed your work?
- What collaboration would you like to see in this niche?
- May we include your links and preferred contact route in the Networking Atlas?

#### Closing

- Where should people follow or shop your work?
- What should a beginner learn before attempting a similar project?
- Is there anything shown here that you do not want filmed or discussed?

### 4. Permission, attribution, and rights workflow

This is an operational workflow, not legal advice. The organizer’s current media rules and venue requirements govern first.

**Before the Expo**

1. Obtain the organizer’s written media policy and any credential.
2. Ask whether booth exteriors, crowds, children, artwork close-ups, demonstrations, and audio capture have distinct restrictions.
3. Send invited vendors a one-page explanation: channels, intended uses, editing style, credit practice, commercial links, and contact information.
4. Prepare a short written appearance-and-use release covering video, audio, stills, excerpts, captions, Atlas inclusion, promotion, and the participant’s preferred credit. Obtain legal review before reuse as a standard form.
5. Create a vendor intake row before filming: legal/business name, public name, pronouns if supplied, website, social handles, shop URL, contact, spelling, prohibited shots, products discussed, compensation or gifts, and release status.

**At the booth**

1. Ask the exhibitor controlling the booth for permission before setup.
2. Record an on-camera confirmation as a backup, but use the written workflow as the standard.
3. Place a small “interview in progress” sign where bystanders can see it.
4. Frame tightly to avoid recording neighboring booths and private customer conversations.
5. Do not film minors without a parent or guardian’s explicit written authorization.
6. Reconfirm any object, technique, supplier, or price the participant wants kept off camera.

**After capture**

1. Log filenames to the vendor record immediately.
2. Transcribe names, terminology, links, prices, and factual claims; flag anything uncertain.
3. Send the participant a spelling/link confirmation and, when promised or prudent, the relevant excerpt for factual review—not open-ended editorial control.
4. Record approval, corrections, restrictions, and expiration terms.
5. Use the participant’s preferred tag in the first visible lines of the caption and in the Atlas entry.
6. Keep raw releases, messages, and published URLs in the rights ledger.

**Commercial disclosures**

- The FTC says a material relationship—including payment, free goods, discounts, personal relationships, or other value—must be obvious and hard to miss. For video, disclosure should be in the video, not solely in the description.
- TikTok requires its content-disclosure setting for commercial content; use it in addition to plain-language disclosure where required.
- Put an affiliate disclosure near linked recommendations. Do not bury it among hashtags.
- Only link the exact item genuinely used or clearly identify a reasonable alternative.

Sources: [FTC Disclosures 101](https://www.ftc.gov/business-guidance/resources/disclosures-101-social-media-influencers), [FTC endorsement questions](https://www.ftc.gov/business-guidance/resources/ftcs-endorsement-guides-what-people-are-asking), [TikTok commercial-content guidance](https://support.tiktok.com/en/business-and-creator/creator-and-business-accounts/promoting-a-brand-product-or-service), [YouTube copyright guidance](https://support.google.com/youtube/answer/2797466), [YouTube monetization rights guidance](https://support.google.com/youtube/answer/2490020).

### 5. Expo capture checklist

#### Listen for

- A process problem that has a repeatable solution.
- A hard-to-find supply or service.
- A surprising material or display choice.
- A customer question heard repeatedly.
- A clear price ladder or business-model pattern.
- An underserved audience or geographic gap.
- A supplier or collaborator named by multiple people.
- A claim requiring later verification.

#### Shoot

- Venue exterior and event identity where permitted.
- Wide booth view, medium maker view, and close detail views.
- Hands demonstrating a safe, approved technique.
- Front, side, back, underside, fastening, label, and display support.
- Price/menu signage only with permission.
- Packaging and transport method.
- A clean portrait and five seconds of stillness for thumbnails.
- Room tone and 10 seconds of booth ambience.
- A vertical closing answer and horizontal closing answer when time allows.

#### Record in the field log

- Vendor ID, time, booth number, interviewer, camera filenames.
- Release and restriction status.
- Exact product and supplier names mentioned.
- Public prices and whether they are Expo-specific.
- Monetization methods observed versus explicitly stated.
- Follow-up request and next introduction.

### 6. Before, during, and after the Expo

**Four to six weeks before**

- Publish “Who should we meet?” and collect audience questions.
- Preview the event’s rules, purpose, and respectful-visitor etiquette.
- Invite vendors using a consistent pitch and offer them their finished vertical clip.
- Build the vendor research sheet and mark priority interviews by uniqueness, teaching value, commercial insight, and network reach.
- Publish a packing and interview-kit checklist with naturally used equipment links.

**During**

- Morning “five booths on today’s route.”
- Short booth stories, design-decision details, and one daily audience question.
- A noncommercial “people to follow” recap.
- End-of-day pattern memo: repeated questions, price bands, displays, supply gaps, and introductions.

**One to two weeks after**

- Publish individual maker stories before broad trend claims.
- Release “What 20 vendors taught us” with observed facts separated from interpretation.
- Build an attributed vendor directory and networking map.
- Create supply and display guides from products genuinely demonstrated.
- Send each guest their live links, credit, and a low-pressure invitation for a future project.

**Long tail**

- Group interviews by technique, product category, audience question, or business model.
- Invite selected makers into full project collaborations.
- Revisit Expo predictions after six months.
- Maintain an “introduced by” field to turn isolated contacts into a visible relationship chain.

### 7. Repurposing map

One 8-minute vendor interview can become:

- 1 edited long-form interview.
- 3–5 short clips: origin, technique, tool, business lesson, next introduction.
- 1 photo carousel showing a design decision.
- 1 email profile with maker links and source notes.
- 1 Atlas vendor entry.
- 1 Networking Atlas node and relationship edge.
- 1 product-research lead.
- 1 quote card, only after quote verification.
- 1 follow-up project or livestream topic.

The sequence is **credit first, insight second, commerce third**. Vendor work should never be stripped of context merely to surround a product link.

## Part II — Treasure Sourcing for Art Projects

### 1. Series structure

**Series name:** *Treasure Routes: Finding the Piece Around the Piece*

Each episode starts with a project need rather than indiscriminate shopping:

1. Define the job: base, frame, stand, enclosure, light, cabinet, hardware, texture, or storage.
2. Set constraints: dimensions, weight, stability, condition, cleanability, price ceiling, and transport.
3. Search one or more legitimate secondhand sources.
4. Ask before filming; never reveal a private residence or seller identity without permission.
5. Inspect the find and explain why it works or fails.
6. Document cleaning, repair, adaptation, and final use.
7. Compare total cost and labor with a readily available new option.
8. Link only the products actually used in the adaptation, plus clearly labeled alternatives.

This format makes judgment—not consumption—the attraction.

### 2. Central Oregon sourcing directory

Inventory and hours change constantly. Confirm before travel.

| Resource | Coverage / location | Sourcing strengths | Cautions and episode hook |
|---|---|---|---|
| [Bend–Redmond Habitat ReStore](https://restorebend.org/hours-and-location-bend/) | 224 NE Thurston Ave, Bend; 2744 NW 7th St, Redmond | Cabinets, lighting, hardware, lumber, frames, fixtures, project bases | Inspect electrical and finish condition. Hook: “Can a cabinet door become a museum-style backing?” |
| [La Pine–Sunriver Habitat ReStore](https://www.habitatlapinesunriver.org/restore) | La Pine / south Deschutes County | Building materials, fixtures, hardware, furniture | Call for current categories. Hook: rural ReStore challenge under a set budget. |
| [Sisters Habitat ReStore and Thrift Store](https://www.sistershabitat.org/) | Sisters; ReStore and thrift operations | Home goods, building materials, frames, display furniture | Two-store route; verify hours. Hook: one project sourced across both formats. |
| [Habitat national local-search result for 97702](https://www.habitat.org/local/restore?zip=97702) | Central Oregon locator | Confirms nearby affiliates and contact details | Use as route planner, then confirm locally. |
| [Humane Society of Central Oregon Thrift Store](https://www.hsco.org/thrift-store) | 61220 S Highway 97, Bend | Household goods, antiques, collectibles, jewelry, furniture, frames | Goods change daily; obtain store filming consent. Hook: a display solution that also supports shelter animals. |
| [Possibilities Thrift Stores](https://www.opportunityfound.org/) | Redmond and Madras | Antiques, clocks, china, furniture, paintings, pottery, textiles, lamps, frames | Their accepted-items document excludes building materials and chemicals. Hook: frame-and-lamp search that supports disability services. |
| [St. Vincent de Paul Redmond Thrift Store](https://www.svdpredmond.org/services/thrift-store) | Redmond | General thrift, household and decor finds | Verify stock and filming. Hook: “five display candidates, one winner.” |
| [Redmond Antique Mall](https://www.redmondantiquemall.net/) | 106 SE Evergreen Ave, Redmond | 50+ vendors, changing vintage decor, primitives, collectibles | Individual-dealer items can carry higher prices; request filming approval. Hook: compare five eras of stands and display vessels. |
| [Old Boy Vintage](https://oldboyvintage.com/) | 124 NW Greenwood Ave, Bend | Vintage and antiques, collaboration contact, curated visual inventory | Curated prices may exceed thrift. Hook: when paying more for the right finished design saves adaptation time. |
| [Roundabouts Home Consignments](https://www.rhcbend.com/) | 1132 NE 2nd St, Bend; currently appointment-oriented | Pre-owned decor, solid wood, antiques, project furniture, changing online previews | Confirm appointment and dimensions. Hook: finding a stable base inside a furniture showroom. |
| [Merryweather](https://www.merryweather.shop/new-page) | 550 SW Industrial Way #180, Bend | Curated antiques, decor, layered display inspiration | Design inspiration more than bargain hunting. Hook: reverse-engineer why a display feels intentional. |
| [Sisters shopping directory](https://exploresisters.com/shopping/) | Sisters | A Touch of Faith Thrift, Big Chief Vintage, frame shop, home-decor shops, antique destinations | Directory is a route starter, not an inventory guarantee. Hook: walkable “four stops, one project” route. |
| [Central Oregon Auctions](https://www.centraloregonauctions.com/) | Regional, online and event-based | Estate, antique, business-liquidation, farm/ranch and consignment auctions | Buyer premiums, pickup, condition and lot size require review. Hook: decode whether an auction lot is truly economical. |
| [EstateSales.NET Bend feed](https://www.estatesales.net/OR/Bend) | Bend and regional listings | Timed sales with photo previews; furniture, decor, tools, cabinets, lamps | Residential privacy, as-is sales, crowds and lifting. Never publish an address after the sale without consent. Hook: plan a route from listing photos. |
| [Farmhouse Estate Sales](https://www.farmhouseestatesales.com/currentsales/) | Bend, Redmond and greater Central Oregon | Current sale details and photo links; furniture, decor, household, outdoor and tools | As-is, no returns, bring loading help; rules vary by sale. Hook: “preview to pickup” disciplined sourcing. |
| [Bates Estate Sales](https://bendestatesales.com/) | Bend | Organized local estate sales; furniture, antiques, tools, decor, collectibles | Join alerts; ask permission before filming private property. Hook: what professional staging teaches about visual merchandising. |
| [Nest Egg Estate Sales](https://nesteggestatesales.com/) | Oregon-wide, including Bend and Sisters | Estate sales and online auctions with broad regional reach | Shipping/pickup and auction terms vary. Hook: comparing local pickup with wider auction access. |
| [Craigslist Bend garage and moving sales](https://bend.craigslist.org/search/gms) | Bend region | Yard and moving sales, low-cost local finds, bulk lots | Scam, condition, privacy and personal-safety risk; meet safely and inspect. Hook: map a Saturday route with strict time and budget limits. |
| [Facebook Marketplace](https://www.facebook.com/marketplace/) | Location-filtered | Search alerts for cloches, shadow boxes, cabinets, display cases, stands and lots | Verify seller/profile, use safe pickup, do not send unsafe deposits, hide private details. Hook: teach the exact search-word ladder. |
| [Buy Nothing Project community finder](https://docs.buynothingproject.org/find-a-group) | Neighborhood-based | Free gifts, leftover frames, jars, cabinets, offcuts and hardware | It is a gift economy, not an advertising or buying/selling channel. Be transparent about intended use, follow local rules, and never treat gifts as extraction. Hook: community generosity transformed with full acknowledgment. |
| [Buy Nothing safety guidance](https://docs.buynothingproject.org/safety) | All participating communities | Safe-exchange practices and reporting | Participation is at one’s own risk. Hook: a short safety-first pickup checklist. |
| [Deschutes County Rethink Waste Guide](https://www.deschutescounty.gov/DocumentCenter/View/3148/Waste-Prevetion-Guide) | Central Oregon | Local reuse roadmap; notes local tools such as Porch Swing and repair options | Programs evolve; confirm current availability. Hook: build a local circular-material route from a government guide. |
| [The Environmental Center / Rethink Waste](https://envirocenter.org/programs/rethink-waste-project/what-we-offer/) | Central Oregon | Repair Cafés, reuse education, guides, community expertise | Not a shopping venue. Ask before filming participants. Hook: repair the secondhand find instead of discarding it. |
| [Repair Café](https://envirocenter.org/event/august-repair-cafe-2026/) | Rotating Central Oregon venues | Repair expertise for lamps, furniture, clothing, knives and other items | Event-specific rules; volunteers are not a free commercial production crew. Hook: “Can this damaged find be saved?” |

### 3. Pacific Northwest deep-sourcing routes

| Resource | Location / coverage | Sourcing strengths | Best content use |
|---|---|---|---|
| [SCRAP Creative Reuse Portland](https://portland.scrapcreativereuse.org/) | Portland | Donated art, craft and creative materials; online pickup inventory | Small materials, texture, labeling, offcuts, unexpected project constraints |
| [ReClaim It](https://www.reclaimitpdx.org/) | 1 N Killingsworth St, Portland | Salvaged furniture, art supplies, vintage trinkets and unusual material; transfer-station recovery | “Saved from disposal” material story; GLEAN artist-program connection |
| [The ReBuilding Center](https://www.rebuildingcenter.org/what-we-sell) | Portland; 30,000 sq. ft. store | Low-cost reclaimed home materials and architectural history | Lumber, cabinet parts, lighting, hardware, unusual project bases |
| [Reclaim NW](https://www.reclaimnw.com/) | Portland; large warehouse and yard | Reclaimed lumber, doors, lighting, hardware, architectural salvage, rare finds | Higher-intent sourcing trip for substantial bases and display structures |
| [Portland salvage retailer directory](https://www.portland.gov/bps/garbage-recycling/decon/salvage-retailers) | Portland metro and Willamette Valley | Primary municipal list including Aurora Mills, Habitat ReStore and specialist retailers | Plan a verified multi-stop regional route |
| [Portland reuse overview](https://www.portland.gov/bps/sustainability/resourcefulpdx/home-improvement/salvage-reuse) | Portland | Explains reclaimed inventory categories and circular-material rationale | Educational context for why reuse can provide character and quality |

### 4. Search-term ladder

Search by the object’s **function**, not only its usual name.

| Need | Search terms |
|---|---|
| Clear enclosure | glass dome, cloche, bell jar, display case, curio case, shadow box, specimen case, clock dome |
| Base | wood plinth, pedestal base, lamp base, trophy base, cutting board, cabinet door, shelf, riser, cake stand |
| Upright support | display stand, plate stand, easel, sign holder, mineral stand, doll stand, acrylic stand, wire stand |
| Frame | deep frame, shadow box, floating frame, vintage frame, display frame, box frame |
| Cabinet | curio cabinet, apothecary cabinet, wall cabinet, printer drawer, typesetter tray, display cabinet |
| Hardware | brass rod, threaded rod, standoff, picture hardware, cabinet pull, hinge, cleat, clamp, bracket, finial |
| Lighting | picture light, puck light, display light, gooseneck lamp, cabinet light, LED strip, museum light |
| Texture / substrate | reclaimed wood, burl, live edge offcut, drawer front, tile sample, stone remnant, metal panel |
| Bulk opportunity | craft lot, hardware lot, shop cleanout, estate lot, display fixtures, store closing, free cabinet |

### 5. Condition and safety screen

Do not use an item merely because it photographs well.

- **Stability:** Can the base carry the finished weight without tipping?
- **Material:** Is it compatible with cleaning, drilling, adhesives, fasteners, and finish?
- **Contamination:** Reject or professionally assess mold, pest activity, unknown residues, damaged batteries, leaking chemicals, and heavily soiled porous goods.
- **Older finishes:** Treat unknown painted or coated surfaces conservatively; do not sand or heat them casually. Seek qualified guidance when lead or other hazardous coatings may be present.
- **Electrical:** Unverified vintage lamps and fixtures need appropriate inspection before use.
- **Glass:** Check chips, stress cracks, edge safety, stability, and transport protection.
- **Structural integrity:** Look for rot, splitting, loose joints, and hidden fasteners.
- **Ownership:** Do not remove items from private property, construction sites, disposal areas, free piles, or curbs unless the right to take them is clear and local rules allow it.
- **Privacy:** Avoid showing home addresses, faces, license plates, messages, or seller identities without permission.
- **Transport:** Plan gloves, eye protection, padding, tie-downs, lifting help, and vehicle capacity.

## Part III — High-value content series portfolio

The following portfolio is also supplied in structured form in `bonesandhoes_content_opportunity_resources.csv`.

### A. Found, Chosen, Made

- **Audience job:** Understand a complete creative transformation rather than isolated technique clips.
- **Episode:** Discovery or lawful acquisition context → project brief → preparation → substrate/display decisions → build → reveal → cost and material ledger.
- **Basis:** Viewer questions and every maker interview can seed a project.
- **Products naturally featured:** Safety gear, cleaning/process tools, fasteners, stand, base, enclosure, finish, light, label.
- **Monetization:** Exact-use affiliate links; later difficult-to-find owned display components; paid workshop only after demand.
- **Effort / repeatability:** High / twice monthly.
- **Safeguards:** Verify acquisition rules; use safe process; disclose commercial relationships; avoid graphic imagery in discovery hooks.
- **CTA:** “Which design decision should we unpack next?”
- **Metric:** Completion rate, saves, qualified product clicks, repeat viewers.

### B. One Find, Three Directions

- **Audience job:** Escape cookie-cutter projects and see creative choice.
- **Episode:** One frame, base, cabinet or enclosure becomes three distinct concept sketches; viewers choose which is built.
- **Basis:** User preference for a broad product ecosystem and individual artistic direction.
- **Products:** Same base object plus alternate fasteners, finishes, stands and lighting.
- **Monetization:** Links to flexible component categories, not a forced bundle.
- **Effort / repeatability:** Medium / monthly.
- **Safeguards:** Clearly distinguish concept from completed/tested method.
- **CTA:** Vote, then subscribe for the build.
- **Metric:** Comment-to-view rate, returning viewers, category clicks.

### C. Treasure Routes

- **Audience job:** Find the hard-to-find supporting object locally and economically.
- **Episode:** Search brief, route, inspection, choice, adaptation and finished use.
- **Basis:** Verified Central Oregon and PNW directory above.
- **Products:** Measuring tools, gloves, transport protection, repair products, fasteners and finishes.
- **Monetization:** Exact adaptation tools/materials; curated new alternatives when local finds are unavailable.
- **Effort / repeatability:** Medium / weekly or biweekly.
- **Safeguards:** Location permission, private-address protection, pickup safety, condition screening.
- **CTA:** Submit a local source or the next object to hunt.
- **Metric:** Saves, local submissions, source referrals, project-page visits.

### D. Search Like a Set Designer

- **Audience job:** Learn better search vocabulary for Marketplace, auction and estate feeds.
- **Episode:** Start with one functional need and show the search-term ladder, filters, false positives and shortlist.
- **Basis:** The same object is often listed under decor, hardware, lighting, furniture or collectibles.
- **Products:** None required; optional measuring/transport tools appear only after selection.
- **Monetization:** Free downloadable search glossary as email entry; later linked adaptation materials.
- **Effort / repeatability:** Low / weekly short.
- **Safeguards:** Hide seller details and messages; warn about scams and deposits.
- **CTA:** Download the search glossary.
- **Metric:** Saves, glossary signups, search-term comments.

### E. Booth Anatomy

- **Audience job:** Learn why a display attracts attention and converts interest.
- **Episode:** With permission, examine hierarchy, lighting, labels, stands, packaging and price communication at one Expo booth.
- **Basis:** Expo vendors provide real-world merchandising tests.
- **Products:** Lighting, risers, label holders, transport cases, display hardware.
- **Monetization:** Exact products when known and disclosed; vendor links first.
- **Effort / repeatability:** Medium / Expo season plus market visits.
- **Safeguards:** Maker factual review; no uninvited revenue claims.
- **CTA:** Visit and follow the featured maker.
- **Metric:** Maker referrals, shares, vendor participation requests.

### F. The Tool Earned Its Place

- **Audience job:** Avoid buying tools without understanding their job.
- **Episode:** One tool, one recurring problem, one controlled demonstration, limitations, and lower-cost alternative.
- **Basis:** Vendor question “What would you replace tomorrow?”
- **Products:** The exact tool and verified alternatives.
- **Monetization:** Affiliate or direct-supplier link with clear disclosure.
- **Effort / repeatability:** Low to medium / weekly.
- **Safeguards:** Manufacturer-intended use, protective equipment, no unsupported claims.
- **CTA:** Name the next problem, not the next product.
- **Metric:** Watch-through, saves, returns/complaints, conversion per qualified view.

### G. Display Engineering

- **Audience job:** Make finished work stable, protectable and visually intentional.
- **Episode:** Diagnose one display problem—balance, attachment, enclosure, glare, lighting, labeling or transport—and test solutions.
- **Basis:** The supporting object is a major commerce opportunity and a major creative decision.
- **Products:** Rods, standoffs, wire, brackets, bases, cases, lights, labels, padding.
- **Monetization:** Broad shop categories and later hard-to-find owned components.
- **Effort / repeatability:** Medium / twice monthly.
- **Safeguards:** Load testing, sharp-edge control, glass safety, transparent failure reporting.
- **CTA:** Send dimensions and the display problem for a future case study.
- **Metric:** Saves, qualified questions, component-category conversion.

### H. What the Vendor Learned

- **Audience job:** Understand how a creative microbusiness actually works.
- **Episode:** One maker explains one pricing, merchandising, sourcing or customer lesson with context.
- **Basis:** Expo monetization question bank.
- **Products:** Usually none; maker’s shop and resources receive priority.
- **Monetization:** Network growth, future collaborations, event sponsorship with disclosure.
- **Effort / repeatability:** Low after interview capture / weekly post-Expo.
- **Safeguards:** Never infer private financial performance; label observation versus maker statement.
- **CTA:** Follow the maker and read the attributed Atlas entry.
- **Metric:** Maker referrals, shares, interview acceptance rate.

### I. Make It, Price It, Pack It

- **Audience job:** See the full operational path from artwork to safe delivery.
- **Episode:** Material and time ledger, pricing rationale, packaging test, shipping choice, and post-delivery review.
- **Basis:** Packaging and transport are often invisible costs at events and online.
- **Products:** Boxes, foam/padding, labels, scales, tape, corner protection, insurance tools.
- **Monetization:** Exact shipping supplies; digital cost worksheet.
- **Effort / repeatability:** High / quarterly case study.
- **Safeguards:** Do not expose customer details; test rather than promise carrier performance.
- **CTA:** Download the cost-and-pack worksheet.
- **Metric:** Downloads, shipping-damage rate, margin variance.

### J. Repair Before Replace

- **Audience job:** Salvage a promising secondhand base, light, frame or cabinet safely.
- **Episode:** Condition screen, repair decision, expert assistance when needed, finished use.
- **Basis:** Central Oregon Repair Cafés and local repair/reuse policy.
- **Products:** Repair consumables and safety equipment actually used.
- **Monetization:** Tools/materials; partner workshops only with permission and fair value exchange.
- **Effort / repeatability:** Medium / monthly.
- **Safeguards:** Do not present volunteer events as free commercial labor; defer electrical/hazardous work appropriately.
- **CTA:** Attend a local repair event or submit a repair question.
- **Metric:** Repair completions, waste avoided estimate with disclosed method, local referrals.

### K. Five Displays Under Fifty

- **Audience job:** Compare options by suitability, not appearance alone.
- **Episode:** Source five candidate stands, bases or enclosures under a declared total budget; score stability, adaptability, condition and visual fit.
- **Basis:** Thrift, estate and auction sources have uneven price/condition.
- **Products:** Measuring and adaptation tools.
- **Monetization:** New comparison alternatives and exact adaptation supplies.
- **Effort / repeatability:** Medium / monthly.
- **Safeguards:** State prices as time-and-place observations, not market averages.
- **CTA:** Download the scoring card.
- **Metric:** Saves, scoring-card downloads, audience predictions.

### L. The Source Ledger

- **Audience job:** Learn responsible documentation and provenance habits.
- **Episode:** Build a project record from acquisition context through materials, treatment, photographs and finished location.
- **Basis:** The Atlas requires evidence-led legal and ethical navigation.
- **Products:** Field notebook, labels, archival pen, scale, camera aids, storage.
- **Monetization:** Digital ledger template; exact documentation supplies.
- **Effort / repeatability:** Low / recurring segment in every project.
- **Safeguards:** Do not expose sensitive locations or imply legal certainty beyond verified sources.
- **CTA:** Download the blank record and check the state guide.
- **Metric:** Downloads, completed-record submissions, correction rate.

### M. Audience Project Clinic

- **Audience job:** Get help choosing a display or process direction without surrendering individuality.
- **Episode:** Review an audience-submitted challenge, constraints and three possible paths.
- **Basis:** Repeated questions become demand evidence.
- **Products:** Category options with reasons, not a mandatory package.
- **Monetization:** Linked solution categories; later paid consultation only if demand supports it.
- **Effort / repeatability:** Medium / monthly livestream or edited episode.
- **Safeguards:** Written submission permission; remove private information; clarify limits of remote advice.
- **CTA:** Submit a project brief through a structured form.
- **Metric:** Qualified submissions, live retention, solution clicks.

### N. Maker-to-Maker Chain

- **Audience job:** Discover the people and relationships behind the niche.
- **Episode:** Each guest introduces the next maker, supplier, educator or expert and explains the connection.
- **Basis:** Expo lightning network-map question.
- **Products:** Secondary; participant links are primary.
- **Monetization:** Shared-audience growth and later transparent collaborations.
- **Effort / repeatability:** Low to medium / continuous.
- **Safeguards:** Permission before introduction; do not publish private contact data.
- **CTA:** Follow both participants and nominate a missing node.
- **Metric:** Accepted introductions, cross-audience follows, collaboration starts.

### O. Price Tag to Practice

- **Audience job:** Understand why apparently similar works or supplies have different prices.
- **Episode:** Compare public, permissioned examples by labor, materials, scale, finish, display, channel fees and service—not by declaring one overpriced.
- **Basis:** Expo pricing and offer-ladder observations.
- **Products:** Cost worksheet and material categories.
- **Monetization:** Digital pricing worksheet; educational workshop after validation.
- **Effort / repeatability:** Medium / quarterly.
- **Safeguards:** No private margins, disparagement or unsupported assumptions.
- **CTA:** Use the worksheet on one of your own projects.
- **Metric:** Worksheet completion, informed comments, creator shares.

### P. One Material, Five Makers

- **Audience job:** See how individual artists make distinct decisions from a shared material or problem.
- **Episode:** Five permissioned makers discuss one substrate, stand, finish, fastener or enclosure.
- **Basis:** Expo and Networking Atlas allow multi-perspective synthesis.
- **Products:** Shared category comparison; exact products only where verified.
- **Monetization:** Category guide, supplier partnership with disclosure, maker referrals.
- **Effort / repeatability:** High / quarterly anchor feature.
- **Safeguards:** Equal attribution; avoid ranking subjective artistry.
- **CTA:** Explore every maker’s full work.
- **Metric:** Cross-profile clicks, watch time, shares, participant satisfaction.

### Q. The Failed Display File

- **Audience job:** Learn from instability, glare, weak fastening, poor proportions or transport damage.
- **Episode:** Reconstruct a consenting maker’s failed approach, identify cause, test corrections and document the result.
- **Basis:** Failure is often more useful than polished reveal footage.
- **Products:** Corrective hardware, test tools, packaging and protection.
- **Monetization:** Exact corrective products; downloadable preflight checklist.
- **Effort / repeatability:** Medium / monthly.
- **Safeguards:** Consent, no humiliation, safe recreation, no guarantee beyond tested conditions.
- **CTA:** Download the display preflight checklist.
- **Metric:** Checklist downloads, saves, reported avoided failures.

### R. Regional Material Trail

- **Audience job:** Connect local making with the region’s reuse, repair, auction and craft ecosystem.
- **Episode:** A route linking one reuse organization, one maker, one repair expert and one finished project.
- **Basis:** Central Oregon’s Rethink Waste infrastructure and the Portland reuse network.
- **Products:** Only those integral to the project.
- **Monetization:** Destination partnerships or sponsorships only after audience fit and with clear disclosure; project links.
- **Effort / repeatability:** High / seasonal.
- **Safeguards:** Permission at every location, accurate community-benefit claims, travel and lifting safety.
- **CTA:** Add a verified stop to the next regional route.
- **Metric:** Partner referrals, route saves, newsletter signups, completed collaborations.

## Part IV — Production and measurement operating system

### Content record for every episode

- Content ID and series.
- Audience job and question being answered.
- Source basis and links.
- Participant and location permissions.
- Acquisition/legal verification needed.
- Objects and exact products shown.
- Compensation, gifts, affiliate status and required disclosure.
- Claims to verify.
- Vertical, horizontal, photo, email, Atlas and shop outputs.
- CTA and primary success metric.
- Published URLs and performance after 7, 30 and 90 days.
- Follow-up relationship action.

### Metric hierarchy

Avoid optimizing only for views.

1. **Trust:** corrections, positive participant feedback, returning viewers, saves.
2. **Learning:** completion rate, repeat questions resolved, guide downloads.
3. **Network:** introductions accepted, creators featured, reciprocal referrals, collaborations started.
4. **Commerce:** qualified product clicks, conversion, returns, complaints, margin after fees.
5. **Durability:** search traffic, 90-day views, Atlas referrals, email growth.

### Editorial QA gate

Before publication, confirm:

- The person, object, artwork, location and audio may be used as planned.
- Names, links, terminology, quotes, prices and factual claims are correct.
- The content distinguishes participant statement, direct observation and BonesAndHoes interpretation.
- Legal and safety guidance uses current authoritative sources and communicates uncertainty.
- The opening promises a story, problem or insight—not a sale.
- Every product is genuinely used, relevant or clearly identified as an alternative.
- Required commercial disclosures are visible, understandable and close to the endorsement.
- Creator credit is prominent and links work.
- Private locations, personal messages, minors and customer data are protected.
- The CTA serves the audience and featured participant before it serves the shop.

## Source notes and limitations

- Local inventories, store hours, auction terms, estate-sale addresses and platform feeds change rapidly. Verify them shortly before each production day.
- A directory listing proves that a source exists; it does not prove a specific item will be available.
- Store or event filming requires direct permission even when a location is open to shoppers.
- Marketplace and neighborhood-group access may depend on an account and local membership. Follow each community’s rules.
- Safety and rights guidance here is operational risk reduction, not professional legal, electrical, structural, hazardous-material or conservation advice.
- No audience or sales performance data was available for this research pass. Frequency recommendations are test hypotheses and should be revised after 30–90 days of measured publishing.

