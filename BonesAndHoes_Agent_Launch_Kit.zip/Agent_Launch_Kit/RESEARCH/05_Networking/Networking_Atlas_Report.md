# BonesAndHoes Networking Atlas

**Research date:** August 18, 2026  
**Companion directory:** `BonesAndHoes_Networking_Atlas_2026-08-18.csv`  
**Purpose:** Turn a scattered field of makers, educators, retailers, events, institutions, suppliers, regulators, and local material sources into an actionable relationship system for Anna and Haley.

## Executive answer

BonesAndHoes should not approach this field as a cold list of influencers. The strongest network is a set of **trust chains** in which each relationship makes the next one easier and more credible:

1. Begin with approachable Oregon and Washington creators, shops, reuse centers, and educators.
2. Produce excellent permission-cleared spotlights and practical resource stories that create visible value for those partners.
3. Use those finished examples to request introductions to their suppliers, represented artists, event organizers, and institutional experts.
4. Cover the Portland and Seattle Oddities & Curiosities Expo dates as a prepared editorial team with a pre-booked interview slate—not as people wandering the floor asking improvised questions.
5. Turn each interview into a creator story, a project-material map, a shop or event link, and a next relationship.
6. Keep scientific and legal authorities separated from product promotion. Their role is accuracy and public education, not commercial endorsement.

The research produced a **61-entity working directory**. The first 25 are ranked; the remaining entries form a second-wave bench and specialist referral pool. Public contact routes are recorded, but no private details or unevidenced relationships have been invented.

## What makes this network commercially useful

The network supports four different jobs. Mixing them into one undifferentiated outreach campaign would weaken the brand.

| Network job | Best nodes | Immediate output | Long-term value |
|---|---|---|---|
| Credibility and accuracy | ODFW, Oregon State Police Fish and Wildlife, Burke Museum, University of Oregon museum, Smithsonian, professional collections groups | Cited explainers and correction paths | Trust, lower legal risk, institutional referrals |
| Audience and creator discovery | Local makers, retailer vendor rosters, community forums, national events | Interviews, spotlights, project census | Shared audiences, creator goodwill, recurring content |
| Product and merchandising intelligence | Artists, retailers, display suppliers, reuse centers | Bills of materials, product gaps, comparison guides | Affiliate revenue, authorized supplier relationships, later product development |
| Distribution and media | Expo organizers, Oddities Flea Market, Atlas Obscura, shops, newsletters | Event reports, local field guides, guest features | Earned reach, backlinks, press access, workshop opportunities |

## Network clusters

### 1. Pacific Northwest creator-and-retailer cluster

**Anchor nodes:** Oddities by Oriana, Ember and the Dead, Skeleton Key Odditorium, Paxton Gate Portland, DeathIsntTheEnd, Northwest Oddities, Honeyed Bones, BonesAndStonesPNW, Blackbird Antiques & Curiosities.

This cluster is the fastest path to credible early relationships because it combines local access, visible finished work, physical retail, and publicly evidenced connections. Skeleton Key is especially valuable: its public artist roster creates a permission-safe discovery route. The correct move is to ask the shop to **forward an opt-in invitation**, not to assume the shop can authorize use of an artist’s work.

**Recommended first output:** “The Pacific Northwest maker and display trail”—a series of short creator profiles connected by shop visits, material choices, and finished-work display decisions.

### 2. Preparation-and-workshop educator cluster

**Anchor nodes:** The Sleeping Sirens, Odd Articulations, Lee Post / The Boneman, Ryan Matthew Cohn, Amber Maykut, ScientificWoman, Gregg’s Bone Shop, Skulls Unlimited.

These nodes show how knowledge becomes a product: books, paid classes, traveling workshops, services, and premium experiences. The best interview questions concern learning progression, common beginner errors, safety, class design, capacity, and tools—not requests for free proprietary curriculum.

**Recommended first output:** a workshop-business comparison showing audience, format, duration, included materials, public price where available, student outcome, instructor authority, and what BonesAndHoes should refer out rather than teach.

### 3. Event-and-media cluster

**Anchor nodes:** Oddities & Curiosities Expo, Oddities Flea Market, World Oddities Expo, The Menagerie Oddities Market, Atlas Obscura.

Events are not merely sales venues. They are compressed research environments containing artists, retailers, instructors, collectors, display systems, price points, product questions, and possible collaborators. Media nodes can amplify original field reporting, but only after BonesAndHoes has a finished example worth sharing.

**Recommended first output:** a Portland Expo field report followed by a Seattle comparison, each with a planned interview slate and a vendor monetization matrix.

### 4. Institutional-and-legal cluster

**Anchor nodes:** Burke Museum Mammalogy, University of Oregon Museum of Natural and Cultural History, Willamette University Natural History Collection, Museum of Osteology, Smithsonian Osteology Prep Lab, ODFW, Oregon State Police Fish and Wildlife Division, U.S. Fish and Wildlife Service.

This cluster protects credibility. Requests should be narrow, educational, and source-specific. A museum or agency should never be placed beside a product call-to-action in a way that implies endorsement.

**Recommended first output:** an official-resource pathway: identification → state rules → federal overlay → documentation → collections-care references → correction/contact route.

### 5. Display-and-commerce supplier cluster

**Anchor nodes:** Art Display Essentials, Gaylord Archival, University Products, SmallCorp, Displays2Go, Strange Remains, SkullStore, Skulls Unlimited.

This cluster turns art analysis into product intelligence. It includes accessible finished display goods, professional conservation materials, custom manufacturing, specialist retail, affiliate options, reseller paths, and B2B inquiries. The early ask should be technical education or formal program terms—not an unsupported promise of large sales volume.

**Recommended first output:** “Budget, refined, and museum-grade display paths,” with exact use cases, dimensions, price checks, shipping risk, and disclosure of commercial relationships.

### 6. Pacific Northwest reuse-and-material cluster

**Anchor nodes:** ReBuilding Center, SCRAP Creative Reuse Portland, ReClaim It, Habitat ReStore Portland Region, Aurora Mills Architectural Salvage, Old Portland Hardware & Architectural, Seattle ReCreative, and the City of Portland salvage directory.

This is a distinctive content and sourcing advantage. It turns the search for bases, frames, enclosures, glass, wood, hardware, fixtures, and found decorative elements into an entertaining repeatable series. The creator’s skill is not merely finding a cheap object; it is recognizing possibility, checking safety and integrity, and transforming the object into a polished support for an individual work.

**Recommended first output:** a fixed-budget local treasure hunt followed by the finished project, an itemized material list, what was rejected and why, and links to the participating reuse organization.

### 7. Community-and-professional connector cluster

**Anchor nodes:** NatSCA, Association of Nature Center Administrators, Oregon and Northwestern taxidermy associations subject to current verification, Reddit’s r/vultureculture and r/bonecollecting, Crown of Bone’s public referral page.

These nodes are best used for referrals, question discovery, resource review, and opt-in recruitment. Community participation must begin with useful contributions and moderator approval; it must never be an extraction exercise.

## Connector nodes: where one conversation can open several doors

| Connector | Publicly evidenced connections | Why it matters | Best initial request |
|---|---|---|---|
| Skeleton Key Odditorium | Current local artist/vendor roster | One respectful shop relationship can lead to several opt-in Portland creator conversations | Forward a short creator-spotlight invitation |
| Oddities & Curiosities Expo | Vendors, classes, museum component, social channels, Portland and Seattle events | National creator discovery plus two reachable regional dates | Editorial access and pre-booked interview plan |
| Paxton Gate Portland | Regional artists, classes, retail audience, DeathIsntTheEnd placement | Joins design, retail, local creators, and education | Research interview about display and customer questions |
| Lust For Dead Oddities | Public links to Odd Articulations, Lee Post, and the Expo | A creator who already curates trusted peer resources | Interview on when to teach, refer, or sell |
| Burke Museum Mammalogy | University, collection staff, public identification, outreach | Connects identification, documentation, science, education, and local audience | Narrow expert interview or resource review |
| Atlas Obscura | Oddities Flea Market, named instructors, paid experiences, editorial reach | Can connect a strong local story to broader distribution | Pitch only after a completed original field report |
| ReClaim It | Metro salvage stream and GLEAN artists | Joins unusual materials, public art, and circular-economy storytelling | Staff and participating-artist feature |
| City of Portland salvage directory | Multiple local reuse retailers | A verified route-planning spine for the treasure-sourcing series | Use as official directory and submit corrections |
| Crown of Bone | Publicly listed preservation and memorial referrals | Demonstrates how trust is built by sending work to the right specialist | Interview about referral standards and maintenance |
| Skulls Unlimited / Museum of Osteology | Specialist service, retail, museum, education | Commercial and institutional perspectives in one visible ecosystem | Separate operations and education interviews |

## Practical relationship-chain models

### Chain A — Local creator to event collaboration

**Skeleton Key shop profile → opt-in introduction to Northwest Oddities → dome-display project interview → product/material map → Portland Expo interview → shared shop/creator/event audience**

This chain begins with a connector, delivers value to an artist, then uses the completed feature as proof when approaching the event.

### Chain B — Reclaimed substrate to product revenue

**ReBuilding Center visit → unusual base or frame discovery → Anna and Haley build video → finished reveal → verified supporting-products list → affiliate links or authorized supplier inquiry → reuse center reshare**

The secondhand object remains individual and locally sourced; repeatable revenue comes from the surrounding tools, finishes, mounting hardware, lighting, and protective display products.

### Chain C — Creator expertise to referral authority

**Lust For Dead Oddities interview → public referral to Odd Articulations and Lee Post → specialist interviews → vetted learning-resource page → Expo class guide → trusted educational audience**

The value is knowing when to send the audience to a specialist rather than pretending to own every subject.

### Chain D — Institutional credibility without commercial confusion

**ODFW source review → Oregon State Police clarification → Burke identification resource → dated legal-navigation card → separate project article → separate product list**

The legal/scientific material and the commercial material remain visibly separate. Links can coexist in the larger Atlas without implying that agencies or museums endorse a shop.

### Chain E — Event interview to creator-commerce loop

**Pre-booked Expo interview → creator’s project and business story → creator-approved media → project supply map → creator shop link → BonesAndHoes product collection → follow-up performance report to creator → next creator introduction**

After publication, BonesAndHoes should show the creator what traffic and engagement the feature delivered. That evidence makes the next introduction easier.

### Chain F — Professional display supplier to later owned product

**Art Display Essentials technical interview → audience comparison guide → repeated requests for missing sizes/styles → supplier quote or SmallCorp manufacturing conversation → prototype only after validated demand → creator testing → formal launch**

Product development follows measured unmet demand, not intuition alone.

## First-25 outreach queue

The order balances accessibility, strategic leverage, geographic relevance, and the need to build proof before approaching high-profile nodes.

| Rank | Target | First concrete ask | Intended proof or output |
|---:|---|---|---|
| 1 | Oddities by Oriana | 20-minute interview about education, drops, and Oregon field-to-art work | Flagship local creator story |
| 2 | Ember and the Dead | Tacoma shop profile and display/customer-question interview | Regional retail case study |
| 3 | Skeleton Key Odditorium | Shop profile plus permission to forward an opt-in invitation to selected vendors | Portland creator gateway |
| 4 | Oddities & Curiosities Expo | Portland/Seattle editorial access proposal with release workflow | Event reporting permission |
| 5 | The Sleeping Sirens | Instructor-business interview | Workshop productization case |
| 6 | Paxton Gate Portland | Retail-trend and display-design interview | Premium local retail benchmark |
| 7 | Burke Museum Mammalogy | Narrow education interview or official resource review | Scientific/identification authority |
| 8 | University of Oregon museum | Collections/public-education interview | Oregon institutional context |
| 9 | ReBuilding Center | Filmed treasure-sourcing visit | First reclaimed-material episode |
| 10 | SCRAP Creative Reuse Portland | Fixed-budget material challenge | Repeatable low-cost content format |
| 11 | ReClaim It | Staff and GLEAN artist feature | Circular-economy story and artist introductions |
| 12 | Ryan Matthew Cohn | Focused interview on curation and workshop economics | National authority case study |
| 13 | Atlas Obscura | Pitch the completed PNW story package | Earned distribution test |
| 14 | ODFW | Written answers to a concise set of Oregon rule questions | Primary-source legal card |
| 15 | Oregon State Police Fish and Wildlife | Common-misconceptions and reporting-resource Q&A | Enforcement reality check |
| 16 | Odd Articulations | Process, memorial-service, and referral interview | Specialist referral feature |
| 17 | Lust For Dead Oddities | Creator-as-curator interview | Peer-resource network story |
| 18 | Showtime Taxidermy | Distinctive-concept-to-full-time-business interview | Monetization pattern case |
| 19 | DeathIsntTheEnd | Local retail-placement interview | Online-to-stockist pathway |
| 20 | Northwest Oddities | Dome/display project interview via opt-in shop introduction | Display materials and creator spotlight |
| 21 | Honeyed Bones | Creator interview via opt-in shop introduction | Local category and buyer-question insight |
| 22 | Bone Boutique | Collection taxonomy and event interview | Merchandising by story/species theme |
| 23 | Osteal Blossoms | Event route and booth-design interview | Touring vendor operations case |
| 24 | Crown of Bone | Referral-vetting interview | Public service directory model |
| 25 | Oddities Flea Market | Curator/access request using completed local work as proof | Premium event/media expansion |

### Sequencing rule

Do not send all 25 messages at once. Work in five waves of five. Each wave should produce at least one completed public asset before the next begins. Record replies and revise the next message based on what people actually value.

## Highest-value interview candidates

### Creator-business interviews

- **Oddities by Oriana:** digital guide, product drops, markets, and Oregon identity.
- **Showtime Taxidermy:** recognizable creative concept, online enthusiasm, capacity, and full-time transition.
- **DeathIsntTheEnd:** Etsy/direct selling plus Portland-area retail placement.
- **Osteal Blossoms:** event-route planning and booth presence.
- **Bone and Bauble:** early commissions and boutique partnership.
- **Bone Boutique:** collection taxonomy, conservation framing, and events.

### Workshop and education interviews

- **The Sleeping Sirens:** traveling class format and repeatability.
- **Odd Articulations:** specialized services, client privacy, education, and referrals.
- **Lee Post:** learning progression and reference publishing.
- **Ryan Matthew Cohn:** premium workshop design and event curation.
- **Amber Maykut and ScientificWoman:** specialist workshops and urban experience partnerships.

### Retail, display, and sourcing interviews

- **Paxton Gate Portland:** customer questions, class demand, and premium presentation.
- **Skeleton Key Odditorium:** local creator discovery and retail curation.
- **Ember and the Dead:** storefront economics, gallery presentation, and local demand.
- **Art Display Essentials:** stands, mounts, bases, and custom fabrication.
- **SmallCorp:** manufacturing feasibility once demand dimensions are documented.
- **ReBuilding Center / SCRAP / ReClaim It:** how experienced makers recognize useful secondhand materials.

### Institutional and legal interviews

- **Burke Museum Mammalogy:** identification, documentation, collection care, and common public misconceptions.
- **University of Oregon Museum of Natural and Cultural History:** Oregon collections and responsible public interpretation.
- **ODFW and Oregon State Police Fish and Wildlife:** dated primary guidance and enforcement-aware public education.
- **Museum of Osteology / Smithsonian Osteology Prep Lab:** institutional preparation and exhibit interpretation, clearly distinguished from home practice.

## Interview format for the Expo

Book interviews in advance wherever possible. Use a three-level format:

1. **Two-minute floor interview:** one distinctive work, one unusual support or display choice, one place to find the creator.
2. **Ten-minute business interview:** customer, product mix, price architecture, shows, online channels, classes, commissions, recurring questions, and current constraint.
3. **Twenty-minute deep interview by appointment:** origin story, sourcing/provenance language, project process, materials, display engineering, content strategy, monetization mix, and ideal collaborations.

Every interview record should capture:

- creator’s exact preferred name and credit line;
- preferred public link and current offer;
- written permission scope for video, stills, quotes, edits, and future reuse;
- work photographed and displayed public price, if any;
- products, tools, substrates, mounts, enclosures, and finishes visible or named;
- whether BonesAndHoes may publish a supply map;
- public contact route and opt-in for future collaboration;
- required disclosures and any restrictions;
- follow-up date and promised deliverables.

## Outreach message architecture

Each first message should be brief and specific:

1. One sentence showing genuine knowledge of the target’s current work.
2. One sentence explaining the exact story or resource being produced.
3. One narrow request with a time estimate.
4. The concrete value the target receives: preferred links, credit, approved quotes, useful clips, or audience referrals.
5. A statement that participation is optional and that no images will be reused without written permission.

Avoid generic “collaboration” messages. Never lead with a request for free products, free instruction, a warm introduction, confidential numbers, or endorsement.

## Lightweight CRM schema

The CSV is an intelligence directory, not yet a full interaction log. Add a second table with one row per relationship and these fields:

| Field | Use |
|---|---|
| `relationship_id` | Stable internal key |
| `entity_name` | Exact public name |
| `cluster` | Creator, retailer, event, institution, supplier, media, legal, community, reuse |
| `owner` | Anna, Haley, or assigned person |
| `priority` | Tier 1, 2, or 3 |
| `source_url` | Page proving relevance |
| `preferred_contact_channel` | Public email, form, shop visit, platform message, modmail |
| `public_intermediary` | Only a documented connection; never an invented relationship |
| `specific_ask` | One request for the current outreach wave |
| `value_offer` | Concrete benefit for the recipient |
| `status` | Workflow state below |
| `first_contact_date` | Date sent |
| `last_contact_date` | Most recent interaction |
| `next_action_date` | Single next follow-up date |
| `response_summary` | Factual notes, not interpretation of tone |
| `permission_scope` | Images, video, quotes, links, edits, duration, platforms |
| `preferred_credit` | Exact credit line and tags |
| `asset_due` | What BonesAndHoes promised |
| `publication_url` | Final live link |
| `results_shared` | Date performance summary was returned to partner |
| `referral_or_next_node` | Opt-in next introduction or discovered relationship |
| `risk_flag` | Legal, sourcing, rights, safety, platform, reputational |
| `confidence` | High, medium, or low |
| `notes` | Short factual notes only |

### CRM status workflow

`Researching → Qualified → Drafting outreach → Contacted → Replied → Discovery scheduled → Permission pending → Confirmed → In production → Awaiting approval → Published → Results shared → Relationship active`

Alternative end states:

- `Declined — do not pursue`
- `No reply — pause`
- `Not a fit`
- `Needs reverification`
- `Rights expired or revoked`

### Follow-up discipline

- One polite follow-up after 7–10 business days.
- A second and final follow-up only when there is a real new reason, such as a completed related story or confirmed event date.
- No response after that becomes `No reply — pause`, not an invitation to chase across private channels.
- Send every participant the finished link and a concise performance/result note.
- Ask for introductions only after delivering the promised value.

## Permission and attribution controls

Public visibility is not publication permission. For each creator or business:

- Save public URLs for internal research; do not download media into a public asset folder without permission.
- Obtain written permission that names the media, platforms, edit rights, duration, and revocation route.
- Record the exact preferred creator/shop credit and target link.
- Let the participant review factual quotes and sensitive sourcing language; do not give blanket editorial control over independent analysis.
- Use platform-native sharing where appropriate, but still respect the creator’s stated preference.
- A shop’s permission does not grant rights to an artist’s work.
- An event’s filming permission does not grant rights to every vendor or attendee.
- Attribution is required but does not substitute for permission.
- Commercial links and gifts require clear disclosure.

## Risk controls by cluster

### Creators and retailers

- Treat provenance and sourcing descriptions as creator statements until independently verified.
- Do not imply that one retailer’s inventory establishes broad legality.
- Do not copy signature project concepts as product-development shortcuts.
- Verify current shop, price, event, and availability information before publication.

### Institutions and agencies

- Ask narrow factual questions.
- Cite current official pages and access dates.
- Distinguish education from legal advice.
- Never imply museum or agency endorsement of a commercial offer.

### Suppliers

- Separate technical interviews from commercial applications.
- Obtain current program terms in writing.
- Test product suitability and shipping risk.
- Disclose paid, gifted, affiliate, or reseller relationships.

### Reuse centers and secondhand sources

- Obtain filming approval and protect customer privacy.
- Check structural integrity, contaminants, sharp edges, coatings, and cleaning requirements.
- Treat changing inventory as the appeal of the series, not as a dependable stock promise.

### Online communities

- Use moderator-approved participation and recruitment.
- Do not scrape member data or media.
- Treat community claims as discovery signals, not verified facts.
- Return value through sourced resources and corrections.

## 30-day activation plan

### Week 1 — Prepare

- Create the CRM relationship table.
- Finalize permission, interview-release, creator-credit, and disclosure templates.
- Select five first-wave targets: Oddities by Oriana, Ember and the Dead, Skeleton Key, ReBuilding Center, and SCRAP Portland.
- Draft one target-specific message for each.
- Build the Expo interview intake form before requesting access.

### Week 2 — Start local

- Send the five first-wave requests.
- Visit one reuse center only after permission is clear.
- Produce the first treasure-sourcing-to-finished-project story.
- Record every material considered, selected, or rejected.

### Week 3 — Publish proof

- Publish one creator/shop profile and one reuse project.
- Send finished links to participants.
- Record results and corrections.
- Ask whether each participant knows one other person who would genuinely benefit from a similar feature; accept introductions only when opt-in.

### Week 4 — Expand with evidence

- Approach The Sleeping Sirens, Paxton Gate, Burke Museum, University of Oregon museum, and the Expo using the completed local work as proof.
- Prepare a tentative Portland Expo interview roster with backups.
- Apply to relevant supplier/affiliate programs only after at least one high-quality display or material guide exists.

## Success measures

Count relationship quality and delivered value, not just contact volume:

- positive reply rate by cluster;
- interviews booked and completed;
- written permissions obtained;
- promised assets delivered on time;
- creator/shop/event clicks delivered;
- reshares by featured partners;
- opt-in referrals received;
- corrections requested and resolved;
- product questions and unavailable-size requests captured;
- partner relationships active after 90 days;
- percentage of outreach ending in a public, useful artifact.

## Source and confidence notes

The directory prioritizes first-party pages and official institutional sources. High confidence means the entity’s role and contact route were visible on a current first-party or official page. Medium confidence usually means the role is strong but a direct account, current offer, or relationship needs verification. Low confidence marks directory or community references that must be rechecked before outreach.

Key sources include:

- Oddities by Oriana: https://odditiesbyoriana.com/
- Ember and the Dead: https://emberandthedead.com/
- Skeleton Key vendor roster: https://www.skeletonkeyodditorium.com/skeleton-key-shop
- Oddities & Curiosities Expo: https://odditiesandcuriositiesexpo.com/
- Paxton Gate: https://paxtongate.com/pages/faqs
- Burke Museum Mammalogy: https://www.burkemuseum.org/collections-and-research/biology/mammalogy
- University of Oregon collections: https://natural-history.uoregon.edu/collections
- ODFW permits and public guidance: https://www.dfw.state.or.us/wildlife/license_permits_apps/
- Oregon State Police Fish and Wildlife resources: https://www.oregon.gov/osp/programs/fw/pages/externalresources.aspx
- U.S. Fish and Wildlife Service sales overview: https://www.fws.gov/sites/default/files/documents/news-attached-files/factsheet-can-i-sell-it.pdf
- ReBuilding Center: https://www.rebuildingcenter.org/what-we-do
- SCRAP Portland: https://portland.scrapcreativereuse.org/
- ReClaim It: https://www.reclaimitpdx.org/
- City of Portland salvage directory: https://www.portland.gov/bps/garbage-recycling/decon/salvage-retailers
- Seattle ReCreative: https://www.seattlerecreative.org/shop
- Atlas Obscura experiences: https://www.atlasobscura.com/experiences
- Smithsonian Osteology Prep Lab: https://naturalhistory.si.edu/research/msc-opl
- Art Display Essentials: https://www.artdisplay.com/
- Gaylord exhibit and display: https://www.gaylord.com/c/Exhibit-and-Display
- University Products exhibit and display: https://www.universityproducts.com/exhibit-display/
- SmallCorp: https://www.smallcorp.com/
- NatSCA: https://www.natsca.org/

## Completion and remaining verification

The networking architecture, ranked queue, relationship chains, interview slate, permission controls, and 61-entity directory are ready for integration. Before anyone sends outreach, the owner should verify:

1. Anna and Haley’s preferred public-facing titles and business contact address.
2. Which existing relationships, if any, already exist; none were assumed here.
3. Which Portland and Seattle Expo dates they plan to attend.
4. Whether they are comfortable conducting on-camera interviews.
5. The exact value they can reliably deliver to the first five partners.
6. Current activity and direct channels for all medium- and low-confidence entities.

This is a working relationship atlas, not a list of guaranteed partners. Its value depends on delivering excellent work before asking the network for more.
