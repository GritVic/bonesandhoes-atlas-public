# BonesAndHoes Commerce, Product, and Merchandising Playbook

## Commercial architecture

The channels are not substitutes for one another. Each has a specific job.

| Channel | Primary job | When to begin | What belongs there | Critical gate |
|---|---|---|---|---|
| Payhip | Free guide, email capture, paid digital tools | Immediately | Guides, records, planners, worksheets | Accurate product scope and update policy |
| Amazon Associates and approved brand programs | Broad no-inventory recommendations | Early | Tools and supplies actually used | Disclosure, program approval, product relevance |
| TikTok Shop Creator Affiliate | Native discovery commerce | At eligibility | Selected marketplace products used naturally in content | Current eligibility and account compliance |
| Etsy | Marketplace discovery for qualifying offers | Weeks 4–8 | Original digital tools, original work, qualifying supplies | Each listing passes current creativity and policy rules |
| Square Online Free | Low-cost owned checkout | After initial demand | Digital and authorized physical offers | Product, policy, and fulfillment readiness |
| Shopify and Collective | Owned hub with supplier-direct catalog and synchronization | When its operating value exceeds cost | Authorized supplier products and later owned products | Approved suppliers, margins, returns, synchronization need |
| Pinterest and Google free listings | Evergreen discovery | After owned catalog exists | Visual project supplies and guides | Complete feed, accurate price, shipping and return policies |
| Meta Shops | Social discovery to owned checkout | After stable catalog | Tagged products and collections | Domain, catalog, and commerce eligibility |
| YouTube Shopping | Long-form project commerce | At eligibility | Exact supply lists tied to full projects | Channel and store eligibility |
| TikTok Shop Seller | Native direct sales | Later | Proven products with compliant fulfillment | Inventory ownership and full operational proof |
| eBay | Search-led specialty or vintage items | Selectively later | Standardized hardware, stands, unusual tools | Category economics and reliable sourcing |
| Amazon Handmade | High-reach handcrafted marketplace | Selectively later | Qualifying high-margin repeatable work | Maker approval and fee absorption |
| Faire | Wholesale distribution | After owned wholesale-ready products exist | Difficult-to-find owned products | Wholesale pricing, lead times, case packs, retailer support |

## Recommended sequence

1. Publish a free guide and one paid digital tool on Payhip.
2. Apply for relevant affiliate programs.
3. Build content-linked product collections and measure qualified clicks.
4. Enter TikTok creator affiliate commerce when the account qualifies.
5. Open Etsy narrowly for offers that clearly fit current rules.
6. Add an owned checkout only after there is something proven to transact.
7. Choose Shopify when supplier-direct catalog operations or multichannel synchronization justify the recurring cost; otherwise use the lower-cost bridge.
8. Add discovery feeds after the owned catalog, policies, and product data are stable.
9. Add marketplace selling and inventory only after product and fulfillment proof.

## TikTok operating choice

### Creator affiliate first

Current research found that a United States affiliate creator must generally be at least 18, US-based, compliant, identity-verified, and have at least 1,000 followers. Smaller eligible creators may enter a pilot with posting and product limits. The live account interface and current first-party policy control at launch.

Use this route to:

- test products with no inventory;
- show real use inside the project;
- learn which product, price, seller, and content format convert;
- earn commission while the merchant handles fulfillment and returns.

Record the displayed commission, price competitiveness, seller performance, shipping promise, return risk, project relevance, and disclosure for every item selected.

### Seller only after proof

Do not treat TikTok Seller as a casual forwarding system. Current policy permits third-party fulfillment when the seller owns the inventory and prohibits buying from another online retailer and directing that retailer to fulfill the customer order.

Every seller SKU must have:

- a named supplier;
- written authorization;
- known inventory ownership;
- a verified United States ship-from and return path;
- handling and tracking standards;
- returns and customer-service ownership;
- all required product instructions, warnings, and documents;
- positive base-case contribution after referral fee, creator commission, shipping, returns, and reserves.

## Etsy operating choice

Use Etsy as a focused marketplace, not the entire business.

Good candidates:

- original digital planning and documentation resources;
- original artwork and seller-made work that passes legal and platform review;
- original designs fulfilled by a properly disclosed production partner;
- qualifying supplies where the exact current rules allow them.

Poor candidates:

- ordinary mass-market goods resold without qualifying creative input;
- undesigned ready-made goods sent by a production partner;
- any offer with uncertain origin, transfer, sale, or policy status;
- attempts to redirect an Etsy-initiated transaction away from Etsy.

Launch with 6–12 clear listings. Each digital listing should show useful previews, exact contents, version date, limitations, and update policy. Reserve approximately 10%–15% of revenue plus the listing fee for platform and payment costs until live-account fees are confirmed.

## Owned checkout decision

### Use Square Free when

- the first need is an owned checkout with no monthly platform cost;
- the catalog is still small and manually manageable;
- supplier-direct synchronization is not yet central;
- the team is testing whether buyers will transact off marketplace.

Verify the current processing rate in the live account because public plan pages have changed.

### Use Shopify when

- at least 20 relevant supplier-direct products are approved with modeled contribution above 20%;
- Shopify Collective provides real supplier access;
- social and marketplace catalog synchronization saves meaningful operating time;
- monthly gross profit attributable to the platform exceeds three times its monthly cost;
- customer retention and owned data justify the move.

Do not pay for a platform merely to appear established.

## Authorized supplier-direct model

The customer may buy through a BonesAndHoes storefront while an authorized supplier fulfills, but only under a real commercial agreement. Required terms include:

- wholesale or retailer price;
- inventory feed and stock accuracy;
- handling time and carrier performance;
- packaging and brand presentation;
- return, damage, warranty, and replacement ownership;
- product safety information and liability allocation;
- permission to use product images and claims;
- customer-service escalation;
- data and termination terms.

Do not advertise one bundled box assembled across unrelated public retailers. Present a curated project list with separate products, or create a single bundle only when one accountable operation can pack, ship, and support it.

## Merchandising system

### Shop by project outcome

- glass-dome and cloche displays;
- shadow-box and framed work;
- tabletop stands;
- wall displays;
- jewelry and wearable work;
- botanical, mineral, and mixed-media compositions;
- carved, painted, and finished art;
- photography and listing setup;
- studio storage and labeling;
- fragile packing and shipping.

### Shop by workflow stage

- document and handle;
- prepare safely;
- drill, shape, and finish;
- build and attach;
- display and protect;
- photograph and publish;
- store and ship.

### Product-card requirements

Every recommended or sold product should show:

- the exact job it performs;
- compatible project formats and relevant measurements;
- why it was selected;
- current price and verification date;
- merchant and fulfillment source;
- shipping and return notes;
- commercial relationship status;
- safety or policy flags;
- lower-cost and premium alternatives when useful;
- confidence and testing status.

## Current product opportunities

### Immediate no-inventory collections

1. Complete project supply lists.
2. Preparation and safety storefront.
3. Display-builder storefront.
4. Photography and listing collection.
5. Packing and shipping guide with supplies.
6. Provenance-card and label templates plus relevant paper, labels, and storage.
7. Treasure-sourcing adaptation tools: measuring, transport protection, repair, fasteners, and finishes.

### Supplier relationships to investigate after demand

- adjustable mount and stand manufacturers;
- glass, acrylic, and custom enclosure manufacturers;
- archival and museum-display suppliers;
- label and documentation suppliers;
- tool and craft retailers with creator programs;
- packaging suppliers;
- regional and national wholesalers offering written direct-fulfillment terms.

### Later owned-product hypotheses

1. Discreet modular tabletop stand with neutral finishes, multiple heights, cushioned contact points, replaceable adapters, and a published size guide.
2. Reversible base-and-enclosure system with configurable rod positions and label slot.
3. Small-scale rod-and-clamp system that looks intentional in finished art.
4. Removable shadow-box mounting insert supporting multiple attachment approaches.
5. Provenance and care system with cards, QR labels, archival sleeves, and digital record.
6. Fragile-art packing system with size-matched components and photo-based pack-out checklist.

## Product evidence from the current market

Current marketplace observations show:

- mini displays around $12.50;
- many framed and domed pieces around $40–$185;
- more complex framed work above $300;
- artist-oriented stands commonly around $38–$99;
- accessible shadow boxes near $12–$30;
- acrylic enclosures from roughly $16 upward depending on size;
- premium glass domes and cases above the entry price tier;
- hundreds of marketplace search results using established terms for shadow boxes and display stands.

These observations prove vocabulary and active offer categories, not sales volume. Use them for price ladders, project taxonomy, and research hypotheses. Do not present them as market size or confirmed sell-through.

## Unit-economics guardrails

### Affiliate model per 10,000 qualified views

Illustrative scenarios from the current research:

| Scenario | Click rate | Merchant conversion | Average order | Commission | Estimated creator revenue |
|---|---:|---:|---:|---:|---:|
| Conservative | 1% | 1% | $35 | 3% | $1.05 |
| Base | 2% | 2.5% | $55 | 8% | $22 |
| Upside | 4% | 4% | $85 | 15% | $204 |

These are planning scenarios, not forecasts. Affiliate value also includes demand information and avoided fulfillment risk.

### Supplier-direct order

At a $65 average order, the current base planning case allocates 55% to supplier cost, 6% to platform/payment, 10% to creator commission, 5% to shipping subsidy, and 4% to returns/damage. That leaves 20%, or $13, before owner labor, tax, and overhead.

Reject or renegotiate products below 15% base-case contribution before owner labor. Target at least 20% for standardized products and 30% or more for owned difficult-to-find products.

### Digital product

A $12 digital guide on a no-monthly-cost platform can retain roughly $10.75 before owner labor and tax under the documented payment assumption. Digital tools are therefore useful early tests, but they still require accuracy, useful design, clear scope, and a maintenance plan.

## Product-development evidence gate

Advance a later product only when all are true:

1. At least 90 days of behavior identifies a recurring need.
2. At least 20 relevant interviews confirm the problem and acceptable price.
3. Three supplier quotes include samples, minimums, tooling, freight, lead time, and replacement terms.
4. The prototype passes appropriate stability, load, vibration, packing, and drop tests.
5. Landed cost supports the intended channel.
6. Product positioning and compatibility do not depend on unlawful possession or commerce.
7. Marketplace and advertising claims pass review.

## Research gaps that remain operational work

- Current Anna and Haley audience analytics.
- Live eligibility inside each account.
- Final approval and rate inside affiliate networks.
- Private wholesale costs and fulfillment terms.
- Product-level conversion and return behavior.
- The best first five project formats.
- Customer preference between glass and acrylic by project and price tier.
- Missing sizes, hardware aesthetics, and compatibility problems revealed by interviews.

These are not reasons to delay the first content and affiliate tests. They are the measurements those tests are designed to produce.
