# BonesAndHoes Invisible Lines and Growth Intelligence

**Research date:** August 18, 2026  
**Readers:** Anna and Haley  
**Purpose:** Draw the commercially meaningful connections across the strategy, product, content, Expo, networking, legal, and channel evidence; identify what changes the launch plan; and define the next tests.

## Executive answer

The strongest opportunity is larger than a content channel with product links. BonesAndHoes can build a structured **project-intelligence system** that connects:

- a finished creative outcome;
- the decisions and problems encountered;
- dimensions, compatibility, and display requirements;
- the products and suppliers that solved each problem;
- the creator or vendor who demonstrated the solution;
- the content in which it appeared;
- audience questions, clicks, purchases, and failures;
- provenance, care, and verification records.

That system is the invisible asset underneath the Atlas, content library, shop, creator network, Expo research, and later owned products. Competitors can copy an individual product list. They cannot easily copy a growing record of what works, for whom, at what dimensions, in which project, with what evidence.

The immediate strategic consequence is important: **build the data model before building a large store.** Every project, creator feature, product test, and Expo interview should feed the same ledger.

## The ten highest-value invisible lines

### 1. The real moat is compatibility data, not inventory

Across the product research, the recurring market friction is not simply that stands, enclosures, bases, frames, rods, fasteners, labels, and packing products are unavailable. The problem is that buyers cannot easily determine which combination works for a particular project.

Most listings describe the item. BonesAndHoes can describe the relationship between the item and the job:

- internal versus external dimensions;
- base thickness and usable clearance;
- rod diameter, height, and interface;
- load and stability requirements;
- reversible versus permanent attachment;
- glass versus acrylic tradeoffs;
- compatible substrate and display formats;
- packing and replacement risk.

This creates a product-information advantage before it creates a product-manufacturing advantage.

**Action:** add compatibility fields to the product ledger now. Do not wait for the owned store.

### 2. Every unique secondhand find can produce repeatable commerce

Treasure Routes appears, at first, to create a sourcing problem because the hero object may be unique and impossible to stock. The cross-source evidence shows the opposite.

The unique object attracts attention. The repeatable revenue sits around it:

- measuring and transport tools;
- repair supplies;
- fasteners, rods, wire, and mounting systems;
- finishes and surface preparation;
- lighting and enclosures;
- photography and labels;
- storage and packing.

One found cabinet, base, frame, or dome should therefore become an **adaptation pattern**, not a one-off shopping recommendation. The content teaches viewers how to evaluate any similar object, then offers the standard supporting products required to make it work.

**Action:** every Treasure Route episode ends with “what was unique” and “what is repeatable.”

### 3. The creator network can become a distributed research and sales network

The networking plan currently creates content, credibility, and introductions. Current platform tools show a second layer: trusted creators can later become compensated distribution partners for products that emerge from the network.

Shopify Collabs supports invite-only creator programs, tracked affiliate links or codes, collection-level commissions, and automated commission payments. TikTok Shop supports targeted creator collaborations for selected products. YouTube Shopping allows eligible creators to tag other brands' products and report shopping performance. These are later mechanisms, not launch requirements. They show that creator relationships can evolve from feature → project intelligence → product testing → transparent revenue sharing.

**Action:** record creator product expertise, audience fit, and collaboration interest in the CRM now, but do not make a commercial offer until a real product and fair terms exist.

Sources: [Shopify Collabs programs](https://help.shopify.com/en/manual/promoting-marketing/collabs/merchants/collabs-programs), [Shopify creator payments](https://help.shopify.com/en/manual/promoting-marketing/collabs/merchants/payments), [TikTok target collaborations](https://seller-us.tiktok.com/university/essay?from=feature_guide&identity=1&knowledge_id=6837873164896001&role=1&shop_region=US), [YouTube Shopping](https://support.google.com/youtube/answer/12257682).

### 4. Etsy has two different strategic roles

The existing plan correctly treats Etsy as a narrow seller channel for qualifying original digital, artistic, and supply offers. Current Etsy guidance reveals another no-inventory role: the Etsy Affiliates Program and Creator Collective allow qualifying publishers and social creators to earn commission for curating Etsy products. Creator Collective currently states a 500-follower minimum on an authorized channel and gives creators a curated Etsy Storefront.

This is highly relevant because many distinctive frames, domes, stands, supports, and handmade accessories are already sold by independent Etsy makers. BonesAndHoes could curate them without pretending to manufacture or fulfill them.

**Action:** add “Etsy seller” and “Etsy curator/affiliate” as separate rows in the channel plan. Verify Anna and Haley's account eligibility and current program terms before applying.

Source: [Etsy Affiliates Program and Creator Collective](https://help.etsy.com/hc/en-us/articles/360000335987-The-Etsy-Affiliates-Program-and-Creator-Collective).

### 5. The first valuable customer may be another creator, not a beginner

Beginners generate audience growth, questions, and early digital-tool demand. Working creators and vendors may generate higher repeated commercial value because they continually need:

- display and booth infrastructure;
- photography and listing tools;
- labels, provenance records, and price cards;
- packing and shipping supplies;
- sourcing and comparison tools;
- event research;
- creator exposure and referrals.

The Expo and networking evidence repeatedly points to these needs. This means BonesAndHoes has two linked markets:

1. an enthusiast and maker audience learning to complete projects;
2. a creator-operator audience trying to present, price, transport, and sell finished work.

**Action:** tag every offer and content unit as enthusiast-facing, creator-operator-facing, or both. Test one creator-operator digital product in the first 60 days.

### 6. Expo interviews are product-development interviews in disguise

The Expo plan already captures stories, price ladders, booth design, and monetization. The missing connection is a consistent **problem count**.

Every interview should ask:

- What display component is hardest to find?
- Which size or format is repeatedly missing?
- What breaks in transit?
- What takes too long to assemble?
- What do customers misunderstand?
- What would the vendor buy repeatedly if it existed?

When the same problem appears across unrelated creators, it becomes stronger product evidence than marketplace listing counts. The Expo can compress months of scattered interviews into one field cycle.

**Action:** add a normalized problem code, requested specification, current workaround, acceptable price, and referral source to every Expo interview record.

### 7. Provenance, care, and packing form one trust product family

The product, legal, content, and creator research independently mention documentation, labels, care, storage, and shipping. Together they form a coherent product family:

- project source and treatment record;
- provenance and artist card;
- care instructions;
- QR-linked digital record;
- photography record before shipment;
- pack-out checklist;
- condition record at receipt.

This family has several advantages: it supports collectors and creators, carries relatively low inventory risk, reinforces trust, works as digital plus physical products, and does not depend on selling regulated material.

**Action:** treat provenance/care/packing as a unified early product lane, not three minor appendices.

### 8. Failure content is a research instrument

“The Failed Display File” and similar troubleshooting content can do more than build authenticity. A structured failure record reveals:

- compatibility gaps;
- weak instructions;
- recurring breakage;
- unsuitable adhesives or attachment methods;
- hidden shipping costs;
- missing product sizes;
- where customers abandon a project.

This is exactly the evidence required for better comparison guides, supplier negotiations, and later product development.

**Action:** add a failure log linked to the project and product ledgers. Count failures and workarounds, not only successful recommendations.

### 9. One structured catalog can power several discovery channels

The product ledger proposed in the existing research is not merely an internal spreadsheet. Current platform documentation shows that accurate structured product data can be reused across multiple discovery surfaces.

Google Merchant Center free listings can surface eligible products across Search, Images, Lens, YouTube, Maps, Gemini, and the Shopping tab. Pinterest catalogs create product Pins from a data source. Shopify category metafields are designed to make products more discoverable on stores, marketplaces, and search engines. YouTube Shopping can connect store products or tag products from participating brands.

Therefore, detailed product fields are not administrative overhead. They are distribution infrastructure.

**Action:** design the product ledger so its core fields can later populate a store and catalog feed: ID, title, description, image, price, availability, condition, brand, identifier, dimensions, compatibility, shipping, return status, and verification date.

Sources: [Google free listings](https://support.google.com/merchants/answer/13889434), [Google structured product data](https://support.google.com/merchants/answer/6069143), [Pinterest catalogs](https://help.pinterest.com/en/business/article/before-you-get-started-with-catalogs), [Shopify category metafields](https://help.shopify.com/en/manual/custom-data/metafields/category-metafields).

### 10. The Atlas can become a living operating system, not a one-time book

The Atlas is the first polished expression of the system, but its underlying records will continue changing: product prices, platform rules, vendor schedules, legal guidance, supplier terms, and tested project paths.

The public-facing book should remain clean and stable. Its companion resources can carry dates, updates, and live links. Later, after a sustainable publishing cadence exists, recurring value could support a membership or update service built around project clinics, sourcing alerts, new creator routes, product comparisons, and updated tools. Payhip currently supports recurring membership products and bundles.

This is not a launch recommendation. A membership without a proven cadence becomes an obligation. It becomes viable only after Anna and Haley demonstrate that they can publish recurring value without harming the core work.

Source: [Payhip membership products and bundles](https://help.payhip.com/article/321-create-a-membership-site-on-payhip).

## What changes in the launch strategy

The current strategy remains sound, but five changes should be incorporated.

### Change 1: create one shared project-intelligence schema

Before publishing the first project, create linked records for:

- project;
- creator/vendor;
- content unit;
- product;
- supplier;
- compatibility;
- failure/workaround;
- audience question;
- link and conversion event;
- provenance/care record;
- relationship and permission.

The system can begin in a spreadsheet. The important part is consistent IDs and fields.

### Change 2: separate Etsy's seller and curator roles

- Seller role: qualifying BonesAndHoes digital tools, original work, and permitted supplies.
- Curator role: eligible affiliate links and a curated Storefront pointing to independent Etsy makers.

These roles have different eligibility, rules, economics, and customer ownership.

### Change 3: add a creator-operator offer in the first 60 days

Recommended test: **Make It, Price It, Pack It Workbook** combining project costing, booth/display planning, provenance, photography, packing, and post-event review.

This tests whether the network is also a paying professional audience.

### Change 4: make Expo problem counting mandatory

Stories remain the visible output. Standardized problem records become the hidden product-development output.

### Change 5: elevate provenance/care/packing into an early collection

Launch it as:

- a free provenance starter record;
- a paid creator documentation and pack-out workbook;
- a recommendation collection for labels, sleeves, photography, storage, and packing;
- a later physical system only after demand is measured.

## Ranked opportunities after cross-source synthesis

| Rank | Opportunity | Why it rises | Investment | Earliest test |
|---:|---|---|---:|---|
| 1 | Project-to-supply pages with compatibility fields | Core content, affiliate layer, search asset, and future store data | Very low | First project |
| 2 | Etsy curation/affiliate role | No inventory; fits independent-maker ecosystem; only 500 followers currently stated for Creator Collective | Very low | Eligibility check now |
| 3 | Provenance, care, and packing digital system | Crosses collector and creator audiences; reinforces trust; low fulfillment risk | Low | First 30 days |
| 4 | Creator-operator workbook | Tests the potentially higher-value professional segment | Low | Days 31–60 |
| 5 | Treasure Route adaptation patterns | Turns unique finds into repeatable product commerce | Low | First two sourcing episodes |
| 6 | Expo problem census | High-density product intelligence and supplier leads | Moderate time | Before Portland Expo |
| 7 | Invitation-only creator affiliate network | Turns trusted relationships into transparent distribution | Low initially; requires owned products/store | After proven catalog |
| 8 | Structured product catalog for Google/Pinterest/YouTube | Reuses one data asset across discovery surfaces | Moderate | After owned catalog exists |
| 9 | Modular display infrastructure | Strong owned-product hypothesis, but requires interviews and testing | High | After 90-day evidence gate |
| 10 | Membership/update service | Potential recurring revenue, but creates recurring delivery obligation | Moderate/high | Only after cadence proof |

## Sixty-day evidence program

### Test A: project-intelligence record

Build one complete record for the first project. Success means another person can choose compatible products and understand the reasoning without asking Anna or Haley to reconstruct the process.

### Test B: unique versus repeatable

For two Treasure Route projects, measure clicks separately for the unique hero object and the repeatable supporting products. The expected result is that the unique object earns attention while the standard products earn most attributable commerce.

### Test C: enthusiast versus creator-operator

Publish one beginner tool and one creator-operator tool. Compare opt-in rate, paid conversion, support burden, and repeat questions. Do not assume the larger audience is the more valuable audience.

### Test D: curated Etsy path

Verify eligibility for Etsy Affiliates or Creator Collective. If approved, build three collections: display infrastructure, unusual supports and enclosures, and creator-business supplies. Measure outbound clicks and qualifying orders separately from BonesAndHoes' own Etsy listings.

### Test E: provenance/care/packing lane

Release a free starter record and a paid expanded system. Tie it to one complete project and one creator-operator interview. Measure opt-ins, purchases, and requests for a physical version.

### Test F: problem codes

Use the same ten problem codes in creator outreach and Expo interviews. A later owned-product concept advances only when the same problem appears across multiple independent creators and is supported by behavior or acceptable-price evidence.

## Evidence still required

The research cannot answer these without Anna and Haley's accounts or direct market contact:

- current follower counts and eligibility for Etsy Creator Collective, TikTok Shop Creator, YouTube programs, and other affiliate programs;
- audience geography, saves, search terms, outbound clicks, and current content performance;
- whether creators will permit product-level project maps and later revenue-sharing collaborations;
- which compatibility fields matter most in actual projects;
- repeated failure and breakage rates;
- supplier authorization, wholesale pricing, direct-fulfillment terms, and image rights;
- customer willingness to pay for creator-operator tools, provenance systems, and later display hardware;
- the dimensions and acceptable price of any missing display component;
- sustainable weekly production capacity.

## What not to do

- Do not open a broad store before the project ledger reveals what deserves shelf space.
- Do not confuse a large marketplace result count with demand.
- Do not treat a creator feature as permission to commercialize the creator's work or audience.
- Do not turn every relationship into an immediate affiliate arrangement.
- Do not let the 50-state legal guide become the brand's emotional center.
- Do not build a membership before recurring delivery is operationally easy.
- Do not manufacture display hardware from anecdotal enthusiasm.
- Do not duplicate product records separately for every channel; maintain one controlling product record and publish outward from it.

## Atlas integration map

Add these conclusions to the later designed Atlas:

- **Opportunity map:** the project-intelligence system as the center of the business.
- **Business model:** Etsy curator role and later creator revenue-sharing network.
- **Product universe:** compatibility data and provenance/care/packing as product families.
- **Content engine:** unique-versus-repeatable sourcing pattern and failure logging.
- **Creator network:** feature → intelligence → testing → optional compensated collaboration.
- **Expo intelligence:** standardized problem census.
- **Channel map:** one structured catalog feeding multiple discovery surfaces.
- **Economics:** distinguish enthusiast value from creator-operator lifetime value.
- **90-day roadmap:** add the schema, Etsy eligibility check, creator-operator test, and provenance lane.
- **One-year map:** creator affiliate network, catalog feeds, later membership, and product development from counted problems.

## Final strategic conclusion

BonesAndHoes should not try to win by carrying the most products. It should win by understanding the full project better than any individual retailer: who is making it, what decision comes next, what fits, what fails, what must be documented, where to obtain the supporting products, and what the audience proves it values.

Content collects the evidence. Relationships expand it. Commerce monetizes it. The Atlas makes it understandable. Later products emerge from it.

