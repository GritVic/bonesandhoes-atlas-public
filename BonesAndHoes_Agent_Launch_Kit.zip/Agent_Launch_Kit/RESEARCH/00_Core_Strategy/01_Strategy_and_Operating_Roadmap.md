# BonesAndHoes Strategy and Operating Roadmap

## The decision

Anna and Haley should launch BonesAndHoes as an authentic project-media, creator-network, and project-supply commerce business. The earliest goal is not to look like a large store. It is to become the most useful bridge between inspiration and execution: show the real project, explain the decisions, credit the people, and make every necessary supporting product easy to understand and find.

The company should remain bootstrapped. For the first operating cycle, use content, digital tools, affiliate programs, and authorized supplier relationships. Buy no broad inventory. Treat every click, save, question, email signup, order, return, and supplier response as market evidence.

## The operating model

### Layer 1: Trust

Answer the questions that keep beginners and makers from moving forward:

- What is this?
- What authority controls whether I may possess or move it?
- What must I document?
- What is the next preparation step?
- Which handling and product instructions matter?
- How can it be displayed securely and respectfully?

Trust resources include the legal navigator, preparation decision trees, documentation templates, safety reminders, source links, and clear corrections.

Trust is not the final product. It removes uncertainty so the audience can participate and make.

### Layer 2: Attention and desire

Create attention through authentic narratives:

- finding and discovery context;
- the decision to keep, leave, document, or ask an authority;
- preparation progress and problems;
- design sketches and competing artistic directions;
- searching for a distinctive base, frame, cabinet, dome, or other support;
- construction and display engineering;
- the reveal;
- the creator, place, or relationship behind the work.

The content should make the viewer want to understand, try, collect, visit, share, or create. It should never feel like a catalog demonstration disguised as art.

### Layer 3: Commerce

Attach products to the moment in which they earn their place:

- field documentation;
- safe handling;
- cleaning and preparation;
- drilling, shaping, and attachment;
- substrates and structural components;
- enclosures and display systems;
- finishing and lighting;
- labels and records;
- photography;
- storage, packing, and shipping.

Each project page should give several compatible choices, including economical, refined, and premium paths where useful. The audience chooses its own aesthetic. BonesAndHoes supplies the reasoning, measurements, compatibility notes, and trusted links.

### Layer 4: Network

Permission-cleared creator spotlights, shop profiles, expert interviews, Expo reporting, and regional material routes create a relationship network. Every completed feature should produce:

- a useful story for the audience;
- visible value for the participant;
- a project/material record;
- at least one next introduction;
- a follow-up action;
- performance feedback when appropriate.

### Layer 5: Defensible products

After at least 90 days of evidence, repeated needs may justify difficult-to-find owned products. The strongest current hypothesis is refined modular display infrastructure: discreet stands, rods, adapters, bases, enclosure systems, mounting inserts, labeling/provenance systems, and fragile-art packing systems.

No product advances because it merely looks promising. It must pass customer interviews, supplier quotes, margin modeling, compatibility review, and practical testing.

## Priority audiences

### Curious beginner

Need: confidence and correct sequence.

First offer: a free “before you begin” decision guide and project record.

Commerce bridge: gloves, containers, labels, brushes, measuring tools, reference materials.

### New processor

Need: problem diagnosis, patience, product-instruction discipline, and stopping points.

First offer: a process map and troubleshooting journal.

Commerce bridge: tubs, strainers, brushes, appropriate protective equipment, drying and storage tools.

### Display-focused collector

Need: stability, protection, proportion, lighting, dust control, and care.

First offer: display-design measurement worksheet.

Commerce bridge: domes, cases, stands, bases, rods, mounting materials, lighting, labels.

### Artist and maker

Need: individual artistic direction plus reliable construction options.

First offer: project atlas organized by outcome, substrate, structural system, and protection.

Commerce bridge: frames, reclaimed and new substrates, tools, attachment systems, finishes, photography, packing.

### Working creator or vendor

Need: audience discovery, peer relationships, supply intelligence, and operational learning.

First offer: permissioned profile, project-material map, event/vendor directory, and network introduction.

Commerce bridge: referral relationships, transparent collaborations, display and packing supplies, later wholesale opportunities.

## The offer ladder

### Free

- 50-state legal-navigation guide with dated official links;
- project documentation record;
- search vocabulary for secondhand and salvage sourcing;
- display measurement sheet;
- selected supplier and event directories;
- weekly content that solves one real problem.

Purpose: trust, email capture, audience questions, and qualified traffic.

### Low-cost digital

- project journal;
- complete preparation and progress record;
- display-design planner;
- pricing and packing worksheet;
- sourcing and vendor comparison workbook;
- creator interview/capture system for participating makers.

Purpose: early high-margin revenue and proof that the audience will pay for organization and saved time.

### Affiliate recommendations

- project supply lists;
- budget/refined/premium alternatives;
- exact-use tools and materials;
- complete shop collections by project outcome and workflow stage.

Purpose: no-inventory revenue and demand sensing.

### Authorized supplier-direct retail

- validated stands, enclosures, substrates, tools, hardware, labels, photography, storage, and packing products;
- products supplied and fulfilled under written commercial terms;
- no reliance on purchasing from a public retailer after the customer order.

Purpose: better margins and an owned customer relationship without premature warehousing.

### Later owned products

- modular tabletop and wall display systems;
- bases and enclosure combinations;
- small-scale rod and clamp systems;
- removable mounting inserts;
- provenance and care systems;
- fragile-art packing systems.

Purpose: solve repeated, measured gaps with stronger margins and defensibility.

## The first 90 days

### Days 1–7: establish the operating foundation

Owner decisions:

1. Select the primary public account and record its current analytics.
2. Select five initial project types.
3. Choose one free guide and one paid digital resource.
4. Define the product and content tracking fields.
5. Assign owner responsibility for content, product research, outreach, and legal/source review.

Build:

- a single product ledger;
- a single creator/network CRM;
- a content record template;
- tagged link conventions;
- disclosure and permission templates;
- a correction and refresh process.

Exit gate: all five systems exist and one complete project has been selected for production.

### Days 8–30: publish proof

Actions:

- publish the free guide through a no-monthly-cost digital storefront;
- publish one paid digital resource;
- apply to suitable affiliate programs;
- build a 50-product recommendation library, each product assigned to a real project job;
- publish 12 content units from discovery, process, design, build, reveal, and supply-list stages;
- begin the first five creator and local-resource outreach conversations;
- start a question log from comments, messages, and searches.

Exit gate:

- at least 100 qualified outbound product clicks;
- reliable link attribution;
- one finished project-to-supply page;
- at least one completed permission-cleared creator or local-resource feature.

If the traffic threshold is not reached, improve audience fit, hooks, and distribution before adding a store platform.

### Days 31–60: test demand and relationships

Actions:

- publish a second full project cycle;
- open a narrow Etsy shop for qualifying digital and original offers;
- add 6–12 tested listings rather than a broad assortment;
- contact 25 relevant manufacturers or brands for affiliate, wholesale, or authorized supplier-direct terms;
- complete two outreach waves of five targets each;
- publish a Treasure Routes or regional material-sourcing episode;
- compare budget and premium display paths;
- prepare Expo permission requests and interview targets if timing applies.

Exit gate:

- at least 10 attributed transactions across digital or recommended products;
- at least three product families showing independent interest;
- supplier responses recorded with economics and fulfillment conditions;
- two completed creator features and at least two warm introductions.

### Days 61–90: choose the scalable path

Actions:

- join TikTok Shop as a creator affiliate when eligibility is met;
- decide whether Payhip alone is sufficient or an owned checkout is justified;
- choose Square Free unless Shopify’s supplier-direct or synchronization value clearly exceeds its cost;
- score at least 50 potential supplier-direct products but publish none below the fulfillment and margin gate;
- rank the top 25 products by qualified clicks, saves, questions, conversions, price, availability, and return risk;
- interview 20 creators or customers about missing sizes, mounting problems, enclosures, materials, and acceptable price;
- select no more than two later product concepts for deeper validation.

Exit gate:

- three independently converting product families;
- no unresolved fulfillment or policy issue for anything sold directly;
- a documented choice of owned-store timing;
- a ranked product, content, and relationship backlog for the next quarter.

## Months 4–6

- Add an owned checkout when its economic or operating trigger is satisfied.
- If Shopify is selected, test 2–5 authorized suppliers and 10–20 products.
- Add Pinterest and Google product discovery after the catalog and policies are stable.
- Connect Meta and prepare YouTube Shopping only when eligibility and catalog quality support them.
- Complete the first Expo or regional-market field-intelligence cycle.
- Prototype one owned display component only if all research gates are met.

Gate: positive contribution after returns for two consecutive months and a documented customer-service process.

## Months 7–12

- Consider TikTok Seller only for products with proven compliant fulfillment.
- Use eBay for narrow search-led hardware or vintage display opportunities where appropriate.
- Consider Amazon Handmade only for qualifying, high-margin, repeatable finished work.
- Prepare Faire only when a wholesale-ready owned product exists.
- Expand the creator network through relationship chains rather than mass outreach.
- Review the full content, product, supplier, platform, and legal source corpus quarterly.

## Decision gates

### Inventory gate

Do not purchase inventory until a product has repeated attributed demand, acceptable contribution after all costs, a credible sales forecast based on observed performance, and a manageable fulfillment plan.

### Supplier-direct gate

Every product requires written authorization, cost, inventory visibility, ship-from location, handling promise, tracking method, return ownership, safety information, image rights, and positive base-case contribution.

### Owned-product gate

Require:

- 90 days of behavioral evidence;
- 20 creator or customer interviews;
- three supplier quotes;
- prototype testing appropriate to the product;
- viable landed economics;
- compatible platform and advertising language.

### Event gate

Attend or cover an event only with a clear research objective, permission plan, interview slate, capture system, follow-up capacity, and expected content or network value.

### Content gate

Every piece needs one audience job, one clear question or story, verified rights, a source basis, a natural product moment if one exists, a primary call to action, and a measure that matters.

## Metrics that decide what happens next

Track weekly:

- qualified views, saves, completion, and returning viewers;
- product clicks and click-through rate;
- attributed orders, commission, cancellations, and returns;
- contribution per 1,000 qualified views;
- contribution per physical order after returns;
- free-guide signups and email-to-sale conversion;
- repeat demand by product family;
- audience questions coded by need;
- accepted introductions and completed creator features;
- supplier response rate and number of products passing the launch gate;
- source corrections and unresolved claims.

Do not treat follower count alone as progress. The core scoreboard is trust, qualified intent, contribution, relationship growth, and repeat demand.

## Immediate next-owner decisions

1. Which account is the primary commerce identity, and what are its current follower, reach, save, click, and audience-location figures?
2. Which five real projects will anchor the first content and product taxonomy?
3. Which free resource and paid digital tool can be completed first?
4. Who owns each weekly operating function?
5. What physical-product contribution threshold and maximum delivery promise are non-negotiable?
6. Which Portland and Pacific Northwest relationships already exist and can begin the first outreach wave?

These questions should appear in the final Atlas as decision boxes, not as unresolved research hidden in an appendix.
