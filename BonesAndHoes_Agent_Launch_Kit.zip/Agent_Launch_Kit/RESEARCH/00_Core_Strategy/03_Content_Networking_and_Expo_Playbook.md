# BonesAndHoes Content, Networking, and Expo Playbook

## The content principle

The opening promise is always a story, problem, discovery, transformation, or useful insight. A sale is secondary.

One complete project can generate:

- discovery or source-context short video;
- identification and jurisdiction questions;
- documentation entry;
- preparation stages and troubleshooting;
- design directions and audience vote;
- treasure-sourcing episode for the supporting object;
- tool and material demonstrations;
- construction sequence;
- finished reveal;
- display, maintenance, photography, or packing follow-up;
- long-form video;
- email story;
- Atlas project page;
- shop collection and complete supply list.

The product is mentioned naturally because it visibly solves a problem in the project. The viewer is told that the exact products and alternatives are listed below. The content does not interrupt itself for a prolonged sales pitch.

## First content portfolio

### Found, Chosen, Made

The complete transformation: source context, project brief, preparation, design, construction, reveal, and material ledger.

Business job: flagship trust and commerce format.

Measure: completion, saves, qualified clicks, repeat viewers.

### Treasure Routes

Search thrift stores, creative reuse centers, architectural salvage, estate sales, yard sales, auctions, Facebook Marketplace, local free groups, and repair networks for distinctive bases, frames, cabinets, domes, lighting, and hardware.

Business job: entertaining regional identity plus demand for the repeatable supporting tools and adaptation materials.

Measure: saves, local submissions, source referrals, project-page visits.

### Search Like a Set Designer

Teach the audience to search by function rather than one product name. For an enclosure, try cloche, bell jar, curio case, specimen case, clock dome, display case, and shadow box. For a base, try plinth, pedestal, lamp base, trophy base, cabinet door, cake stand, riser, and wood offcut.

Business job: email-capture glossary and preparation for later linked solutions.

### One Find, Three Directions

Show three distinct artistic directions for the same support or problem. Let the audience choose what is built.

Business job: engagement and evidence without prescribing a uniform aesthetic.

### Display Engineering

Solve balance, attachment, glare, enclosure, lighting, labeling, dust, transport, or measurement problems.

Business job: the strongest bridge to mounts, rods, stands, cases, lighting, labels, and later owned components.

### The Tool Earned Its Place

One recurring problem, one controlled demonstration, the limitations, and a lower-cost alternative.

Business job: honest affiliate content.

### Booth Anatomy

With permission, examine hierarchy, lighting, stands, labels, packing, price communication, and customer flow at one maker’s booth.

Business job: Expo intelligence, creator value, and display-product discovery.

### What the Vendor Learned

One creator explains one pricing, sourcing, merchandising, event, or customer lesson.

Business job: network growth and practical market education.

### Make It, Price It, Pack It

Show materials, time, pricing logic, packaging test, shipping choice, and post-delivery learning.

Business job: digital worksheet sales and packing-product commerce.

### Maker-to-Maker Chain

Each guest introduces the next relevant maker, supplier, educator, shop, or expert.

Business job: turn isolated interviews into a network.

## Content record for every episode

- content ID and series;
- audience job and central question;
- source basis;
- participant and location permissions;
- legal or acquisition verification needed;
- products and objects shown;
- commercial relationship and required disclosure;
- claims requiring verification;
- planned short, long, photo, email, Atlas, and shop outputs;
- call to action and primary success measure;
- published links;
- performance after 7, 30, and 90 days;
- relationship follow-up.

## Permission and attribution workflow

1. Save the public link and internal notes; do not assume public media may be reused.
2. Screen for fit, conflicts, sourcing questions, and unsafe or unsupported claims.
3. Ask in writing for the exact media, platform, edits, duration, caption context, links, and commercial context intended.
4. Record the permission, required credit, limitations, and revocation method.
5. Confirm the participant’s preferred provenance and factual language.
6. Publish credit prominently and link to the participant’s preferred destination.
7. Disclose payment, products, affiliate relationships, or other material relationships clearly.
8. Send the participant the live link and invite corrections.
9. Report useful performance and keep the relationship active.

Credit alone is not a substitute for permission.

## Networking strategy

Do not treat the network as a cold influencer list. Build trust chains.

### Seven working clusters

1. Pacific Northwest creators and retailers.
2. Preparation and workshop educators.
3. Events and media.
4. Museums, collections, and legal/scientific authorities.
5. Display and commerce suppliers.
6. Pacific Northwest reuse and material sources.
7. Community and professional connectors.

### Relationship sequence

1. Start with approachable Oregon and Washington creators, shops, reuse centers, and educators.
2. Complete permission-cleared features that visibly help the participant.
3. Use the finished work as proof when asking for introductions.
4. Approach the Portland and Seattle Expo dates with scheduled interviews.
5. Turn each interview into a creator story, project-material map, preferred shop link, and next relationship.
6. Keep institutional accuracy work separate from product promotion so no endorsement is implied.

### First outreach waves

Work in waves of five. Finish at least one public or internal proof asset before beginning the next wave.

Wave-one priorities should combine local access and network leverage:

- an Oregon creator with a strong project and education story;
- a regional oddities retailer;
- a Portland shop with multiple represented creators;
- the Oddities & Curiosities Expo organizer;
- a workshop educator or instructor.

Wave two should add a premium retailer, local museum or collection, creative reuse organization, and two relevant creators or suppliers.

The completed 61-entity networking directory contains the ranked first 25, public contact routes, relationship rationale, collaboration ideas, risks, confidence, and next actions.

### Lightweight CRM stages

- Researching
- Ready to contact
- Contacted
- Replied
- Call scheduled
- Permission pending
- In production
- Published
- Follow-up due
- Active relationship
- Not now
- Do not contact

Required fields include owner, last action, next action, due date, introduction source, permission status, promised deliverable, public links, and relationship notes.

## Relationship-chain examples

### Local creator to Expo

Shop profile → opt-in creator introduction → project interview → material map → Expo interview → shared creator, shop, and event audience.

### Reclaimed support to commerce

Reuse-center visit → distinctive base or frame → Anna and Haley build video → reveal → exact adaptation supplies → partner reshare.

### Creator expertise to trusted referrals

Creator interview → specialist referrals → specialist interviews → vetted learning-resource page → relevant event or class guide.

### Event interview to commerce loop

Scheduled interview → creator-approved media → project supply map → creator shop link first → relevant BonesAndHoes collection → performance follow-up → next introduction.

### Supplier to later product

Technical supplier interview → audience comparison guide → repeated requests for missing sizes → manufacturing inquiry → prototype after evidence → creator testing.

## Expo purpose

The Expo is a compressed market laboratory. It contains creators, classes, price ladders, booth systems, customer questions, supply choices, retail relationships, and touring business models.

The verified census currently contains 58 records with direct source links and evidence labels, including 48 current vendors, instructors, a partner, the organizer, and clearly separated historical or discovery leads. A stable complete city roster was not publicly available, so the directory must not be described as exhaustive.

## What the vendor research reveals

Recurring public models include:

- portable lower-cost merchandise;
- wholesale plus direct retail;
- one creator’s work traveling through a partner booth;
- collective storefront plus touring team;
- materials-included workshops;
- timed drops and rotating one-of-one stock;
- service plus product revenue;
- stockist networks;
- selective premium-event strategies;
- event-to-owned-channel continuity;
- cross-event audience portfolios;
- gift and consumable repeat purchase;
- high-ticket functional art.

BonesAndHoes should study how the businesses work, not copy their aesthetics.

## Expo preparation

### Before

- Request organizer permission, filming rules, press expectations, and the current vendor directory.
- Schedule the highest-value interviews before the event.
- Prepare written creator permission and attribution records.
- Build a sampling grid for category, visible price ladder, support/display choices, public stockout signs, shopper questions, and follow-up path.
- Research each target’s current work so questions are specific.
- Prepare compact two-, ten-, and twenty-minute interview formats.

### During

- Sample a category-diverse set of booths at consistent intervals.
- Record only public prices and direct observation unless the vendor supplies a statement.
- Ask each participant to name one hard-to-find support, substrate, enclosure, tool, or packing problem.
- Capture preferred links and follow-up permissions.
- Ask who else should be interviewed.
- Respect all photo, privacy, and no-recording boundaries.

### After

- Confirm names, links, quotes, and attribution.
- Send promised assets and publication timing.
- Publish features in a sequence that connects creator, project, supporting products, shop, and next event.
- Monitor public post-event updates for 30 days.
- Record introductions and next actions in the CRM.
- Update the vendor and product infrastructure directories.

## Expo interview formats

### Two-minute floor interview

- What is the one work or decision we should notice?
- What support, display, or material choice made it work?
- Where should people follow or buy from you?

### Ten-minute business interview

- Who is the buyer?
- What brings attention but does not convert?
- What tends to sell earlier or later in the event?
- What travels well and what creates operational problems?
- Which display or packing change made the biggest difference?
- What buyer questions repeat?
- How does the event connect to the website, email, stockists, services, or classes?

### Twenty-minute operator interview

- How did the current offer develop?
- What is the public price architecture and why?
- Which products, services, workshops, stockists, or partnerships support the business?
- How are one-of-one work, touring inventory, partner booths, and fulfillment handled?
- What hard-to-find supporting product deserves a better solution?
- Which audience, city, or event produces the best long-term relationship?
- Which next creator, supplier, or operator should be interviewed?

Never invent private sales, margins, attendance, or profitability. Separate direct observation, participant statement, and BonesAndHoes interpretation.

## Treasure-sourcing system

### Source categories

- thrift stores and charity shops;
- creative reuse centers;
- architectural salvage and reclaimed-material retailers;
- Habitat ReStores;
- estate and yard sales;
- auction and resale platforms;
- Facebook Marketplace and local free groups;
- repair cafés and maker networks;
- store-closing and workshop-clearance lots.

### Search by function

- Enclosure: cloche, bell jar, curio case, clock dome, display case, specimen case, shadow box.
- Base: plinth, pedestal, lamp base, trophy base, cake stand, cabinet door, wood offcut, riser.
- Upright support: mineral stand, plate stand, doll stand, sign holder, easel, wire stand.
- Frame: deep frame, floating frame, box frame, vintage frame.
- Cabinet: curio cabinet, apothecary cabinet, printer drawer, typesetter tray.
- Hardware: standoff, threaded rod, brass rod, clamp, bracket, cleat, finial.
- Lighting: picture light, puck light, cabinet light, gooseneck lamp, museum light.
- Bulk: craft lot, hardware lot, shop cleanout, store fixtures, estate lot.

### Selection screen

Check stability, material compatibility, mold or pests, unknown residues, older coatings, electrical condition, glass damage, structural integrity, ownership, privacy, transport, and safe adaptation. The fact that an object looks good on camera does not make it usable.

## Editorial QA

Before publication confirm:

- people, media, objects, locations, and audio may be used as planned;
- names, links, quotes, prices, and claims are current;
- statements, observations, and interpretation are distinguished;
- legal and safety content uses controlling sources and communicates uncertainty;
- the opening promises audience value rather than a sale;
- products are genuinely used or clearly labeled alternatives;
- disclosures are clear and close to the recommendation;
- creator credit is prominent;
- private information is protected;
- the call to action serves the audience and participant before the shop.
