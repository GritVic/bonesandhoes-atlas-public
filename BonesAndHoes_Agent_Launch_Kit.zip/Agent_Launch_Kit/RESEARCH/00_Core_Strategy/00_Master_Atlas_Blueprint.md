# BonesAndHoes Master Atlas Blueprint

## Controlling purpose

This Atlas is a private operating guide for Anna and Haley. It is not a public explanation of their niche and it is not a legal treatise. Its job is to turn a distinctive creative practice into a bootstrapped, content-led business with clear choices, revenue paths, research tools, relationship targets, and an ordered launch plan.

The emotional center is possibility: Anna and Haley already possess the authentic subject matter, curiosity, making process, and visual world that can attract an audience. The Atlas shows how to translate that advantage into attention, trust, useful commerce, and eventually defensible products without purchasing inventory before demand is visible.

## Strategic thesis

BonesAndHoes should become the project-to-supply translator for this market.

The audience is drawn to authentic discovery, preparation, transformation, artistic judgment, and finished work. The scalable early revenue does not depend on selling regulated material. It comes from the surrounding project ecosystem: substrates, stands, mounts, enclosures, hardware, tools, consumables, finishes, lighting, documentation, photography, storage, and packing.

One documented project should therefore perform four jobs:

1. Tell an engaging story.
2. Teach a useful decision or process.
3. create a complete, choice-rich materials path.
4. Produce evidence about what the audience wants enough to click, save, ask about, or buy.

Creator relationships extend that system. Permission-cleared spotlights introduce new art, new methods, new audiences, new products, and new relationships. Events compress that network into a research environment. Commerce begins with recommendations and digital tools, expands into authorized supplier-direct retail, and reaches owned products only after repeated demand is measured.

## Reader promise

At the end of the Atlas, Anna and Haley should know:

- what business they are actually building;
- what to publish first;
- which audience questions create the strongest entry points;
- which product families naturally belong beside the content;
- which channels to open, and in what order;
- what Etsy, TikTok Shop, Payhip, Square, Shopify, affiliate networks, and later marketplaces are each for;
- how to turn creator features and Expo interviews into a networking chain;
- how to source distinctive project supports from reuse, salvage, resale, and local-market channels;
- what to measure before spending money;
- what must be verified before any legal, safety, product, or platform claim is published;
- what to do in the first 7, 30, 60, 90, 180, and 365 days.

## Main Atlas boundary

Target length: 35–50 highly designed pages.

The main Atlas carries decisions, examples, visual market maps, short tables, and the operating roadmap. It does not reproduce long directories, every source note, all 50 state entries, or every supplier record. Those belong in companion resources linked from the relevant page.

Every main-Atlas section must do at least one of the following:

- reveal a market opportunity;
- show what the audience makes, wants, fears, or struggles to source;
- connect a content idea to a revenue path;
- help Anna and Haley make a decision;
- give them a specific next action;
- provide a memorable example or visual comparison.

If a passage does none of those things, it should be removed or moved to a companion resource.

## Recommended chapter architecture

### Opening: You already have the scarce asset

Purpose: establish momentum and the central advantage.

Key message: authentic discovery, making, aesthetic judgment, and a real relationship to the subject cannot be manufactured by a generic retailer. The business begins by documenting that advantage and making the surrounding project system easier to navigate.

Evidence and examples:

- recurring beginner questions;
- visible diversity of finished art formats;
- fragmented supply paths;
- current price ladder from small displays to complex finished work.

Visual requirement later: one full-spread content-to-commerce flywheel.

### Chapter 1: The opportunity map

Purpose: show the market as an ecosystem rather than one product category.

Include:

- audience segments and their jobs;
- project outcomes and supporting-product families;
- trust, attention, commerce, and product-development layers;
- why the fragmented supply problem is commercially useful.

Decision: focus initial effort on audience confidence, project inspiration, and complete supply paths.

### Chapter 2: The business model

Purpose: make the revenue system legible.

Include:

- affiliate creator/publisher revenue;
- free and paid digital resources;
- qualifying Etsy offers;
- owned checkout;
- authorized supplier-direct catalog;
- later owned difficult-to-find display components;
- workshops, services, wholesale, and events as later or selective branches.

Decision: media and curation first; inventory last.

Visual requirement later: revenue ladder from zero-inventory tests to owned products.

### Chapter 3: The product universe

Purpose: show what can be monetized around authentic projects.

Organize two ways:

- by project outcome: dome, shadow box, frame, tabletop, wall, jewelry, mixed-media, photography, storage, packing;
- by workflow stage: document, prepare, shape, attach, finish, display, photograph, store, ship.

Include budget, refined, and premium alternatives. Avoid forcing the audience into one prescribed package. The shop should offer many compatible paths with clear reasons for each choice.

Visual requirement later: illustrated project-to-product matrix.

### Chapter 4: The content engine

Purpose: convert one project into sustained attention and buying intent.

Include:

- discovery or lawful-source context;
- preparation and problem-solving;
- artistic direction;
- material and display decisions;
- finished reveal;
- supply list;
- maintenance or packing follow-up;
- reuse across short video, long video, email, shop, Pinterest, Atlas, and creator spotlight.

Featured series should include Found, Chosen, Made; Treasure Routes; Display Engineering; Booth Anatomy; The Tool Earned Its Place; One Find, Three Directions; and Maker-to-Maker Chain.

Visual requirement later: one-project content multiplication map.

### Chapter 5: The creator and relationship network

Purpose: make networking operational.

Include:

- seven network clusters;
- connector nodes;
- the first 25 outreach targets;
- five-at-a-time outreach waves;
- permission, credit, and correction workflow;
- relationship-chain examples;
- lightweight CRM stages.

Decision: create value before asking for reach, products, or introductions.

Visual requirement later: relationship-chain network map.

### Chapter 6: Expo intelligence

Purpose: treat the Expo as a research, relationship, and content acquisition environment.

Include:

- verified vendor census and recurrence patterns;
- monetization patterns already visible among vendors;
- ranked interview slate;
- before, during, and after field plan;
- booth and product observation grid;
- interview formats and question bank;
- post-event follow-up and content sequence.

Decision: attend as a prepared editorial and market-intelligence team, not as casual visitors or early inventory buyers.

Visual requirement later: Expo intelligence capture flow.

### Chapter 7: Where and how to sell

Purpose: remove channel confusion.

Include:

- TikTok Shop creator affiliate first; seller only after fulfillment compliance;
- Payhip for free and paid digital tools;
- Etsy for qualifying original digital, artistic, and supply offers;
- Amazon Associates and relevant brand programs for broad recommendations;
- Square Free as a low-cost owned checkout bridge;
- Shopify when supplier-direct synchronization or multichannel operations justify the cost;
- Pinterest, Google, Meta, and YouTube as discovery layers once an owned catalog exists;
- eBay, Amazon Handmade, and Faire only for later, specific use cases.

Visual requirement later: ranked channel matrix and launch gates.

### Chapter 8: The economics of starting small

Purpose: show why evidence should precede spending.

Include:

- affiliate revenue scenarios per 10,000 qualified views;
- digital-product economics;
- supplier-direct contribution scenarios;
- break-even triggers for paid platforms;
- the 15% minimum and 20% target contribution gates for physical products;
- the evidence required before product development.

Decision: optimize contribution per qualified view and contribution per order, not vanity metrics.

### Chapter 9: The 90-day launch roadmap

Purpose: convert the strategy into work.

Include:

- days 1–7: identity, measurement, research ledger, first project selection;
- days 8–30: free guide, paid digital tool, affiliate applications, first content batch;
- days 31–60: creator spotlights, Etsy tests, supplier outreach, product comparisons;
- days 61–90: qualifying TikTok affiliate launch, owned checkout decision, Expo preparation, channel and product review;
- gates for continuing, revising, or stopping a tactic.

Visual requirement later: milestone road with decision gates.

### Chapter 10: The one-year expansion map

Purpose: show the larger possibility without disguising uncertainty.

Include:

- owned audience and repeatable content library;
- supplier-direct catalog;
- regional creator network;
- event intelligence system;
- later modular display hardware or documentation products;
- selective workshops or wholesale paths;
- quarterly legal, platform, and product verification.

### Closing: The next three moves

The closing should not summarize the niche. It should state the next three owner actions, the evidence expected from them, and the date of the next decision review.

## Companion-resource architecture

1. Executive Operating Roadmap: actions, owners, gates, metrics, and cadence.
2. Product, Supplier, and Merchandising Atlas: live product records, prices, dimensions, program paths, and confidence.
3. E-commerce Channel Playbooks: setup requirements, economics, policies, and launch gates.
4. Creator, Networking, and Expo Directory: contacts, relationship rationale, permission status, and next actions.
5. Content Opportunity Library: repeatable series, episode fields, permission controls, and measurement.
6. 50-State Legal Navigation Guide: federal overlay, state routing, official links, uncertainty, and verification dates.
7. Evidence Workbook and Source Register: claim-level source, access date, evidence class, caveat, and refresh need.

## Visual-production plan for the later phase

No visual assets should be generated until the text corpus is frozen.

The later visual package should contain only visuals that clarify a decision:

- opportunity ecosystem map;
- content-to-commerce flywheel;
- project-to-product matrix;
- revenue and channel ladder;
- networking chain map;
- Expo field-intelligence flow;
- 90-day roadmap;
- owned-product validation funnel;
- compact unit-economics comparisons;
- state-guide navigation logic.

NotebookLM may propose visual interpretations only after the content audit. Image generation or other agentic visual tools may be used where they can create a stronger final illustration. Layout tools should assemble approved components, not invent strategy.

## Final editorial rules

- Write to Anna and Haley as capable owners making decisions.
- Lead with opportunity and action.
- Keep legal and safety guidance visible but proportionate.
- Separate verified facts, directional observations, planning assumptions, and owner decisions.
- Do not imply that marketplace result counts equal sales.
- Do not imply that creator claims equal independently verified provenance.
- Do not imply that affiliate rates, platform eligibility, prices, or policies are permanent.
- Do not treat follower count as the primary measure of business value.
- Do not recommend inventory before demand and fulfillment evidence exist.
- Credit creators and obtain permission before reusing media.
- Preserve specific examples and numbers when they change a decision.
- Move dense directories and detailed procedures out of the main reading flow.

## Blueprint approval status

The user explicitly approved this direction: a clean rebuild, written for Anna and Haley, centered on the exciting prospect of monetizing and going to market, with legal material treated as supporting guidance. The user then authorized full execution through the text-only NotebookLM synthesis and corpus-freeze stage. This blueprint therefore serves as the approved controlling architecture for the next drafting phase.
