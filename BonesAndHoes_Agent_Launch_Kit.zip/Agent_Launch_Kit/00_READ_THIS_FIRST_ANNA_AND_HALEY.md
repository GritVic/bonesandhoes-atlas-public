# Start Here, Anna and Haley

This package turns the BonesAndHoes Monetization Atlas and its supporting research into a working business assistant you can use with Codex, ChatGPT, Claude, Grok, or another capable AI.

## Get started

1. Download `BonesAndHoes_Agent_Launch_Kit.zip` and save it somewhere you can find again.
2. Start a new conversation with your preferred agent and attach the ZIP.
3. Open `01_COPY_AND_PASTE_THIS_PROMPT.txt`, copy the complete prompt, and send it to the agent.
4. Give the agent time to inspect the package before it answers.
5. Answer its first onboarding question. It should guide you one decision at a time—not dump the entire research archive on you.
6. When the agent updates `BONESANDHOES_WORKING_STATE.md`, download and keep that file. It is the record of your decisions, progress, and next steps.
7. If you start a separate conversation later, attach the ZIP and your newest working-state file, then use the same launch prompt.

If the agent cannot open ZIP files, extract the package on your phone or computer and attach these four files first: `AGENT_README.md`, `BONESANDHOES_MASTER_CONTEXT.md`, `MANIFEST.md`, and your latest working-state file. Add the Atlas or relevant research files when the agent requests them.

The research is a starting point, not permanent truth. Platform requirements, prices, supplier terms, event details, and laws can change. Your agent is instructed to verify current information before you act.

