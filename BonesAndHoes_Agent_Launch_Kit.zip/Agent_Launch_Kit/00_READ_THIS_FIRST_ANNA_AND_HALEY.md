# Start Here, Anna and Haley

This package turns the BonesAndHoes Monetization Atlas and its supporting research into a working ChatGPT business operator.

## That is really all you have to do

1. Download `BonesAndHoes_Agent_Launch_Kit.zip` from the link in your text message.
2. Open a conversation with your ChatGPT agent and say:

> Find the BonesAndHoes Agent Launch Kit ZIP I just downloaded. Unzip it, read it, and follow the README.

Your agent is responsible for locating the downloaded ZIP, extracting it, reading the controlling files, inventorying the package, and beginning the guided conversation. You do **not** need to unzip it, sort its files, open the README, copy a long prompt, or decide which research documents the agent should read.

If the ChatGPT session genuinely cannot access downloaded files, it should say so plainly and ask you only to attach the ZIP to the conversation. After that, the agent must handle extraction and setup itself. It must never ask you to extract the package or upload its contents one file at a time.

The package includes its own continuity record. Your agent should create and maintain that record as you work, so future sessions can recover decisions, progress, and next steps without making you reorganize the project.

The research is a starting point, not permanent truth. Platform requirements, prices, supplier terms, event details, and laws can change. Your agent is instructed to verify current information before you act.
