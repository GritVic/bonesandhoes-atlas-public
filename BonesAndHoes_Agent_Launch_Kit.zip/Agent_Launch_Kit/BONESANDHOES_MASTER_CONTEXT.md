# BonesAndHoes Master Context

**Purpose:** Fast strategic orientation for a new agent  
**Research snapshot:** August 18, 2026  
**Package release:** August 24, 2026

## Executive direction

BonesAndHoes is a bootstrapped media, education, community, curation, and commerce opportunity built around Anna and Haley's authentic friendship and creative work. The business should become the most useful bridge between a real project and everything required to complete it well.

The scarce asset is not inventory. It is the combination of:

- authentic discovery and sourcing;
- preparation and problem-solving;
- artistic judgment and finished work;
- two personalities an audience can follow;
- practical teaching;
- creator and vendor relationships;
- trusted product and compatibility knowledge;
- a community that contributes searchable experience.

The direct path is:

**real project → useful content → audience questions → structured product and compatibility knowledge → trusted recommendations and digital tools → validated commerce → selective owned products**

## The five-part operating model

### 1. See the opportunity

Document authentic work. The friendship, discoveries, mistakes, judgments, and finished results are the differentiator. The content itself is early market research.

### 2. Create what people want

Organize products around the job: preparation, construction, attachment, display, protection, photography, storage, provenance, packing, and shipping. Preserve aesthetic choice; do not prescribe identical finished projects.

### 3. Build the community

Use credited reposts, creator spotlights, interviews, Expo work, local resources, and a moderated community hub to make the channel a trusted network. Community questions and contributed knowledge reveal unmet needs.

### 4. Turn attention into revenue

Start with free resources, paid digital tools, and approved product recommendations. Use Etsy, TikTok Shop, affiliate programs, email, and owned checkout for different jobs and only when current eligibility and evidence support them.

### 5. Put the plan into motion

Build the operating records, publish complete project cycles, measure qualified behavior, deepen relationships, and let evidence determine which channels, product families, suppliers, and later owned products earn expansion.

## Audience groups

1. Curious beginners seeking a confident, lawful, understandable starting path.
2. New processors needing sequence, troubleshooting, and stopping points.
3. Display-focused collectors seeking stability, protection, proportion, lighting, and care.
4. Artists and makers seeking unusual substrates and reliable construction options without losing creative freedom.
5. Working creators and vendors needing display, photography, provenance, pricing, packing, event, and supply intelligence.

The shared problem is fragmentation: inspiration, preparation, law, project design, display engineering, sourcing, and commerce live in different places. BonesAndHoes connects them.

## What to offer, in order

### Free trust tools

- Dated 50-state legal-navigation resource linked to official authorities.
- Project documentation and provenance starter record.
- Secondhand sourcing vocabulary and Treasure Routes guide.
- Display measurement and compatibility worksheet.
- Selected creator, vendor, event, and supplier guides.

### Low-cost digital tools

- Project journal and progress record.
- Display-design planner.
- Sourcing and vendor comparison workbook.
- Make It, Price It, Pack It creator workbook.
- Interview and content-capture system.
- Provenance, care, condition, and pack-out system.

### Approved recommendations

Organize products by outcome and workflow. Every recommendation should state the job, compatibility, dimensions, why it was selected, price verification date, seller, fulfillment, returns, alternatives, commercial relationship, safety flags, and test status.

### Authorized supplier-direct commerce

Use only written commercial arrangements covering inventory, pricing, handling, packaging, returns, damage, warranties, product information, service, and termination. Do not rely on ordinary retail purchasing after a customer orders.

### Later owned products

The strongest current hypothesis is refined modular display infrastructure: discreet stands, rods, adapters, bases, enclosure systems, removable mounting inserts, provenance systems, and fragile-art packing systems. Advance only after repeated measured need, interviews, quotes, economics, compatibility review, and practical tests.

## Product universe

### By outcome

- domes, cloches, and enclosure displays;
- shadow boxes and framed work;
- tabletop and wall displays;
- jewelry and wearable work;
- botanical, mineral, and mixed-media compositions;
- carved, painted, and finished art;
- photography and listing setup;
- studio storage, labeling, packing, and shipping.

### By workflow

- document and handle;
- prepare safely;
- drill, shape, and finish;
- build and attach;
- display and protect;
- photograph and publish;
- store and ship.

## Content engine

One project can produce:

- discovery or sourcing footage;
- initial-condition documentation;
- preparation progress and setbacks;
- competing artistic directions;
- unusual substrate or support sourcing;
- construction and display decisions;
- the finished reveal;
- a complete supply path;
- care, provenance, storage, and packing follow-up;
- short video, long-form video, email, project page, community prompt, and product collection.

Priority content systems include Found, Chosen, Made; Treasure Routes; Search Like a Set Designer; One Find, Three Directions; Display Engineering; The Tool Earned Its Place; Booth Anatomy; What the Vendor Learned; Make It, Price It, Pack It; and Maker-to-Maker Chain.

## Community hub

The owned website should eventually include a moderated, searchable community space where participants can contribute:

- regional sourcing knowledge and search vocabulary;
- techniques and project solutions;
- product compatibility and failure reports;
- creator and vendor discoveries;
- lawful-resource routing and agency links;
- questions that become future guides, interviews, products, and content.

The hub requires attribution, permission, correction, moderation, privacy, safety, and a ban on exposing sensitive collection locations or encouraging unlawful access. It is a central trust and intelligence asset, not a footnote.

## Channel architecture

1. TikTok and Instagram for discovery, personality, questions, and short demonstrations.
2. YouTube for durable long-form project stories, interviews, education, and description links.
3. Email for owned audience, resource delivery, and launches.
4. Payhip or equivalent for free and paid digital tools.
5. Approved affiliate programs for project-earned recommendations.
6. Etsy for qualifying original offers and, separately, eligible curation opportunities.
7. TikTok Shop Creator Affiliate after eligibility verification.
8. A searchable owned website and community hub.
9. Low-cost owned checkout when buyer intent appears outside marketplaces.
10. Shopify only when operating value or synchronization justifies the recurring cost.
11. TikTok Shop Seller, broader inventory, and additional marketplaces only after fulfillment and economics are proven.

All platform rules and costs are time-sensitive and must be rechecked.

## Relationship engine

Work across creators and educators; Expo and event operators; suppliers and brands; retailers and marketplaces; reuse and regional-resource nodes; legal and subject-matter authorities; and media/community connectors.

Use permission-first, five-at-a-time outreach waves. Create value before asking for reach, products, or introductions. A strong relationship produces a useful audience story, visible value for the participant, a project or material record, a possible next introduction, and respectful follow-through.

The curated network contains 61 entities and a ranked first-25 queue. The Expo directory contains 58 records, including 48 verified 2026 vendors. Use these as research and relationship queues—not bulk-contact lists.

## Expo method

Treat the Expo as a compressed market laboratory.

Before: rank interviews, request permission, prepare questions, define the observation grid, and schedule follow-up.

During: capture stories, product families, price bands, booth design, packaging, workshops, wholesale signals, customer questions, missing sizes, breakage, workarounds, acceptable prices, and introductions.

After: publish the strongest stories, return useful assets to participants, record follow-up, and connect observations to content, product, supplier, and relationship hypotheses.

## Invisible strategic asset

The long-term moat is a project-intelligence system linking:

- project;
- creator or vendor;
- content unit;
- product and supplier;
- dimensions and compatibility;
- failure and workaround;
- audience question;
- link and conversion behavior;
- provenance and care;
- permission and relationship status.

Build the shared ledger before building a large store. The valuable asset is evidence about what works, for whom, in which project, and with what tradeoffs.

## First 90 days

### Days 1–7: foundation

- Choose the primary account and record baseline analytics.
- Select five initial project types and one complete first project.
- Choose one free guide and one paid digital tool.
- Assign responsibility for content, research, outreach, and source verification.
- Create the project ledger, product ledger, relationship CRM, content record, tagged links, permission templates, failure log, and correction workflow.

### Days 8–30: publish proof

- Publish the first free and paid tools.
- Apply to suitable verified affiliate programs.
- Build a 50-product recommendation library tied to real jobs.
- Publish 12 content units from one project cycle.
- Begin five creator or regional-resource conversations.
- Log audience questions, clicks, saves, signups, and product interest.

### Days 31–60: test demand and relationships

- Publish a second complete project cycle.
- Launch 6–12 qualifying Etsy listings if ready.
- Contact 25 manufacturers or brands for legitimate commercial terms.
- Complete two outreach waves and two permission-cleared creator features.
- Publish a Treasure Routes episode.
- Compare economical and premium display paths.
- Test one creator-operator digital tool.

### Days 61–90: choose the scalable path

- Enter TikTok creator affiliate commerce if eligible.
- Decide whether digital checkout remains sufficient or owned checkout is justified.
- Score potential supplier-direct products by demand, margin, compatibility, and operating risk.
- Complete 20 interviews about missing sizes, display problems, enclosures, materials, and acceptable prices.
- Select no more than two later product concepts for deeper validation.

## Decision gates

- Improve content and distribution before adding a store if qualified traffic is weak.
- Require independent interest across product families before expanding the catalog.
- Do not accept unresolved fulfillment problems for direct sales.
- Do not buy a platform merely to look established.
- Do not advance a physical concept from compliments alone.
- Use qualified clicks, saves, signups, attributed transactions, repeat questions, contribution, supplier quality, warm introductions, returns, damage, and compatibility failures as evidence.

## Legal boundary

The package contains 50-state research in three non-overlapping tranches plus federal, District of Columbia, tribal, public-land, disease-movement, import, and international routing. It is dated research, not permanent permission or individualized legal advice. Verify material, origin, land authority, possession, movement, transfer, display, and commerce with the current governing authority before acting.

## Research inventory snapshot

- 50 unique states across 17 + 17 + 16 state records.
- 12 federal, District of Columbia, tribal, and land-routing records.
- 58 Expo records, including 48 verified 2026 vendors.
- 61 curated networking entities, with 25 ranked for first outreach.
- 44 content and sourcing records: 26 resources and 18 complete content-series records.
- 50+ product and pricing observations and 25+ supplier or partner records.
- 18 digital-product and lead-magnet concepts.

## Immediate decisions for Anna and Haley

1. Which account and public identity lead?
2. Who owns content, product research, outreach, and verification?
3. Which first five project types fit their actual lives?
4. Which free guide and paid digital tool go first?
5. What are the filming, privacy, interview, and commercial boundaries?
6. How much weekly production capacity exists?
7. Which current project becomes the first complete content-to-commerce record?

## The next three moves

1. Select one complete project and record every decision, product, problem, and visual moment.
2. Build the free guide, paid tool, product ledger, tagged links, and first five outreach messages around it.
3. Publish the first content cycle, measure qualified behavior, and let the evidence decide which channel and product family earns the next 60 days.

