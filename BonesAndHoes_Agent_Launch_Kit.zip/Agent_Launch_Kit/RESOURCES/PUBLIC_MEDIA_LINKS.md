# BonesAndHoes Public Media

These links require no Google account or sign-in.

- Mobile Atlas viewer: https://gritvic.github.io/bonesandhoes-atlas-public/atlas/
- Direct Atlas PDF: https://gritvic.github.io/bonesandhoes-atlas-public/BonesAndHoes_Monetization_Atlas.pdf
- Approved explainer video: https://gritvic.github.io/bonesandhoes-atlas-public/The_Evidence_Led_Blueprint_Approved.mp4

The package also contains the Atlas PDF for offline use. Platform availability can change; verify these links before sending them publicly.

