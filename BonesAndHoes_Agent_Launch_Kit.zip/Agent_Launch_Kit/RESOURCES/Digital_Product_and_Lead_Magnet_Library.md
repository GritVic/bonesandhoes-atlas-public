# Digital Product and Lead-Magnet Library

These resources can function as free trust-builders, paid expanded guides, or paired free-and-paid editions. Each should lead naturally to an email signup, Community Hub conversation, related long-form content, verified product recommendations, or a later evidence-backed physical offer.

1. **The 50-State Rules Handbook:** state-by-state acquisition, possession, roadkill, shed, transfer, agency contacts, and federal overlays. Launch as a major free trust resource, with updated or expanded editions later.
2. **“I Found This—Now What?” Decision Tree:** a fast location, land, species, documentation, authority, and next-step guide that routes readers into the rules handbook.
3. **The Bone Preparation Bench Guide:** preparation workflow, safety notes, tools, products, containers, cleaning supplies, and storage. Offer a free checklist and a paid expanded guide.
4. **The Display Compatibility Workbook:** specimen dimensions, weight, clearance, base thickness, rod size, mounting interface, enclosure dimensions, and reversibility. It should connect directly to stands, mounts, bases, and enclosures.
5. **The Hard-to-Find Display Hardware Directory:** stands, rods, mounts, inserts, bases, domes, cabinets, glass enclosures, and specialty hardware organized by use rather than generic category.
6. **The Treasure Routes Sourcing Playbook:** thrift, salvage, yard sale, estate sale, Marketplace, free-listing, and auction strategies, including search language and evaluation prompts.
7. **The Substrate and Base Idea Atlas:** visual ideas for vintage frames, wood rounds, architectural salvage, glass, metal, shadow boxes, cabinets, plinths, and found foundations.
8. **The Found–Chosen–Made Project Workbook:** a complete project record covering discovery, provenance, preparation, design, products, filming, and reveal.
9. **The One Find, Three Directions Idea Deck:** three creative approaches to a common kind of find, designed to inspire choice rather than identical results.
10. **The Failed Display File:** troubleshooting for tipping stands, weak mounts, poor adhesives, bad clearances, damaged finishes, broken glass, and shipping failures.
11. **Pack It Like It Matters:** measuring, stabilization, wrapping, void fill, glass protection, labeling, double-boxing, photography, and damage documentation.
12. **The Creator Collaboration and Permission Kit:** outreach messages, permissions, credit requirements, interview releases, repost approval, link collection, and follow-up templates.
13. **The Oddities Expo Field Kit:** vendor directory, interview questions, booth notes, product-gap worksheet, contact tracker, filming checklist, and follow-up system.
14. **The Project Pricing and Profit Calculator:** materials, platform fees, packaging, shipping, returns, owner labor, contribution, retail price, and minimum acceptable margin.
15. **The Project-to-Content Machine Planner:** one project converted into a YouTube episode, TikToks, Reels, Shorts, carousels, Stories, email, project page, product links, and creator feature.
16. **The Verified Supply Library:** a living catalog of products, dimensions, suppliers, prices, alternatives, compatibility notes, and project examples.
17. **The Provenance, Care, and Project Record Pack:** acquisition records, care sheets, photography logs, project histories, and printable labels.
18. **The Creator and Vendor Networking Atlas:** the curated directory, relationship map, outreach queue, collaboration ideas, and contact-management workflow.

## Reusable funnel

**Free checklist, decision tool, or sampler → email signup and Community Hub → expanded paid guide → project-specific product links → related long-form content → later owned product.**

Rules, platform requirements, prices, program eligibility, and supplier terms change. Verify the current primary source before making a legal, financial, fulfillment, or platform decision.
