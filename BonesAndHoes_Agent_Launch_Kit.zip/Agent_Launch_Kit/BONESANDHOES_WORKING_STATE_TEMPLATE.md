# BonesAndHoes Working State

**File purpose:** Portable continuity record for Anna, Haley, and their agent  
**Last updated:** YYYY-MM-DD  
**Updated by:**  
**Current planning horizon:**

## Current outcome

- Primary goal:
- Why it matters now:
- Success measure:
- Target date:

## Roles and capacity

| Area | Owner | Available time | Notes |
|---|---|---:|---|
| Content and filming | | | |
| Editing and publishing | | | |
| Product research and links | | | |
| Outreach and relationships | | | |
| Legal/source verification | | | |
| Operations and measurement | | | |

## Accounts and channels

| Channel/account | Status | Current audience or baseline | Next action | Date |
|---|---|---:|---|---|
| TikTok | | | | |
| Instagram | | | | |
| YouTube | | | | |
| Email list | | | | |
| Etsy | | | | |
| TikTok Shop | | | | |
| Digital checkout | | | | |
| Website | | | | |
| Community hub | | | | |

## Active projects

| Project ID | Project | Stage | Content captured | Product record | Next action | Owner/date |
|---|---|---|---|---|---|---|

## Content calendar

| Publish date | Platform | Format | Project/topic | Call to action | Status | Result |
|---|---|---|---|---|---|---|

## Offers and commerce

| Offer/product family | Type | Evidence | Current channel | Economics checked? | Status | Next gate |
|---|---|---|---|---|---|---|

## Product research and compatibility

| Product ID | Job | Project used in | Compatibility facts | Supplier/status | Link verified | Result/failure |
|---|---|---|---|---|---|---|

## Outreach and relationships

| Contact/entity | Cluster | Value offered | Permission/status | Last contact | Next action | Owner/date |
|---|---|---|---|---|---|---|

## Community intelligence

| Question or contributed insight | Source | Verification needed | Content/product implication | Follow-up |
|---|---|---|---|---|

## Measurements

| Period | Qualified views | Saves | Product clicks | Email signups | Transactions | Contribution | Returns/failures | Notes |
|---|---:|---:|---:|---:|---:|---:|---:|---|

## Decisions made

| Date | Decision | Evidence/reason | Owner | Revisit trigger |
|---|---|---|---|---|

## Completed

- 

## Open questions

- 

## Deadlines and events

| Date | Deadline/event | Preparation required | Owner | Status |
|---|---|---|---|---|

## Next recommended actions

1. **Now:**
2. **Next:**
3. **Later:**

## Current source updates

Record time-sensitive facts verified after the package research date.

| Date checked | Subject | Current finding | Primary source URL | What changed |
|---|---|---|---|---|

## Session handoff

### Decided

- 

### Completed

- 

### Learned

- 

### Begin next session with

- 

